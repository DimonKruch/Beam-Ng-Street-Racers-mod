angular.module('beamng.apps')
.directive('streetRacersTorqueCurve', ['$log', 'CanvasShortcuts',
function ($log, CanvasShortcuts) {
  return {
    template:`

      <div style="width: 100%; height: 100%; display: flex; flex-direction: column; background-color: #191b1f; color: #d7d9dc">

        <div>
          <md-input-container style="padding: 0" md-no-ink ng-hide="engines.length <= 1">
            <md-select ng-model="selectedEngine" aria-label="_" ng-change="onEngineSelection()">
              <md-option ng-repeat="eng in engines track by eng">{{ eng }}</md-option>
            </md-select>
          </md-input-container>
        </div>

        <div style="height: 70%; position: relative" >
          <canvas style="position: absolute; top: 0; left: 0" width="50" height="50"></canvas>
          <canvas style="position: absolute; top: 0; left: 0" width="50" height="50"></canvas>
        </div>

        <div style="height: 12%; width: 100%; margin-top:2%;  padding: 0;  position: relative;" layout="row">
          <md-checkbox style="z-index:100; line-height: 100%; font-size: 0.7em" md-no-ink ng-repeat="(key, val) in curves track by key" ng-change="graph()" ng-model="config[key].isPresent" aria-label="_">
            {{ val.name }}
          </md-checkbox>
        </div>

        <div style="position: relative; height: 120px; padding: 10% overflow-x: auto; overflow-y: hidden" layout="row" layout-align="left center">
          <div layout="row" flex layout-padding>
            <table ng-repeat="(key, obj) in config track by key" ng-if="obj.isPresent" style="vertical-align: center; font-size: 12px; margin: 0 4px 0 4px; padding: 0 3px 0 3px; border-left: 1px solid black; border-right: 1px solid black; border-radius: 2px;">
              <tr><th colspan="2">{{ obj.name }}</th></tr>
              <tr>
                <td><graph-legend-tip type="line" color="{{ ::obj.torque.color }}" dash-array="{{ obj.torque.dashArray }}"></graph-legend-tip> {{:: "ui.apps.torquecurve.Torque" | translate}}</td>
                <td style="font-family: monospace">{{ obj.torque.val.toFixed(2) }}/{{ obj.torque.max.toFixed(0) }}</td>
                <td style="font-family: monospace; padding: 0 3px">[{{ obj.torque.units }}]</td>
              </tr>
              <tr>
                <td><graph-legend-tip type="line" color="{{ ::obj.power.color }}" dash-array="{{ obj.power.dashArray }}"></graph-legend-tip> {{:: "ui.apps.torquecurve.Power" | translate}}</td>
                <td style="font-family: monospace">{{ obj.power.val.toFixed(2) }}/{{ obj.power.max.toFixed(0) }}</td>
                <td style="font-family: monospace; padding: 0 3px">[{{ obj.power.units }}]</td>
              </tr>
            </table>
          </div>
        </div>

      </div>`,
    replace: true,
    restrict: 'EA',
    link: function (scope, element, attrs) {

      const streamsList = ['engineInfo']
      StreamsManager.add(streamsList)

      const canvasWrapper = element[0].children[1]
        , staticCanvas = element[0].getElementsByTagName('canvas')[0]
        , sctx = staticCanvas.getContext('2d')
        , dynamicCanvas = element[0].getElementsByTagName('canvas')[1]
        , dctx = dynamicCanvas.getContext('2d')
      let maxRpm = 1, xFactor = -1

      const plotMargins = {top: 15, bottom: 25, left: 25, right: 26}

      scope.config = {}
      scope.curves = {}

      const currentVehicle = {
        id: '',
        engines: []
      }

      scope.engineIndex = -1
      scope.engines = []

      scope.selectedEngine = ''

      scope.$on('$destroy', function () {
        StreamsManager.remove(streamsList)
        currentVehicle.engines = []
        scope.curves = {}
        scope.config = {}
      })

      scope.$on('VehicleChange', () => {
        currentVehicle.id = ''
        currentVehicle.engines = []
        scope.engines = []
        scope.engineIndex = -1
        scope.selectedEngine = ''
        scope.curves = {}
        scope.config = {}
        dctx.clearRect(0, 0, dynamicCanvas.width, dynamicCanvas.height)
        plotStaticGraphs()
        bngApi.activeObjectLua('controller.mainController.sendTorqueData()')
      })


      scope.$on('TorqueCurveChanged', function (_, data) {
        // console.log('ALL DATA:', data)
        if (data.vehicleID !== currentVehicle.id) {
          // console.log('new vehicle!!')
          currentVehicle.id = data.vehicleID
          currentVehicle.engines = []
          scope.engines = []
          scope.engineIndex = -1
          scope.selectedEngine = ''
          scope.curves = {}
          // console.log('new vehicle', data.vehicleID)
        }

        const existingInd = currentVehicle.engines.findIndex(engine => engine.name === data.deviceName)
        if (existingInd === -1) {
          currentVehicle.engines.push({name: data.deviceName, curves: data.curves, maxRPM: data.maxRPM})
          // scope.engines.push({index: currentVehicle.engines.length - 1, name: data.deviceName})
          scope.engines.push(data.deviceName)
          // console.log('new engine:', data.deviceName)
        } else {
          const existingEngine = currentVehicle.engines[existingInd]
          existingEngine.curves = data.curves
          existingEngine.maxRPM = data.maxRPM
          if (scope.engineIndex === existingInd) {
            scope.selectEngine(scope.engineIndex)
          }
          // console.log('already have', data.deviceName)
        }

        scope.$evalAsync(() => {
          if (scope.engineIndex < 0) {
            scope.selectEngine(0)
          }
        })

      })

      scope.onEngineSelection = () => {
        // console.log('changed to engine', scope.selectedEngine)
        const ind = scope.engines.indexOf(scope.selectedEngine)
        if (ind > -1)
          scope.selectEngine(ind)
      }

      scope.selectEngine = (engineIndex) => {
        // console.log('selecting', engineIndex, currentVehicle.engines[engineIndex])
        for (let key in scope.config) {
          scope.config[key].power.data = []
          scope.config[key].power.max = 0
          scope.config[key].torque.data = []
          scope.config[key].torque.max = 0
          scope.config[key].isPresent = false
        }

        maxRpm = currentVehicle.engines[engineIndex].maxRPM
        updateScopeData(currentVehicle.engines[engineIndex].curves)
        scope.engineIndex = engineIndex
        plotStaticGraphs()

        scope.selectedEngine = currentVehicle.engines[engineIndex].name
        scope.engineIndex = engineIndex
        scope.curves = {}
        for (let curveKey in scope.config) {
          scope.curves[curveKey] = { name: scope.config[curveKey].name }
        }
        scope.$evalAsync()
      }

      scope.$on('SettingsChanged', function () {
        bngApi.activeObjectLua('controller.mainController.sendTorqueData()')
      })

      const updateScopeData = function (curves) {
        for (let key in scope.config) {
          if (!curves.hasOwnProperty(key))
            delete scope.config[key]
        }
        for (let key in curves) {
          const torqueArr = Array.isArray(curves[key].torque) ? curves[key].torque : []
          const powerArr = Array.isArray(curves[key].power) ? curves[key].power : []
          const mp = powerArr.length ? Math.max.apply(Math, powerArr) : 0
          const mt = torqueArr.length ? Math.max.apply(Math, torqueArr) : 0

          scope.config[key] = {
            torque: {
              color: '#d7d9dc',
              dashArray: curves[key].dash ? curves[key].dash : [],
              width: curves[key].width,
              data: torqueArr.map(key => UiUnits.torque(key).val ),
              max: UiUnits.torque(mt).val ,
              units: UiUnits.torque(mp).unit,
              val: 0
            },
            power: {
              color: '#f47c20',
              dashArray: curves[key].dash ? curves[key].dash : [],
              width: curves[key].width,
              data: powerArr.map(key => UiUnits.power(key).val ),
              max: UiUnits.power(mp).val,
              units: UiUnits.power(mp).unit,
              val: 0
            },
            isPresent: key < 2 ? true : false,  // only displays first two curves by default
            name: curves[key].name
          }
        }
      }

      const plotStaticGraphs = function () {
        const plotMaxRpm = maxRpm > 1 ? maxRpm : 5000
        xFactor = (dynamicCanvas.width - plotMargins.left - plotMargins.right) / plotMaxRpm
        sctx.clearRect(0, 0, staticCanvas.width, staticCanvas.height)

        let maxPower = 0 , maxTorque = 0

        for (let key in scope.config) {
          if (scope.config[key].isPresent) {
            maxPower  = Math.max(maxPower,  scope.config[key].power.max)
            maxTorque = Math.max(maxTorque, scope.config[key].torque.max)
          }
        }

        maxPower  = Math.ceil(maxPower) || 250
        maxTorque = Math.ceil(maxTorque) || 250
        const powerTicks  = Array(6).fill().map((x, i, a) => i * maxPower / (a.length - 1))
        const torqueTicks = Array(6).fill().map((x, i, a) => i * maxTorque / (a.length - 1))
        const rpmTicks    = Array( Math.floor(plotMaxRpm/1000) + 1 ).fill().map((x, i) => i*1000)

        CanvasShortcuts.plotAxis(sctx, 'left',  [0, maxTorque], torqueTicks, plotMargins, {numLines: torqueTicks.length, color: 'darkgrey', dashArray: [2, 3]}, '#d7d9dc')
        CanvasShortcuts.plotAxis(sctx, 'right', [0, maxPower],  powerTicks,  plotMargins,  null,                          'red')
        CanvasShortcuts.plotAxis(sctx, 'top',     [0, plotMaxRpm],          [], plotMargins,      null)
        CanvasShortcuts.plotAxis(sctx, 'bottom',  [0, plotMaxRpm], rpmTicks, plotMargins, {values: rpmTicks, color: 'darkgrey', dashArray: [2, 3]} , '#d7d9dc')

        Object.keys(scope.config).forEach(function (x) {
          const cc = scope.config[x]
          if (!cc.isPresent) return
          if (cc.torque.data.length > 1)
            CanvasShortcuts.plotData(sctx, cc.torque.data, 0, maxTorque, {margin: plotMargins, lineWidth: cc.torque.width, lineColor: cc.torque.color, dashArray: cc.torque.dashArray })
          if (cc.power.data.length > 1)
            CanvasShortcuts.plotData(sctx, cc.power.data,  0, maxPower,  {margin: plotMargins, lineWidth: cc.power.width,  lineColor: cc.power.color,  dashArray: cc.power.dashArray  })
        })
      }

      scope.graph = function () {
        plotStaticGraphs()
      }

      scope.$on('streamsUpdate', function (event, streams) {
        dctx.clearRect(0, 0, dynamicCanvas.width, dynamicCanvas.height)
        const _rpm = streams.engineInfo ? streams.engineInfo[4] : undefined

        if (_rpm === undefined || _rpm >= maxRpm) { return; }

        const rpmX = plotMargins.left + Math.floor(_rpm * xFactor)

        dctx.beginPath()
        dctx.moveTo(rpmX, plotMargins.top)
        dctx.lineTo(rpmX, dynamicCanvas.height - plotMargins.bottom)

        dctx.lineWidth = 2
        dctx.strokeStyle = 'orange'
        dctx.shadowBlur = 30
        dctx.shadowColor = 'steelblue'
        dctx.stroke()

        const rpmInd = Math.floor(_rpm)
        scope.$evalAsync(function () {
          for (let key in scope.config) {
            if (scope.config[key].isPresent) {
              scope.config[key].power.val = scope.config[key].power.data[rpmInd] ?? 0
              scope.config[key].torque.val = scope.config[key].torque.data[rpmInd] ?? 0
            }
          }
        })
      })

      let _ready = false

      scope.$on('app:resized', function (event, data) {
        // We can use this event as initialization trigger since it is emitted from
        // the app-container for this reason
        const w = canvasWrapper.offsetWidth
        const h = canvasWrapper.offsetHeight + plotMargins.bottom
        if (staticCanvas.width !== w || staticCanvas.height !== h) {
          staticCanvas.width = w
          staticCanvas.height = h
        }
        if (dynamicCanvas.width !== w || dynamicCanvas.height !== h) {
          dynamicCanvas.width = w
          dynamicCanvas.height = h
        }

        if (!_ready) {
          _ready = true
          bngApi.activeObjectLua('controller.mainController.sendTorqueData()')
        }
        plotStaticGraphs()
      })

      scope.$on('VehicleFocusChanged', function() {
        bngApi.activeObjectLua('controller.mainController.sendTorqueData()')
      })

      // A layout/UI reload can mount the app after the vehicle's initial event,
      // without a resize event. Request data only after all listeners exist.
      scope.$evalAsync(() => {
        bngApi.activeObjectLua('controller.mainController.sendTorqueData()')
      })

    }
  }
}])

