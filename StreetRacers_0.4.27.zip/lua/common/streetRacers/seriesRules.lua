-- StreetRacers, 2026. MIT. Independent stakes for Street championship.
local rules=require('streetRacers/domain')
local M={}
function M.limit(power,length)
  if not rules.finite(power) or power<=0 or not rules.finite(length) or length<=0 then return nil end
  local base=1000+math.max(0,power-100)*6
  local distance=math.sqrt(math.max(400,length)/400)
  return math.floor(math.min(15000,base*distance)/50)*50
end
function M.valid(stake,power,length,balance)
  local cap=M.limit(power,length)
  return cap and rules.finite(stake) and stake>=50 and stake%50==0 and stake<=cap and stake<=balance or false
end
function M.opponent(power,catalog,mode,used)
  if not rules.finite(power) or power<=0 then return nil end
  local best,score
  for _,row in ipairs(catalog or {}) do
    if rules.finite(row.power) and row.power>0 and not (used and used[row]) then
      local cost=math.abs(math.log(row.power/power))+(mode~='drag' and row.class=='drag' and 2 or 0)
      if not score or cost<score then best,score=row,cost end
    end
  end
  return best
end
function M.lineup(power,catalog,mode,count)
  local rows,used={},{}
  for i=1,count do
    local row=M.opponent(power,catalog,mode,used) or M.opponent(power,catalog,mode)
    if not row then return nil end
    rows[i]=row used[row]=true
  end
  return rows
end
function M.participants(bots,mode)
  -- Alder has exactly two lanes. Other races keep their configured field size.
  if mode=='drag' then return 2 end
  bots=tonumber(bots)
  return 1+math.floor(rules.clamp(rules.finite(bots) and bots or 3,1,5))
end
function M.payout(stake,outcome,participants)
  if not rules.finite(stake) or stake<0 or not rules.finite(participants) or participants%1~=0 or participants<2 or participants>6 then return 0 end
  if outcome=='win' then return stake*participants end
  if outcome=='void' or outcome=='draw' then return stake end
  return 0
end
function M.outcome(player,opponents)
  local first
  for _,state in ipairs(opponents) do
    if state.complete and (not first or state.endTime<first.endTime) then first=state end
  end
  if player.complete and first then
    if math.abs(player.endTime-first.endTime)<0.001 then return 'draw' end
    return player.endTime<first.endTime and 'win' or 'loss'
  end
  if player.complete then return 'win' end
  if first then return 'loss' end
end
return M
