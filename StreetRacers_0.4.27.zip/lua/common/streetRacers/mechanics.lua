-- StreetRacers, 2026. MIT. Gameplay fatigue, in addition to native crash/thermal damage.
local rules=require('streetRacers/domain')
local M={}
function M.loss(kind,sample,dt)
  local function num(x,default) return rules.finite(x) and x or default end
  dt=rules.clamp(num(dt,0),0,0.25)
  local av=math.abs(num(sample.av,0))
  local load=rules.clamp(math.abs(num(sample.load,0)),0,1.5)
  if av<5 or load<0.03 or dt==0 then return 0 end
  local rpm=rules.clamp(num(sample.rpmRatio,0),0,1.3)
  local hp=rules.clamp(num(sample.power,150),1,3000)
  local stress=rules.clamp((hp/1000)^1.5,0.025,5.2)
  local speed=math.max(math.abs(num(sample.speed,0)),12*rpm*load)
  local heat=1+rules.clamp((num(sample.temperature,90)-110)/20,0,3)
  local boost=rules.clamp(num(sample.boost,0),0,4)
  local nitrous=rules.clamp(num(sample.nitrous,0),0,1)
  local cold=num(sample.temperature,90)<60 and 1.5 or 1
  local race=rules.clamp((load-0.45)/0.55,0,1.5)^3*math.sqrt(rpm)
  local factors={engine=1,gearbox=0.60,differential=0.40,clutch=0.90}
  -- Gameplay calibration: 100 seconds of loaded 1000 PS racing at 90% RPM
  -- consumes about 30 points. Cruising remains inexpensive; no per-race debit.
  local factor=factors[kind] or 1
  local road=speed/20000000*math.min(2,stress+0.1)*load
  local abuse=0.0031623*stress*race*heat*cold*(1+0.12*boost)*(1+3*nitrous)
  return math.min((road+abuse)*dt*factor,dt*0.04*factor)
end
return M
