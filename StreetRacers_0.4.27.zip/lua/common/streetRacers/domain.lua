-- StreetRacers, 2026. MIT. Pure rules shared by GE/VLua and tests.
local M = {}
function M.finite(x) return type(x) == 'number' and x == x and x > -math.huge and x < math.huge end
function M.clamp(x, lo, hi) return math.max(lo, math.min(hi, x)) end
function M.classify(config)
  local text = string.lower(table.concat({tostring(config.key or ''), tostring(config.Configuration or ''), tostring(config['Config Type'] or '')}, ' '))
  if text:find('police', 1, true) or text:find('taxi', 1, true) then return 'service' end
  if text:find('drag', 1, true) then return 'drag' end
  if text:find('rally', 1, true) then return 'rally' end
  if text:find('race', 1, true) or text:find('track', 1, true) then return 'race' end
  if text:find('sport', 1, true) or text:find('custom', 1, true) or text:find('drift', 1, true) then return 'sport' end
  return 'street'
end
-- Metadata belongs to configurations too: e.g. Grand Marshal's sedan and limo
-- share a model. Never blacklist an entire model just for one unusual body.
function M.racerEligible(config, model, modelKey)
  config, model = type(config)=='table' and config or {}, type(model)=='table' and model or {}
  local function value(key)
    local v=config[key] or model[key] or (type(config.aggregates)=='table' and config.aggregates[key])
    if type(v)=='table' then
      local values={}
      for k,x in pairs(v) do values[#values+1]=type(k)=='number' and tostring(x) or tostring(k) end
      return table.concat(values,' ')
    end
    return tostring(v or '')
  end
  local kind=value('Type'):lower()
  if not kind:find('%f[%a]car%f[%A]') and not kind:find('%f[%a]truck%f[%A]') then return false end
  if config.isAuxiliary or tostring(modelKey):find('simple',1,true) or M.classify(config)=='service' then return false end
  local body=(value('Body Style')..' '..value('Commercial Class')..' '..value('Derby Class')):lower()
  local identity=(tostring(modelKey or '')..' '..tostring(config.key or '')..' '..value('Configuration')):lower()
  local text=body..' '..identity
  for _,word in ipairs({'bus','citybus','schoolbus','coach','limo','limousine','semi','tractor','ambulance','firetruck','motorhome'}) do
    if text:find('%f[%a]'..word..'%f[%A]') then return false end
  end
  if body:find('heavy truck',1,true) or body:find('box truck',1,true) then return false end
  return true -- includes pickups, SUVs, vans and arbitrary mod folders
end
function M.profile(config, measured)
  local class = M.classify(config)
  local defaults = {street = 130, sport = 250, rally = 320, race = 450, drag = 700, service = 150}
  local performance = type(config['Performance Data'])=='table' and config['Performance Data'] or {}
  local watts = type(performance.power)=='table' and tonumber(performance.power.propulsionPowerCombined)
  local enginePower = measured and tonumber(measured.power)
  local power = enginePower
  local source = M.finite(enginePower) and enginePower>0 and 'engine' or 'catalog'
  if not M.finite(power) or power<=0 then power=tonumber(config.Power) end
  if (not M.finite(power) or power<=0) and M.finite(watts) and watts>0 then power=watts/735.499 end
  local estimated = not M.finite(power) or power <= 0
  if estimated then power = defaults[class] end
  power = M.clamp(power, 1, 10000)
  local weight = (measured and tonumber(measured.weight)) or tonumber(config.Weight) or tonumber(performance.weight) or 1400
  if not M.finite(weight) then weight = 1400 end
  weight = M.clamp(weight, 400, 6000)
  local score = power * 1000 / weight
  local willingness = ({street = 0.28, sport = 0.65, rally = 0.75, race = 0.88, drag = 0.94, service = 0})[class]
  willingness = class == 'service' and 0 or M.clamp(willingness + (score - 150) / 2000, 0.12, 0.98)
  local maximum = math.floor(M.clamp(power * 6, 250, 20000) / 50) * 50
  return {class = class, power = math.floor(power+0.5), estimated = estimated, powerSource = estimated and 'estimate' or source, willingness = willingness,
    maxBet = maximum, minBet = math.max(50, math.floor(maximum / 10 / 50) * 50), aggression = M.clamp(0.92 + score / 6000, 0.92, 1)}
end
function M.requiredReputation(power)
  return math.max(0, math.floor(((power or 0)-300)/100)*20)
end
M.racerDensities = {
  normal={label='Обычно',share=0.65,bonus=0},
  high={label='Много',share=0.90,bonus=0.40},
  maximum={label='Максимум',share=1,bonus=1}
}
function M.challengeTerms(opponentPower, playerPower)
  local required = M.requiredReputation(opponentPower)
  if not M.finite(playerPower) or playerPower <= 0 then return required, false end
  if playerPower > opponentPower*1.5 and playerPower-opponentPower > 75 then return required, true end
  if opponentPower > playerPower*1.5 and opponentPower-playerPower > 75 then
    required = math.max(required, math.ceil((opponentPower/playerPower-1)*4)*10)
  end
  return required, false
end
function M.maximumBet(balance, profile)
  if not M.finite(balance) or not profile or not M.finite(profile.maxBet) then return nil end
  local maximum = math.floor(math.min(balance, profile.maxBet)/50)*50
  if maximum < profile.minBet then return nil end
  return maximum
end
function M.reputationChange(outcome, power)
  if outcome=='win' then return 10+math.min(30,math.floor((power or 0)/100)*5) end
  if outcome=='loss' then return -10 end
  return 0
end
function M.collisionFine(speed)
  if not M.finite(speed) or speed<1 then return 0 end
  return math.floor(M.clamp(speed*speed*5,50,5000)/50)*50
end
function M.validBet(bet, balance, profile)
  return M.finite(bet) and bet == math.floor(bet) and bet % 50 == 0 and bet >= profile.minBet and bet <= profile.maxBet and bet <= balance
end
-- Reserve before starting. A win returns both stakes, a loss returns zero.
function M.payout(stake, outcome)
  if outcome == 'win' then return 2 * stake end
  if outcome == 'void' or outcome == 'draw' then return stake end
  return 0
end
-- Swept sphere intersection: do not skip the finish between frames at high speed.
function M.crossing(a, b, centre, radius)
  local dx, dy, dz = b.x-a.x, b.y-a.y, b.z-a.z
  local ox, oy, oz = a.x-centre.x, a.y-centre.y, a.z-centre.z
  local c = ox*ox + oy*oy + oz*oz - radius*radius
  if c <= 0 then return 0 end
  local aa = dx*dx + dy*dy + dz*dz
  if aa < 1e-10 then return nil end
  local bb = 2*(ox*dx + oy*dy + oz*dz)
  local disc = bb*bb - 4*aa*c
  if disc < 0 then return nil end
  local t = (-bb-math.sqrt(disc))/(2*aa)
  if t >= 0 and t <= 1 then return t end
end
-- A drag finish is a forward crossing of the timing plane within one's lane.
function M.dragCrossing(a,b,lane,direction,right)
  local function along(p)
    return (p.x-lane.finish.x)*direction.x+(p.y-lane.finish.y)*direction.y+(p.z-lane.finish.z)*direction.z
  end
  local before,after=along(a),along(b)
  if before>0 or after<0 or after-before<1e-8 then return nil end
  local t=-before/(after-before)
  local x,y,z=a.x+(b.x-a.x)*t-lane.finish.x,a.y+(b.y-a.y)*t-lane.finish.y,a.z+(b.z-a.z)*t-lane.finish.z
  if math.abs(x*right.x+y*right.y+z*right.z)>lane.halfWidth or math.abs(z)>3 then return nil end
  return t
end
function M.dragOutOfLane(p,lane,right)
  return math.abs((p.x-lane.stage.x)*right.x+(p.y-lane.stage.y)*right.y+(p.z-lane.stage.z)*right.z)>lane.halfWidth+0.5
end
function M.winner(playerT, opponentT)
  if playerT and opponentT then
    if math.abs(playerT-opponentT) < 0.001 then return 'draw' end
    return playerT < opponentT and 'win' or 'loss'
  end
  if playerT then return 'win' end
  if opponentT then return 'loss' end
end
-- Relative gameplay durability at equal speed/slip/load; stock tyre grip stays intact.
M.tyreProfiles = {
  road = {label = 'Дорожные', wear = 1.00, heat = 1.00, hot = 100},
  economy = {label = 'Экономичные', wear = 0.80, heat = 0.90, hot = 95},
  sport = {label = 'Спортивные', wear = 1.25, heat = 1.05, hot = 110},
  semi = {label = 'Полуслики', wear = 1.60, heat = 1.10, hot = 120},
  race = {label = 'Слики / гоночные', wear = 1.90, heat = 1.15, hot = 130},
  drag = {label = 'Дрэг', wear = 2.40, heat = 1.25, hot = 115},
  rally = {label = 'Раллийные', wear = 1.15, heat = 1.00, hot = 105},
  offroad = {label = 'Внедорожные', wear = 0.90, heat = 0.95, hot = 95},
  biasply = {label = 'Диагональные', wear = 1.10, heat = 1.10, hot = 90}
}
function M.tyreCompound(part)
  local override = part.streetRacersCompound
  if M.tyreProfiles[override] then return override end
  local description = part.description
  if type(description) == 'table' then description = description.description or description.name end
  local text = string.lower((part.name or '') .. ' ' .. tostring(description or ''))
  local function has(word) return text:find(word, 1, true) end
  if has('drag') then return 'drag' end
  if has('semi') then return 'semi' end
  if has('rally') then return 'rally' end
  if has('offroad') or has('off-road') or has('mud') or has('allterrain') then return 'offroad' end
  if has('slick') or has('race') or has('racing') then return 'race' end
  if has('sport') then return 'sport' end
  if has('eco') then return 'economy' end
  if has('biasply') or has('bias-ply') then return 'biasply' end
  return 'road'
end
-- Original gameplay model, not an engineering tyre simulation. Units: seconds, m/s, C.
-- Keep the distance and slip constants explicit: a quiet road trip must not
-- consume a set of tyres during one short race.
local rollingDistanceForFullWear = 2000000 -- about 2,000 km at steady road load
local slipNoiseThreshold = 1.5 -- native lastSlip is a velocity error in m/s
local slipWearScale = 100000
function M.stepTyre(state, sample, dt, multiplier, compound)
  local profile = M.tyreProfiles[compound] or M.tyreProfiles.road
  sample = type(sample) == 'table' and sample or {}
  state = type(state) == 'table' and state or {}
  dt = M.clamp(M.finite(dt) and dt or 0, 0, 0.25)
  local ambient = M.finite(sample.ambient) and M.clamp(sample.ambient, -50, 80) or 21
  local rawLoad = M.finite(sample.load) and math.max(0, sample.load) or 0
  local load = M.clamp(rawLoad / 3500, 0, 4)
  local rawSlip = M.finite(sample.slip) and math.abs(sample.slip) or 0
  local slip = M.clamp(rawSlip, 0, 100)
  local speed = M.finite(sample.speed) and M.clamp(math.abs(sample.speed), 0, 500) or 0
  if speed < 0.05 then speed = 0 end -- parked body/node jitter is not distance travelled
  if speed == 0 and M.finite(sample.wheelSpeed) and math.abs(sample.wheelSpeed) < 0.15 then slip = 0 end
  local temp = M.finite(state.temperature) and state.temperature or ambient
  temp = M.clamp(temp, ambient, 240)
  -- lastSlip contains small solver noise while a loaded wheel is rolling. Only
  -- the part above the normal-grip band contributes to tread loss.
  local excessSlip = math.max(0, slip - slipNoiseThreshold)
  local heat = load > 0.02 and (slip * load * 0.72 + speed * load * 0.0045) * profile.heat or 0
  local cooling = (temp-ambient) * (0.035 + speed*0.002)
  temp = M.clamp(temp + (heat-cooling)*dt, ambient, 240)
  -- Overheating accelerates wear, but sustained abuse is still required to fail.
  local thermalWear = 1 + M.clamp(math.max(0, temp-profile.hot), 0, 90)/180
  local wearMultiplier = M.finite(multiplier) and M.clamp(multiplier, 0, 10) or 1
  local loss = load > 0.02 and (speed/rollingDistanceForFullWear + excessSlip*excessSlip*load/slipWearScale)
       * profile.wear * thermalWear * dt * wearMultiplier or 0
  local condition = M.finite(state.condition) and state.condition or 1
  state.condition = M.clamp(condition - (M.finite(loss) and math.max(0, loss) or 0), 0, 1)
  state.temperature = temp
  return M.clamp((0.45 + 0.55*state.condition^0.6) * (1-M.clamp((temp-profile.hot-10)/500, 0, 0.2)), 0.3, 1)
end
function M.acceptWear(previous, incoming)
  if not M.finite(incoming) then return previous end
  return math.min(previous or 1, M.clamp(incoming, 0, 1))
end
return M
