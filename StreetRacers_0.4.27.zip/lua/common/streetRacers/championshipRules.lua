-- StreetRacers, 2026. MIT. Each stage uses its reward as a fixed wager.
local rules=require('streetRacers/domain')
local M={ratios={0.90,1.05,1.20,1.35,1.50}}
local multipliers={1,1.2,1.4,1.7,2}
function M.rewards(power)
  if not rules.finite(power) or power<=0 then return nil end
  local base=math.max(1000,math.min(power,10000)*5)
  local result={}
  for i,m in ipairs(multipliers) do result[i]=math.floor(base*m/50+0.5)*50 end
  return result
end
function M.create(power,inventoryId,catalog,id)
  if not rules.finite(power) or power<=0 then return nil,'Дождитесь замера мощности вашей машины.' end
  if type(catalog)~='table' or #catalog==0 then return nil,'Не найдено подходящих автомобильных конфигураций.' end
  local rewards=M.rewards(power)
  local c={economyVersion=4,id=id,inventoryId=inventoryId,playerPower=power,round=1,earned=0,bank=0,failed=false,rounds={}}
  local used,models={},{}
  for i,ratio in ipairs(M.ratios) do
    local target=math.floor(power*ratio+0.5)
    local best,score
    for _,row in ipairs(catalog) do
      local key=row.model..':'..row.config
      local cost=math.abs(math.log(math.max(1,row.power)/target))+(used[key] and 5 or 0)+(models[row.model] and 0.5 or 0)+
        (row.class and row.class~='drag' and 1 or 0)
      if not score or cost<score or (cost==score and key<best.model..':'..best.config) then best,score=row,cost end
    end
    used[best.model..':'..best.config],models[best.model]=true,true
    c.rounds[i]={model=best.model,config=best.config,name=best.name,targetPower=target,reward=rewards[i],attempts=0,status='ready'}
  end
  return c
end
function M.valid(c,legacy)
  if type(c)~='table' or c.economyVersion~=(legacy and 2 or 4) or type(c.failed)~='boolean' or not rules.finite(c.bank) or c.bank<0 or
      not rules.finite(c.id) or c.id<1 or c.id%1~=0 or not rules.finite(c.earned) or c.earned<0 or
      not rules.finite(c.inventoryId) or not rules.finite(c.playerPower) or c.playerPower<=0 or
      not rules.finite(c.round) or c.round%1~=0 or c.round<1 or c.round>6 or type(c.rounds)~='table' or #c.rounds~=5 then return false end
  local earned=0
  local rewards=legacy and {3000,4000,5000,7000,10000} or M.rewards(c.playerPower)
  for i,row in ipairs(c.rounds) do
    if type(row)~='table' or type(row.model)~='string' or type(row.config)~='string' or type(row.name)~='string' or
        not rules.finite(row.targetPower) or row.targetPower<=0 or row.reward~=rewards[i] or
        not rules.finite(row.attempts) or row.attempts<0 or row.attempts%1~=0 or
        (row.status~='ready' and row.status~='won') or (i<c.round)~=(row.status=='won') then return false end
    if row.status=='won' then earned=earned+row.reward end
  end
  if c.failed and (c.round>5 or c.rounds[c.round].lastResult~='loss') then return false end
  return c.earned==earned and (legacy and c.bank==((c.failed or c.round>5) and 0 or earned) or
    not legacy and c.bank==0 and not c.failed)
end
function M.settle(c,id,round,outcome,time)
  if not M.valid(c) or c.failed or c.id~=id or c.round~=round or round>5 then return 0,false end
  local row=c.rounds[round]
  row.attempts=row.attempts+1
  row.lastResult=outcome
  if outcome~='win' then return 0,true end
  row.status,row.time='won',rules.finite(time) and time or nil
  c.round=c.round+1
  c.earned=(c.earned or 0)+row.reward
  return row.reward,true
end
return M
