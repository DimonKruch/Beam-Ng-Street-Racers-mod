-- StreetRacers, 2026. MIT. Consume one native menu press, including its release.
local M={}
function M.new(host,hooks)
  local self={}
  local previous=hooks.trigger
  local active,suppressed=true,false
  local wrapper
  wrapper=function(name,...)
    local action,value=...
    if active and name=='UINavigation' and action=='menu' then
      if suppressed then
        if value==0 then suppressed=false end
        return
      end
      if value==1 and host.canCollapse() then
        suppressed=true
        host.collapse()
        return
      end
    end
    return previous(name,...)
  end
  hooks.trigger=wrapper
  function self.stop()
    active,suppressed=false,false
    if hooks.trigger==wrapper then hooks.trigger=previous end
  end
  return self
end
return M
