-- StreetRacers, 2026. MIT. Full vehicle configurations in the stock traffic system.
local rules = require('streetRacers/domain')
local M = {}
local buckets, profiles = nil, {}
local priorPoliceEnabled
local policeRetryAt=0
local patrolsStarted={}
local patrolsPending={}
local inspectionSerial = 0
local elapsed,scanTimer=0,0
local excluded,originalSpawn,spawnWrapper={},nil,nil
local exclusionFile='/settings/streetRacersExcludedTraffic.json'
local modSet
local reputation=0
local playerPerformance
local racerDensity='high'
-- Shared by model + configuration, owned and saved by the current career.
local wallets={}
function M.bindWallets(value) wallets=value or {} end
local models, scanQueue, queueIndex, readyRows, readyAt = {}, {}, 1, nil, -1
local function modelInfo(key)
  if not models[key] then
    local ok,data=pcall(core_vehicles.getModel,key)
    models[key]=ok and type(data)=='table' and data or {}
  end
  return models[key]
end

local function terms(p)
  readyRows=nil
  local mismatch
  p.playerPending=playerPerformance and playerPerformance.pending or false
  p.playerPower=playerPerformance and playerPerformance.power
  p.playerPowerSource=playerPerformance and playerPerformance.source
  p.requiredReputation,mismatch=rules.challengeTerms(p.power,p.playerPower)
  p.powerMaxBet=p.powerMaxBet or p.maxBet
  local account=wallets[p.fingerprint]
  if account and (type(account)~='table' or not rules.finite(account.balance) or account.balance<0) then
    wallets[p.fingerprint]=nil account=nil
  end
  if not account and not p.pending then
    account={balance=p.powerMaxBet*p.walletRaces,races=p.walletRaces}
    wallets[p.fingerprint]=account
  end
  p.wallet=account and account.balance or p.powerMaxBet*p.walletRaces
  p.walletRaces=account and (account.races==6 and 6 or 5) or p.walletRaces
  p.maxBet=math.min(p.powerMaxBet,math.floor(p.wallet/50)*50)
  p.refusal=p.wallet<p.minBet and "У соперника закончились деньги. Найдите другого водителя." or
    (mismatch and 'Ваша машина слишком мощная для этого соперника. Найдите более сильного водителя.' or nil) or
    (reputation<p.requiredReputation and ("Недостаточно репутации: нужно "..p.requiredReputation.." очков.") or nil)
  local bonus=rules.racerDensities[racerDensity].bonus
  local willingness=p.class=='service' and 0 or math.min(1,p.willingness+bonus)
  p.accepted=p.roll<willingness and not p.refusal and not p.playerPending
end
local function refreshTerms()
  readyRows=nil
  for _,p in pairs(profiles) do terms(p) end
end
function M.setReputation(value)
  reputation=value or 0
  refreshTerms()
end
function M.invalidatePlayer()
  playerPerformance=nil
  refreshTerms()
end
function M.measuredPlayerPower() return playerPerformance and not playerPerformance.pending and playerPerformance.source=='engine' and playerPerformance.power or nil end
function M.playerPower() return playerPerformance and playerPerformance.power or 150 end
function M.inspectPlayer(car)
  if not car then M.invalidatePlayer() return end
  local id=car:getID()
  if playerPerformance and playerPerformance.id==id and elapsed-playerPerformance.at<5 then return end
  local old=playerPerformance and playerPerformance.id==id and playerPerformance or nil
  local vd=core_vehicle_manager.getVehicleData(id)
  local filename=vd and vd.config and vd.config.partConfigFilename or car.partConfig
  local key=type(filename)=='string' and filename:match('([^/\\]+)%.pc$') or ''
  local config=core_vehicles.getConfig(car:getJBeamFilename(),key) or {}
  local fallback=rules.profile(config)
  inspectionSerial=inspectionSerial+1
  local token='player:'..tostring(os.time())..':'..inspectionSerial
  playerPerformance={id=id,token=token,at=elapsed,pending=not old or not old.power,
    power=old and old.power,source=old and old.source,waiting=true,fallback=fallback.power}
  refreshTerms()
  car:queueLuaCommand('extensions.load("streetRacersVehicle"); streetRacersVehicle.inspectRacer('..serialize(token)..')')
end
function M.receivePlayerPerformance(data)
  local p=playerPerformance
  if not p or not p.waiting or p.id~=data.vehicleId or p.token~=data.token or not getObjectByID(p.id) then return false end
  p.waiting,p.pending=false,false
  if rules.finite(data.power) and data.power>0 then p.power,p.source=data.power,'engine' end
  if not p.power then p.power,p.source=p.fallback,'estimate' end
  refreshTerms()
  return true
end
function M.settleWallet(key,stake,outcome)
  readyRows=nil
  local account=wallets[key]
  if not account or not rules.finite(stake) or stake<0 then return end
  account.balance=math.max(0,account.balance+(outcome=="win" and -stake or outcome=="loss" and stake or 0))
  for _,p in pairs(profiles) do if p.fingerprint==key then terms(p) end end
end
function M.settle(id,stake,outcome)
  local p=profiles[id]
  if not p then return end
  if not wallets[p.fingerprint] then wallets[p.fingerprint]={balance=p.wallet,races=p.walletRaces} end
  M.settleWallet(p.fingerprint,stake,outcome)
end
local function modSetId()
  local ok,mods=pcall(function() return core_modmanager and core_modmanager.getMods() end)
  if not ok or type(mods)~='table' then return nil end
  local entries={}
  for name,data in pairs(mods) do
    if type(data)=='table' and data.active~=false then
      local stat=type(data.stat)=='table' and data.stat or {}
      entries[#entries+1]=tostring(name)..'|'..tostring(data.filename or '')..'|'..tostring(stat.filesize or '')..'|'..tostring(stat.modtime or '')
    end
  end
  table.sort(entries)
  return table.concat(entries,'\n')
end
local function saveExclusions()
  if jsonWriteFile then jsonWriteFile(exclusionFile,{version=2,modSet=modSet,entries=excluded},true) end
end
local function exclude(model,config,reason)
  excluded[model..':'..config]=tostring(reason)
  buckets=nil
  log('W','StreetRacers','Excluded traffic '..model..'/'..config..': '..tostring(reason))
  saveExclusions()
end

function M.startGuard()
  local loaded=jsonReadFile(exclusionFile)
  modSet=modSetId()
  excluded=type(loaded)=='table' and loaded.version==2 and loaded.modSet==modSet and type(loaded.entries)=='table' and loaded.entries or {}
  if not spawn or type(spawn.spawnVehicle)~='function' or originalSpawn then return end
  originalSpawn=spawn.spawnVehicle
  spawnWrapper=function(model,config,pos,rot,options)
    if not options or options.spawnMeta~='streetRacers' then return originalSpawn(model,config,pos,rot,options) end
    local key=tostring(config):match('([^/\\]+)%.pc$') or tostring(config)
    if excluded[model..':'..key] then return nil end
    local ok,car=pcall(originalSpawn,model,config,pos,rot,options)
    if not ok or not car then exclude(model,key,ok and 'Vehicle failed to load' or car) return nil end
    return car
  end
  spawn.spawnVehicle=spawnWrapper
end

function M.exclusions() return excluded end
function M.clearExclusions()
  excluded={} buckets=nil
  modSet=modSetId()
  saveExclusions()
end
local classes = {'street', 'sport', 'race', 'rally', 'drag'}
local weights = {35, 25, 16, 14, 10}

local function catalog()
  if buckets then return end
  buckets = {street = {}, sport = {}, race = {}, rally = {}, drag = {}}
  local ok,list=pcall(core_vehicles.getConfigList)
  if not ok or type(list)~='table' or type(list.configs)~='table' then
    log('W','StreetRacers','Vehicle catalog unavailable; using stock traffic fallback.') return
  end
  for _, config in pairs(list.configs) do
    if type(config)=='table' and type(config.model_key)=='string' and type(config.key)=='string' then
    local model = tostring(config.model_key or '')
    local modelData = modelInfo(model)
    if rules.racerEligible(config,modelData.model,model) then
      local class = rules.classify(config)
      local exists=not FS or not FS.fileExists or FS:fileExists(config.pcFilename or ('/vehicles/'..model..'/'..config.key..'.pc'))
      if buckets[class] and exists and not excluded[model..':'..config.key] then table.insert(buckets[class], config) end
    end
    end
  end
end

local function randomEntry()
  catalog()
  local roll, class = math.random(100), 'street'
  for i, weight in ipairs(weights) do
    roll = roll-weight
    if roll <= 0 then class = classes[i] break end
  end
  local pool = buckets[class]
  if #pool == 0 then
    for _, key in ipairs(classes) do if #buckets[key] > 0 then pool = buckets[key] break end end
  end
  if #pool == 0 then return {model = 'covet', config = 'DXi_A'} end
  local c = pool[math.random(#pool)]
  local entry = {model = c.model_key, config = c.key,spawnMeta='streetRacers'}
  local model = modelInfo(c.model_key)
  local names = {}
  local paints=type(model.model)=='table' and model.model.paints
  for name in pairs(type(paints)=='table' and paints or {}) do names[#names+1] = name end
  if #names > 0 then
    local paint = names[math.random(#names)]
    entry.paintName, entry.paintName2, entry.paintName3 = paint, paint, paint
  end
  return entry
end

function M.invalidateCatalog()
  buckets,profiles,models,scanQueue,queueIndex=nil,{},{},{},1
  M.clearExclusions()
  readyRows=nil
end

function M.championshipCatalog()
  catalog()
  local rows={}
  for _,class in ipairs(classes) do
    for _,c in ipairs(buckets[class]) do
      local info=modelInfo(c.model_key).model or {}
      local function text(value,fallback)
        local translated=value and _tr(value)
        return type(translated)=='string' and translated or fallback
      end
      rows[#rows+1]={model=c.model_key,config=c.key,class=class,power=rules.profile(c).power,
        name=text(info.Brand,'')..' '..text(info.Name,c.model_key)..' / '..text(c.Configuration,c.key)}
    end
  end
  return rows
end

function M.register(enabled, police, density)
  if density and rules.racerDensities[density] then racerDensity=density refreshTerms() end
  gameplay_traffic.unregisterSpecialVehicleProvider('streetRacersCars')
  gameplay_traffic.unregisterSpecialVehicleProvider('streetRacersPolice')
  if not enabled then return end
  gameplay_traffic.registerSpecialVehicleProvider({
    name = 'streetRacersCars', priority = 70, minTotalAmount = 2, guaranteed = 2,
    getDesiredCount = function(total) return math.max(2, math.floor(total*rules.racerDensities[racerDensity].share)) end,
    buildGroup = function(count)
      local group = {}
      for i = 1, count do group[i] = randomEntry() end
      return group
    end
  })
  if police then
    gameplay_traffic.registerSpecialVehicleProvider({
      -- An extra reserved slot keeps a patrol even with a small civilian pool and
      -- the vanilla taxi provider. Ordinary providers replace each other's slots.
      name = 'streetRacersPolice', priority = 80, reserved = 1,
      getDesiredCount = function() return 0 end,
      buildGroup = function(count) return gameplay_traffic_trafficUtils.createPoliceGroup(count) end
    })
  end
end

local function startPatrol(id,entry)
  -- Reserve activation can discard commands queued before physics wakes up.
  -- Require two periodic observations of an active object before starting AI.
  if patrolsStarted[id]~=entry or not entry.isAi then
    if patrolsPending[id]~=entry then patrolsPending[id]=entry return end
    entry:setAiMode('traffic')
    patrolsStarted[id]=entry
    patrolsPending[id]=nil
    log('I','StreetRacers','Patrol AI started: '..id)
  end
end

function M.applyPolice(enabled)
  if priorPoliceEnabled == nil then priorPoliceEnabled = gameplay_police.enabled end
  gameplay_police.enabled = enabled
  if enabled then gameplay_traffic.useReservedVehicle('streetRacersPolice', 1) end
  for id, traffic in pairs(gameplay_traffic.getTrafficData()) do
    if traffic.role and traffic.role.name == 'police' then
      if not enabled and traffic.reserved == 'streetRacersPolice' then
        gameplay_traffic.returnReservedVehicle(id, true)
        patrolsStarted[id]=nil
        patrolsPending[id]=nil
      end
      traffic.activeProbability = enabled and 1 or 0
      local car = getObjectByID(id)
      if car then car:setActive(enabled and 1 or 0) end
    end
    if not enabled and traffic.pursuit and traffic.pursuit.mode ~= 0 then
      gameplay_police.setPursuitMode(0, id)
    end
  end
end

function M.policeStatus()
  local result={active=0,total=0,reserved=0,reserveActive=0}
  for id,entry in pairs(gameplay_traffic.getTrafficData()) do
    local car=getObjectByID(id)
    if car and entry.reserved=='streetRacersPolice' then
      result.reserved=result.reserved+1
      if entry.claimed=='streetRacersPolice' and car:getActive() then result.reserveActive=result.reserveActive+1 end
    end
    if car and entry.role and entry.role.name=='police' then
      result.total=result.total+1
      if entry.isAi and car:getActive() and (entry.alpha or 1)>=0.99 then result.active=result.active+1 end
    end
  end
  return result
end

function M.maintainPolice(enabled)
  if not enabled or not gameplay_traffic.getState or gameplay_traffic.getState()~='on' then return end
  -- Traffic can be restored or replaced after onTrafficStarted, or lose a car.
  -- Repair only our reserve, without restarting traffic or other providers.
  local status=M.policeStatus()
  if status.reserved==0 then
    if elapsed>=policeRetryAt then
      policeRetryAt=elapsed+10
      gameplay_traffic.ensureReservedVehicles('streetRacersPolice',1)
    end
    return
  end
  gameplay_traffic.useReservedVehicle('streetRacersPolice',1)
  for id,entry in pairs(gameplay_traffic.getTrafficData()) do
    if entry.reserved=='streetRacersPolice' and entry.claimed=='streetRacersPolice' then
      entry.activeProbability=1
      entry.enableRespawn=true
      local car=getObjectByID(id)
      if car and not car:getActive() then
        patrolsStarted[id]=nil
        patrolsPending[id]=nil
        car:setActive(1)
      end
      if car and car:getActive() then startPatrol(id,entry) end
    end
  end
end

function M.stop()
  if originalSpawn and spawn.spawnVehicle==spawnWrapper then spawn.spawnVehicle=originalSpawn end
  originalSpawn,spawnWrapper=nil,nil
  M.register(false)
  gameplay_traffic.removeReservedVehicles('streetRacersPolice')
  if priorPoliceEnabled ~= nil then gameplay_police.enabled = priorPoliceEnabled end
  priorPoliceEnabled, profiles, buckets = nil, {}, nil
  models,scanQueue,queueIndex={},{},1
  readyRows=nil
  playerPerformance=nil
  racerDensity='high'
  policeRetryAt=0
  patrolsStarted={}
  patrolsPending={}
  wallets={}
end

function M.profile(id)
  local car = getObjectByID(id)
  if not car then return end
  local vd = core_vehicle_manager.getVehicleData(id)
  if not vd then return end
  local model = car:getJBeamFilename()
  if tostring(model):find('simple', 1, true) then return end
  local filename = vd.config and vd.config.partConfigFilename or car.partConfig
  local key = type(filename) == 'string' and filename:match('([^/\\]+)%.pc$') or ''
  if key=='' and type(filename)=='string' and not filename:find('[{}]') then key=filename:match('([^/\\]+)$') or '' end
  local fingerprint = model .. ':' .. tostring(key)
  local cached = profiles[id]
  if cached and cached.fingerprint == fingerprint then return cached end
  local config = core_vehicles.getConfig(model, key) or {key = key}
  if not rules.racerEligible(config,modelInfo(model).model,model) then return end
  local result = rules.profile(config)
  result.fingerprint = fingerprint
  local info=modelInfo(model).model
  info=type(info)=='table' and info or {}
  local name=type(info.Name)=='string' and _tr(info.Name) or model
  local variant=type(config.Configuration)=='string' and _tr(config.Configuration) or tostring(key)
  result.name = (type(info.Brand)=='string' and info.Brand..' ' or '')..name..' / '..variant
  result.roll = math.random()
  result.walletRaces = math.random()<0.5 and 5 or 6
  result.pending = true
  terms(result)
  result.config = config
  inspectionSerial = inspectionSerial+1
  result.token = tostring(os.time())..':'..inspectionSerial
  result.pending = true
  result.age = 0
  profiles[id] = result
  car:queueLuaCommand('extensions.load("streetRacersVehicle"); streetRacersVehicle.inspectOpponent('..serialize(result.token)..')')
  return result
end

function M.update(dt,player,draw)
  elapsed,scanTimer=elapsed+dt,scanTimer+dt
  M.inspectPlayer(player)
  if playerPerformance and playerPerformance.waiting and elapsed-playerPerformance.at>=3 then
    playerPerformance.waiting,playerPerformance.pending=false,false
    if not playerPerformance.power then playerPerformance.power,playerPerformance.source=playerPerformance.fallback,'estimate' end
    refreshTerms()
  end
  for id,p in pairs(profiles) do
    if p.pending then p.age=p.age+dt if p.age>=3 then M.finishInspection(id) end end
  end
  if player and scanTimer>=1 then
    scanTimer=0
    scanQueue,queueIndex={},1
    for id,data in pairs(gameplay_traffic.getTrafficData()) do
      local car=getObjectByID(id)
      if id~=player:getID() and data.isAi and not data.reserved and data.role and data.role.name~='police' and car and car:getActive()
        then scanQueue[#scanQueue+1]=id end
    end
    table.sort(scanQueue,function(a,b)
      return getObjectByID(a):getPosition():squaredDistance(player:getPosition()) < getObjectByID(b):getPosition():squaredDistance(player:getPosition())
    end)
  end
  -- Inspect one traffic car per update, including distant active cars for the map.
  local nextId=scanQueue[queueIndex]
  if nextId then M.profile(nextId) queueIndex=queueIndex+1 end
  if not draw or not player or not debugDrawer then return end
  local ready=M.ready(player)
  local labels={street='STREET',sport='SPORT',race='TRACK',rally='RALLY',drag='DRAG'}
  for i=1,math.min(5,#ready) do
    local row=ready[i]
    if row.distance<95 then
      local p,car=row.profile,getObjectByID(row.id)
      local height=car.initialCollidableNodePosBB and car.initialCollidableNodePosBB:getExtents().z or 1.8
      local label=string.format('ГОТОВ К ЗАЕЗДУ\n%s  /  %d л.с.  /  до $%d\nГудок — вызов',labels[p.class] or 'STREET',p.power,p.maxBet)
      local alpha=rules.clamp((110-row.distance)/35,0.35,1)
      debugDrawer:drawTextAdvanced(car:getPosition()+vec3(0,0,math.max(2,height+0.6)),label,
        ColorF(0.35,0.95,0.78,alpha),true,false,ColorI(13,23,32,math.floor(225*alpha)))
    end
  end
end

function M.ready(player)
  local result={}
  if not player then return result end
  if readyRows and readyRows.playerId==player:getID() and elapsed-readyAt<0.2 then return readyRows.rows end
  local data=gameplay_traffic.getTrafficData()
  for id,p in pairs(profiles) do
    local car,entry=getObjectByID(id),data[id]
    if p.accepted and not p.pending and p.class~='service' and car and car:getActive() and entry and
      entry.isAi and not entry.reserved and entry.role and entry.role.name~='police' and (entry.alpha or 1)>=0.99 then
      result[#result+1]={id=id,profile=p,pos=car:getPosition(),distance=car:getPosition():distance(player:getPosition())}
    end
  end
  table.sort(result,function(a,b) return a.distance<b.distance end)
  readyRows,readyAt={playerId=player:getID(),rows=result},elapsed
  return result
end

function M.selectRacer(id,player)
  M.inspectPlayer(player)
  local entry=gameplay_traffic.getTrafficData()[id]
  local car=getObjectByID(id)
  if not car or not car:getActive() or id==player:getID() or not entry or not entry.isAi or
    entry.reserved or entry.claimed or not entry.role or entry.role.name=='police' or (entry.alpha or 1)<0.99 or
    (career_modules_inventory and career_modules_inventory.getInventoryIdFromVehicleId(id)) then return end
  local profile=M.profile(id)
  if not profile or profile.class=='service' or profile.pending or profile.playerPending then return end
  return id,profile
end

function M.receivePerformance(data)
  local cached = profiles[data.vehicleId]
  if not cached or not cached.pending or cached.token~=data.token or not getObjectByID(data.vehicleId) then return false end
  local result = rules.profile(cached.config,data)
  cached.powerMaxBet=result.maxBet
  for k,v in pairs(result) do cached[k]=v end
  cached.pending = false
  terms(cached)
  log('I','StreetRacers',string.format('Opponent %s power=%d source=%s bet=%d-%d',
    cached.name,cached.power,cached.powerSource,cached.minBet,cached.maxBet))
  return true
end

function M.finishInspection(id)
  local cached=profiles[id]
  if cached then cached.pending=false terms(cached) end -- freeze the quoted price; ignore late replies
end

function M.forget(id) profiles[id] = nil patrolsStarted[id]=nil patrolsPending[id]=nil readyRows=nil end

function M.nearest(player)
  M.inspectPlayer(player)
  local best, bestDist = nil, 35*35
  local pos, dir = player:getPosition(), player:getDirectionVector()
  for id, data in pairs(gameplay_traffic.getTrafficData()) do
    if id ~= player:getID() and data.isAi and data.role and data.role.name ~= 'police' and not data.reserved then
      local car = getObjectByID(id)
      if car and car:getActive() then
        local delta = car:getPosition()-pos
        local dist = delta:squaredLength()
        if dist < bestDist and delta:dot(dir) > -4 and (data.alpha or 1) >= 0.99 then
          local profile = M.profile(id)
          if profile and profile.class ~= 'service' then best, bestDist = id, dist end
        end
      end
    end
  end
  return best
end

function M.refresh()
  profiles,scanQueue,queueIndex={},{},1
  readyRows=nil
  -- Called only by an explicit menu action, not every frame.
  gameplay_traffic.setupTraffic(-1, {simpleVehs = false, allConfigs = true, autoLoadFromFile = false})
end

return M
