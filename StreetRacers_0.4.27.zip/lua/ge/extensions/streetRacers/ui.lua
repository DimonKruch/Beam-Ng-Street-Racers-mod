-- StreetRacers, 2026. MIT. Native UI: no replacement of BeamNG's Vue bundles.
local M = {}
local skin=require('ge/extensions/streetRacers/uiTheme')
local layout=require('ge/extensions/streetRacers/uiLayout')
local obstacle
local function captureWindow(im)
  local pos,size=im.GetWindowPos(),im.GetWindowSize()
  obstacle={x=pos.x,y=pos.y,w=size.x,h=size.y}
end
function M.clearBounds() obstacle=nil end
function M.tyrePosition() return obstacle end
local rules = require('streetRacers/domain')
local tab, bet, confirming = 'career', nil, nil
local seriesTrack,seriesBet,seriesTerms
local labels = {street = 'Дорожная', sport = 'Спорт / тюнинг', race = 'Кольцевая', rally = 'Раллийная', drag = 'Дрэг', service = 'Служебная'}
local phases = {idle = 'Ищем соперника', offer = 'Соперник согласен', preparing='Готовим старт...', saving = 'Готовим старт: сохранение...', staging='Расстановка машин...', countdown = 'Старт', running = 'Гонка', settling = 'Результат'}
local outcomes = {win='Победа',loss='Поражение / сход',draw='Ничья',void='Отменена'}
local function displayName(value)
  if type(value)=='string' then return value end
  if type(value)=='table' then
    local candidate=value.txt or value.text or value.name or value.translation or value.key
    return type(candidate)=='string' and candidate or 'Автомобиль'
  end
  return tostring(value or 'Автомобиль')
end

local focusOffer,positioning=true,false
function M.newOffer() bet = nil focusOffer=true positioning=false end
function M.focusOffer() focusOffer=true end
function M.selectTab(value) tab = value end

local function theme(im) return skin.push(im) end
local function untheme(im,n) skin.pop(im,n) end
local function section(im,title,subtitle)
  im.Spacing()
  im.TextColored(im.ImVec4(unpack(skin.accent)),title)
  if subtitle then im.TextWrapped(subtitle) end
end
local function primary(im,label,size)
  im.PushStyleColor2(im.Col_Button,im.ImVec4(0.58,0.27,0.06,1))
  local clicked=im.Button(label,size or im.ImVec2(-1,40))
  im.PopStyleColor()
  return clicked
end

local selectedTyres={}
local function tyreRows(im,api,v,rows,inventoryId,mode,allowed,reason)
  if not allowed and reason then im.TextWrapped(reason) end
  if #rows==0 then im.TextWrapped('Сядьте в свою машину и дождитесь считывания шин.') end
  for _,row in ipairs(rows) do
    im.Separator()
    local slot=tostring(row.part.containingSlot or ''):upper()
    local axle=slot:find('WHEEL_F',1,true) and 'Передняя ось' or (slot:find('WHEEL_R',1,true) and 'Задняя ось' or row.part.containingSlot or 'Комплект')
    local description=row.part.description
    im.TextWrapped(axle..' / '..(type(description)=='table' and description.description or description or row.part.name))
    local choices=row.choices or {{name=row.part.name,description=row.part.description,price=row.price,roadsidePrice=row.roadsidePrice,compound=row.compound}}
    local selected=choices[1]
    for _,choice in ipairs(choices) do
      if choice.name==(selectedTyres[row.token] or row.part.name) then selected=choice break end
    end
    local function name(choice)
      local d=choice.description
      return type(d)=='table' and d.description or d or choice.name
    end
    if im.BeginCombo('Модель##tyre'..row.id,name(selected)) then
      for _,choice in ipairs(choices) do
        if im.Selectable1(name(choice)..'##'..row.id..choice.name,choice.name==selected.name) then
          selectedTyres[row.token]=choice.name selected=choice confirming=nil
        end
      end
      im.EndCombo()
    end
    local profile=rules.tyreProfiles[selected.compound] or rules.tyreProfiles.road
    im.Text(string.format('%s  |  Износ x%.2f',profile.label,profile.wear))
    if #row.punctured>0 then im.TextColored(im.ImVec4(1,0.34,0.38,1),'Прокол / разрыв: '..table.concat(row.punctured,', ')) end
    local price=mode=='roadside' and selected.roadsidePrice or selected.price
    im.Text(string.format('В гараже: $%d  |  На выезде: $%d',selected.price,selected.roadsidePrice))
    im.BeginDisabled(not allowed or v.saving)
    if im.Button(string.format('Установить: $%d##tyre%d',price,row.id),im.ImVec2(-1,32)) then
      confirming={mode='tyre',id=row.id,inventoryId=inventoryId,token=row.token,price=price,model=selected.name,service=mode}
    end
    if confirming and confirming.mode=='tyre' and confirming.id==row.id and confirming.inventoryId==inventoryId then
      if confirming.token~=row.token or confirming.price~=price or confirming.service~=mode or confirming.model~=selected.name then confirming=nil
      else
        im.TextWrapped(string.format('Установить %s за $%d? Старый комплект утилизируется. %s',name(selected),price,
          mode=='roadside' and 'Включён выезд шиномонтажа.' or 'Монтаж в гараже включён.'))
        if im.Button('Купить и установить##'..row.id) then
          api.replaceTyres(inventoryId,row.id,mode,confirming.token,price,selected.name) confirming=nil
        end
        im.SameLine() if im.Button('Назад##'..row.id) then confirming=nil end
      end
    end
    im.EndDisabled()
  end
end

function M.draw(api)
  local im, v = ui_imgui, api.getView()
  if not v.active then return end
  local open = im.BoolPtr(true)
  local style=theme(im)
  -- Set a default only for a new window; preserve ImGui's user position on
  -- every frame and subsequent opening, including painting and parts shops.
  im.SetNextWindowPos(im.ImVec2(24, 24), im.Cond_FirstUseEver)
  local width,height=layout.window(im,660,740)
  im.SetNextWindowSize(im.ImVec2(width,height),im.Cond_Appearing)
  local visible = im.Begin(tab=='championship' and 'ALDER / CHAMPIONSHIP###StreetRacersChampionship' or 'STREETRACERS / WEST COAST###StreetRacers', open)
  captureWindow(im)
  if visible then
    im.TextColored(im.ImVec4(unpack(skin.accent)), string.format('$%0.0f     /     РЕПУТАЦИЯ  %d',v.money,v.state.reputation or 0))
    im.TextDisabled(string.format('ПОБЕДЫ  %d     ПОРАЖЕНИЯ  %d     ШТРАФЫ  $%.0f',v.state.stats.win,v.state.stats.loss,v.state.stats.fines or 0))
    im.TextDisabled('Esc — свернуть до HUD шин | Ctrl + Shift + S — открыть / закрыть меню')
    if v.saving then im.Text('Сохранение / обслуживание...') end
    if v.message ~= '' then im.TextWrapped(v.message) end
    im.Separator()
    if not v.state.homeGarage then
      section(im,'СТАРТОВАЯ БАЗА / BELASCO','Бесплатный гараж Belasco назначается автоматически. $15 000 на первую машину уже на счёте; покупка — у дилера.')
      im.TextWrapped('Подготавливаем место в Belasco… Остальные гаражи можно купить позже за $100 000 каждый.')
      if not v.garagePending and not v.saving and im.Button('Повторить подготовку Belasco') then api.chooseGarage('servicestationGarage') end
    else
      local nav={{'career','Карьера'},{'championship','Alder championship'},{'streetSeries','Street championship'},{'tyres','Запчасти'},{'roadside','Техпомощь'},{'settings','Настройки'}}
      local width=(im.GetContentRegionAvail().x-16)/3
      for i,item in ipairs(nav) do
        if (i-1)%3>0 then im.SameLine() end
        local selected=tab==item[1]
        if selected then im.PushStyleColor2(im.Col_Button,im.ImVec4(0.58,0.27,0.06,1)) end
        if im.Button(item[2],im.ImVec2(width,36)) then tab,confirming=item[1],nil end
        if selected then im.PopStyleColor() end
      end
      im.Separator()
      im.BeginChild1('StreetRacersContent',im.ImVec2(0,0),false)

      if tab == 'tyres' then
        section(im,'ОБСЛУЖИВАНИЕ / '..displayName(v.carName),'Выберите совместимую модель отдельно для каждой оси. Можно менять и изношенные, и проколотые шины. Вне гаража: цена ×1,5 + $150 за выезд на комплект.')
        tyreRows(im,api,v,v.tyres,v.inventoryId,v.tyreMode or 'garage',v.tyreAllowed,v.tyreReason)
        if #(v.mechanical or {})>0 then
          im.Separator()
          section(im,'РЕМОНТ УЗЛОВ','Состояние показано полосами в Tyre HUD. Переборка доступна в гараже.')
          local kindLabels={engine='Двигатель',gearbox='Коробка',differential='Редуктор',clutch='Сцепление'}
          for _,row in ipairs(v.mechanical) do
            if row.id and row.condition<=0.98 then
              im.Text(kindLabels[row.kind] or row.kind)
              im.BeginDisabled(v.saving)
              if im.Button(string.format('Переборка: $%d##component%d',row.price,row.id),im.ImVec2(-1,32)) then confirming={mode='mechanical',id=row.id,price=row.price} end
              if confirming and confirming.mode=='mechanical' and confirming.id==row.id then
                im.TextWrapped('Восстановить выбранный узел? Автомобиль должен находиться в гараже.')
                if primary(im,'Оплатить переборку##component'..row.id) then api.repairComponent(row.id,confirming.price) confirming=nil end
                if im.Button('Отмена##component'..row.id) then confirming=nil end
              end
              im.EndDisabled()
            end
          end
        end
        im.Separator()
        im.TextWrapped('Список моделей зависит от установленных колёс. Для другого размера дисков используйте магазин запчастей гаража. Снятые через магазин комплекты сохраняют износ.')
        im.Separator()
        section(im,'СКЛАД / ПРОДАЖА ДЕТАЛЕЙ','Продажа доступна, когда ваша машина находится в гараже.')
        local stored=api.getStoredParts()
        if #stored==0 then im.TextWrapped('Склад пуст. Установленные детали сначала снимите в магазине запчастей.') end
        for _,part in ipairs(stored) do
          im.TextWrapped(tostring(part.name))
          if im.Button(string.format('Продать: $%.2f##sell%d',part.price,part.id)) then
            confirming={mode='sell',id=part.id,price=part.price}
          end
          if confirming and confirming.mode=='sell' and confirming.id==part.id then
            im.TextWrapped('Продать эту снятую деталь?')
            if im.Button('Подтвердить##sell'..part.id) then api.sellPart(part.id,confirming.price) confirming=nil end
            im.SameLine()
            if im.Button('Отмена##sell'..part.id) then confirming=nil end
          end
        end
      elseif tab == 'roadside' then
        section(im,'ЭВАКУАТОР / ДО ВАШЕГО ГАРАЖА','Для машины после аварии, в том числе с оторванным колесом. Доставка сохраняет повреждения; ремонт оплачивается отдельно.')
        im.TextDisabled('$300 за вызов + $100 за каждый начатый км по прямой')
        if v.tow then
          im.Text(string.format('До базы: %.1f км     Итого: $%d',v.tow.distance/1000,v.tow.price))
          im.BeginDisabled(v.saving)
          if primary(im,'Эвакуировать в гараж##tow') then confirming={mode='tow',price=v.tow.price,vehicleId=v.tow.vehicleId} end
          if confirming and confirming.mode=='tow' then
            if confirming.vehicleId~=v.tow.vehicleId or confirming.price~=v.tow.price then confirming=nil
            else
              im.TextWrapped(string.format('Доставить эту машину в стартовый гараж за $%d?',confirming.price))
              if primary(im,'Оплатить эвакуатор##tow') then api.requestTow(confirming.price) confirming=nil end
              if im.Button('Отмена##tow') then confirming=nil end
            end
          end
          im.EndDisabled()
        elseif v.towReason then im.TextWrapped(v.towReason) end
        im.Separator()
        section(im,'ШИННЫЙ СЕРВИС / НА МЕСТЕ','Замена любой резины в любой точке карты. Выберите модель, остановитесь и оставайтесь в своей машине. На выезде: цена гаража ×1,5 + $150 на комплект. В гараже автоматически действует обычная цена.')
        tyreRows(im,api,v,v.roadsideTyres,v.roadsideInventoryId,v.roadsideMode or 'roadside',v.roadsideAllowed,v.roadsideReason)
      elseif tab == 'career' then
        section(im,'ALDER / ДРЭГ-ЧЕМПИОНАТ','Пять соперников от слабого к сильному. Ставка зависит от мощности вашей машины. Победа приносит прибыль, при поражении или сходе ставка теряется.')
        if primary(im,'Открыть чемпионат') then api.openChampionship() end
        if im.Button('GPS до Alder Drag Strip',im.ImVec2(-1,34)) then api.navigateDragStrip() end
        im.Separator()
        section(im,'УЛИЧНЫЕ ГОНКИ','Для обычного заезда задайте GPS-финиш, подъедьте к водителю трафика и подайте гудок. Соперников можно найти на карте.')
        if im.Button('Показать гонщиков на карте',im.ImVec2(-1,34)) then api.showRacersMap() end
        im.Separator()
        section(im,'БАЗА / НАВИГАЦИЯ')
        for _,garage in ipairs(api.garages()) do if garage.id==v.state.homeGarage then im.TextWrapped(garage.name) end end
        if im.Button('GPS до гаража',im.ImVec2(-1,34)) then api.navigateHome() end
        if im.Button('GPS до стартового дилера',im.ImVec2(-1,34)) then api.navigateDealer() end
        im.Separator()
        section(im,'ГАРАЖИ','Belasco — бесплатная стартовая база. Каждый дополнительный гараж стоит $100 000. Покупка открывает гаражные услуги; домашнюю базу можно сменить без переезда машины.')
        for _,garage in ipairs(api.garages()) do
          im.Separator()
          section(im,garage.name,garage.description)
          local owned=garage.starter or (v.state.ownedGarages or {})[garage.id]
          if owned then
            if v.state.homeGarage==garage.id then im.TextDisabled('Домашняя база')
            else
              im.BeginDisabled(v.saving)
              if im.Button('Сделать домашним##home'..garage.id,im.ImVec2(-1,32)) then api.setHomeGarage(garage.id) end
              im.EndDisabled()
            end
          else
            im.BeginDisabled(v.saving or v.money<garage.price)
            if im.Button('Купить за $100 000##garage'..garage.id,im.ImVec2(-1,32)) then confirming={mode='garage',id=garage.id,price=garage.price} end
            if confirming and confirming.mode=='garage' and confirming.id==garage.id then
              im.TextWrapped('Купить этот гараж за $100 000? Сумма будет списана со счёта.')
              if im.Button('Подтвердить покупку##garage'..garage.id) then api.buyGarage(garage.id,confirming.price) confirming=nil end
              im.SameLine() if im.Button('Отмена##garage'..garage.id) then confirming=nil end
            end
            im.EndDisabled()
          end
        end
      elseif tab == 'streetSeries' then
        section(im,'STREET CHAMPIONSHIP','Кольцо • спринт • драг. На своей машине, против соперников близкой мощности.')
        local busy=v.streetSeriesPhase and v.streetSeriesPhase~='idle'
        local locked=v.saving or busy or v.race.phase~='idle' or (v.championshipPhase and v.championshipPhase~='idle')
        im.BeginDisabled(locked)
        if im.BeginCombo('Моя машина##seriesCar',displayName(v.carName)) then
          for _,car in ipairs(api.getStreetSeriesCars()) do
            if im.Selectable1(displayName(car.name)..'##seriesCar'..car.id,car.id==v.inventoryId) then api.selectStreetSeriesCar(car.id) end
          end
          im.EndCombo()
        end
        local tracks=api.getStreetSeriesTracks()
        local selected
        for _,track in ipairs(tracks) do if track.id==seriesTrack then selected=track end end
        if not selected then selected=tracks[1] seriesTrack=selected and selected.id end
        local function trackName(track)
          local name=track and track.name or 'Нет доступных трасс'
          return displayName(_tr and _tr(name) or name)
        end
        if im.BeginCombo('Трасса##seriesTrack',trackName(selected)) then
          for _,track in ipairs(tracks) do
            if im.Selectable1(trackName(track)..'##seriesTrack'..track.id,track.id==seriesTrack) then
              seriesTrack=track.id seriesTerms=nil
            end
          end
          im.EndCombo()
        end
        im.EndDisabled()
        local track=seriesTrack and api.getStreetSeriesTrack(seriesTrack)
        local quote=track and api.streetSeriesQuote(seriesTrack)
        if track then
          local names={circuit='Кольцо',sprint='Спринт',drag='Драг'}
          im.Text(string.format('%s / %.2f км / кругов: %d',names[track.mode] or 'Гонка',track.length/1000,track.laps))
          im.Text(string.format('Участников: %d (вы + %d бота)',track.participants,track.participants-1))
        elseif selected then im.TextWrapped('Эта трасса не поддерживает заезд с ИИ. Выберите другую.') end
        if quote then
          local maxAffordable=math.floor(math.min(v.money,quote.maxBet)/50)*50
          local terms=seriesTrack..':'..v.inventoryId..':'..quote.maxBet
          if not seriesBet then seriesBet=im.IntPtr(math.min(1000,math.max(50,maxAffordable))) end
          if seriesTerms~=terms then seriesBet[0]=math.max(50,math.min(seriesBet[0],maxAffordable)) seriesTerms=terms end
          im.Text(string.format('Мощность двигателя: %.0f л.с. / максимум: $%d',quote.power,quote.maxBet))
          im.BeginDisabled(locked)
          im.InputInt('Ставка, $##seriesBet',seriesBet,50,500)
          im.SameLine()
          im.BeginDisabled(maxAffordable<50)
          if im.Button('Max##seriesBet') then seriesBet[0]=maxAffordable end
          im.EndDisabled()
          local pool=math.max(0,seriesBet[0])*track.participants
          im.Text(string.format('Фонд: $%d / прибыль за 1-е место: $%d',pool,pool-math.max(0,seriesBet[0])))
          im.EndDisabled()
          local valid=rules.finite(seriesBet[0]) and seriesBet[0]>=50 and seriesBet[0]%50==0 and seriesBet[0]<=maxAffordable
          local near=track.mode~='drag' or api.dragStripAvailable()
          im.BeginDisabled(locked or not valid or not near)
          if primary(im,'Начать заезд##streetSeries') then api.startStreetSeries(seriesTrack,seriesBet[0]) end
          im.EndDisabled()
          if not valid then im.TextWrapped('Введите доступную сумму с шагом $50.') end
          if not near then
            im.TextWrapped('Для драга подъедьте к регистрации Alder.')
            if im.Button('GPS до Alder##series') then api.navigateDragStrip() end
          end
        else im.TextWrapped('Сядьте в свою машину и дождитесь замера мощности двигателя.') end
        im.TextWrapped('Все участники вносят одинаковую ставку. За 1-е место вы получаете весь призовой фонд, включая свою ставку. Любое другое место или сход — потеря только своей ставки. Ничья за 1-е место и техническая отмена возвращают её. Число ботов берётся из гонки, по умолчанию — 3; в драге Alder — 1 соперник и две полосы. Остановитесь перед стартом. Расстановка сохраняет повреждения, ремонт и резина — за ваш счёт.')
        if busy then
          im.TextWrapped(v.streetSeriesPhase=='racing' and (phases[v.race.phase] or 'Заезд идёт') or 'Готовим участников и проверяем двигатели…')
          if im.Button('Отменить подготовку / сойти##series') then api.cancelStreetSeries() end
        end
      elseif tab == 'championship' then
        local c=v.state.championship
        local busy=v.championshipPhase and v.championshipPhase~='idle'
        section(im,'ALDER / CHAMPIONSHIP','400 м • 5 этапов • фиксированная ставка на каждый заезд')
        if im.Button('GPS до Alder Drag Strip',im.ImVec2(-1,32)) then api.navigateDragStrip() end
        if c and type(c.rounds)=='table' then
          im.TextWrapped(string.format('Состав под вашу машину: %.0f л.с. | Прибыль с побед: $%d',c.playerPower,c.earned or 0))
          im.TextWrapped('Перед заездом списывается ставка. Победа возвращает две ставки. При поражении или сходе ставка теряется, при ничьей или технической отмене возвращается. Повтор требует новой ставки.')
          im.ProgressBar(math.min(1,(c.round-1)/5),im.ImVec2(-1,8),'')
          im.Spacing()
          local flags=(im.TableFlags_RowBg or 0)+(im.TableFlags_BordersInnerH or 0)
          if im.BeginTable('StreetRacersChampionshipStandings',5,flags) then
            im.TableSetupColumn('#',im.TableColumnFlags_WidthFixed or 0,25)
            im.TableSetupColumn('Соперник',im.TableColumnFlags_WidthStretch or 0)
            im.TableSetupColumn('л.с.',im.TableColumnFlags_WidthFixed or 0,60)
            im.TableSetupColumn('Ставка',im.TableColumnFlags_WidthFixed or 0,70)
            im.TableSetupColumn('Статус',im.TableColumnFlags_WidthFixed or 0,105)
            im.TableHeadersRow()
            for i,row in ipairs(c.rounds) do
              im.TableNextRow()
              im.TableNextColumn() im.Text(tostring(i))
              im.TableNextColumn() im.TextWrapped(row.name)
              im.TableNextColumn() im.Text(string.format('%.0f',row.power or row.targetPower))
              im.TableNextColumn() im.Text('$'..row.reward)
              im.TableNextColumn()
              local text=row.status=='won' and 'ПОБЕДА' or (i==c.round and (c.failed and 'ПОРАЖЕНИЕ' or (busy and 'НА СТАРТЕ' or 'ВАШ ЭТАП')) or 'ДАЛЕЕ')
              im.TextColored(im.ImVec4(row.status=='won' and 0.4 or 1,row.status=='won' and 0.85 or 0.55,0.25,1),text)
              if row.time then im.TextDisabled(string.format('%.2f с',row.time))
              end
            end
            im.EndTable()
          end
          im.Spacing()
          if c.round>5 then section(im,'ЧЕМПИОНАТ ПРОЙДЕН','Все пять соперников побеждены. Прибыль за каждый этап уже выплачена.') end
          if c.round<=5 and c.rounds[c.round].lastResult=='loss' then section(im,'ПОВТОР ЭТАПА','Ставка проиграна. Прогресс сохранён; повтор этапа требует новую ставку.') end
        else
          im.TextWrapped('Состав подбирается по замеренной мощности вашей машины: от 90% до 150%. Для 100–200 л.с. ставки $1000–2000, для 1000 л.с. — $5000–10 000. Победа приносит чистую прибыль в размере ставки. При поражении ставка теряется.')
        end
        local stake=c and c.rounds[c.round] and c.rounds[c.round].reward or 1000
        im.BeginDisabled(v.saving or busy or v.race.phase~='idle' or v.money<stake or not api.dragStripAvailable())
        if primary(im,c and c.failed and 'Начать заново' or (c and c.round<=5 and 'Начать следующий этап' or 'Начать чемпионат')) then api.startChampionshipRound() end
        im.EndDisabled()
        if v.money<stake then im.TextWrapped('Недостаточно денег для ставки этапа: $'..stake..'.') end
        if not api.dragStripAvailable() then im.TextWrapped('Подъедьте к оранжевому маркеру регистрации у старта Alder.') end
        if busy then
          im.TextWrapped(v.championshipPhase=='racing' and (phases[v.race.phase] or 'Этап идёт') or 'Загружаем машину и проверяем реальную мощность двигателя…')
          if im.Button('Прервать подготовку / этап',im.ImVec2(-1,32)) then
            if v.race.phase~='idle' then api.cancelRace() else api.cancelChampionshipPreparation() end
          end
        end
        if c then
          im.BeginDisabled(v.saving or busy or v.race.phase~='idle')
          if im.Button('Новый состав под мою машину',im.ImVec2(-1,30)) then confirming={mode='restartChampionship'} end
          if confirming and confirming.mode=='restartChampionship' then
            im.TextWrapped('Сбросить таблицу и подобрать новый состав? Баланс и результаты прошлых заездов не изменятся.')
            if im.Button('Сбросить таблицу') then api.resetChampionship() confirming=nil end
            im.SameLine() if im.Button('Отмена##championship') then confirming=nil end
          end
          im.EndDisabled()
        end
      elseif tab == 'settings' then
        section(im,'ИНТЕРФЕЙС / ПОДСКАЗКИ')
        local torque=im.BoolPtr(v.state.settings.torqueCurve~=false)
        if im.Checkbox('График мощности и крутящего момента',torque) then api.setTorqueCurve(torque[0]) end
        im.TextWrapped('Штатный Torque Curve появляется за рулём своей машины в карьере.')
        local tyreHud = im.BoolPtr(v.state.settings.tyreHud)
        if im.Checkbox('Панель шин и узлов', tyreHud) then api.setTyreHud(tyreHud[0]) end
        im.TextWrapped('Появляется автоматически за рулём своей машины. Перетащите панель за заголовок, чтобы изменить положение.')
        local racers=im.BoolPtr(v.state.settings.racerMarkers~=false)
        if im.Checkbox('Отмечать готовых гоняться водителей',racers) then api.setRacerMarkers(racers[0]) end
        im.Separator()
        section(im,'ТРАФИК / ГОТОВНОСТЬ ВОДИТЕЛЕЙ')
        for i,key in ipairs({'normal','high','maximum'}) do
          if i>1 then im.SameLine() end
          local density=rules.racerDensities[key]
          local selected=v.state.settings.racerDensity==key
          if im.Button((selected and '> ' or '')..density.label..'##density'..key) then api.setRacerDensity(key) end
        end
        im.TextWrapped('«Много» включено по умолчанию. «Максимум»: все подходящие по мощности и репутации водители готовы гоняться, пока у них есть деньги. После смены режима обновите трафик для нового состава.')
        im.Separator()
        local enabled = im.BoolPtr(v.state.settings.police)
        if im.Checkbox('Полиция', enabled) then api.setPolice(enabled[0]) end
        local patrols=api.getPoliceStatus and api.getPoliceStatus()
        if patrols then
          im.TextWrapped(v.state.settings.police and string.format('Полиция включена. Активных патрулей: %d из %d.',patrols.active,patrols.total) or 'Полиция отключена.')
        end
        im.TextWrapped('Один дополнительный патруль поддерживается автоматически. Он ездит по карте и не обязан находиться рядом. Изменение доступно между гонками.')
        if im.Button('Обновить трафик', im.ImVec2(-1, 36)) then api.refreshTraffic() end
        for config,reason in pairs(v.excludedTraffic or {}) do im.TextWrapped('Исключено: '..config..' — '..reason) end
        if next(v.excludedTraffic or {}) and im.Button('Повторно разрешить исключённые машины') then api.clearTrafficExclusions() end
        im.TextWrapped('Обновление заменяет только дорожный трафик и может занять несколько секунд. Обычные, спортивные, кольцевые, раллийные и дрэг-конфигурации выбираются из машин, установленных в игре.')
        im.Separator()
        im.TextDisabled('StreetRacers 0.4.26 alpha / BeamNG.drive 0.40')
        im.TextWrapped('Уличная карьера на West Coast USA. Гоняйтесь на своей машине, выбирайте ставки и следите за состоянием шин.')
      end
      im.EndChild()
    end
  end
  im.End()
  untheme(im,style)
  if not open[0] then api.closeMenu() end
end

-- Contextual invitation: appears only after a driver accepts the horn challenge.
function M.drawOffer(api)
  local im,v=ui_imgui,api.getView()
  local r=v.race
  if r.profile and (r.profile.championshipId or r.profile.streetSeries) then return end
  if not v.active or (r.phase~='offer' and r.phase~='preparing' and r.phase~='saving') then return end
  local open=im.BoolPtr(true)
  local style=theme(im)
  local compact=positioning and r.phase=='offer'
  local width,height=layout.window(im,compact and 390 or 580,compact and 210 or 640)
  im.SetNextWindowPos(im.ImVec2(24,24),im.Cond_FirstUseEver)
  im.SetNextWindowSize(im.ImVec2(width,height),im.Cond_Always)
  if focusOffer then im.SetNextWindowFocus() focusOffer=false end
  local visible=im.Begin((r.mode=='drag' and 'ALDER / ДРЭГ НА ДЕНЬГИ' or 'УЛИЧНЫЙ ЗАЕЗД')..'###StreetRacersOffer',open,im.WindowFlags_NoCollapse)
  captureWindow(im)
  if visible then
    if compact then
      im.TextWrapped(v.startZone and v.startZone.text or 'Выберите GPS-финиш, чтобы увидеть зону старта.')
      if im.Button('Вернуться к ставке',im.ImVec2(-1,36)) then positioning=false end
      if im.Button('Отменить заезд',im.ImVec2(-1,30)) then api.cancelRace() end
    else
    local pending=(r.profile.pending or r.profile.playerPending) and r.phase=='offer'
    -- Instructions and long messages scroll; bet, Max and Start remain outside
    -- that child region and cannot disappear below its scrollbar.
    local footer=100+(im.GetFontSize and im.GetFontSize() or 13)*3
    local bodyHeight=math.max(1,im.GetContentRegionAvail().y-footer)
    local body=im.BeginChild1('StreetRacersOfferDetails',im.ImVec2(0,bodyHeight),false)
    if body then
      im.TextColored(im.ImVec4(unpack(skin.accent)),phases[r.phase])
      im.TextWrapped(displayName(r.profile.name))
      if pending then
        im.TextWrapped('Определяем мощность обеих машин и условия ставки…')
      else
        im.Text(string.format('%s / %s%d л.с.',labels[r.profile.class] or r.profile.class,r.profile.estimated and '~' or '',r.profile.power))
        if r.profile.playerPower then
          im.Text(string.format('Ваша машина: %s%.0f л.с.',r.profile.playerPowerSource=='engine' and '' or '~',r.profile.playerPower))
        end
        im.Text(string.format('На счету: $%.0f',v.money))
        im.TextWrapped(string.format('Банк этой модели / комплектации: $%d | Репутация: от %d',r.profile.wallet or 0,r.profile.requiredReputation or 0))
        if r.phase=='offer' then
          im.Text(string.format('Ставка: $%d — $%d. Шаг: $50.',r.profile.minBet,r.profile.maxBet))
          if r.mode=='drag' then
            im.TextColored(im.ImVec4(unpack(skin.accent)),'DRAG STRIP / ALDER')
            im.TextWrapped('Штатная прямая West Coast USA, старт с двух полос, финиш по штатной линии (около 400 м). Выезд из своей полосы — сход. Машины будут доставлены к реальной стартовой линии трассы.')
            if im.Button('Вернуться к уличной гонке',im.ImVec2(-1,36)) then api.selectRaceMode('street') end
          else
            im.TextWrapped('Выберите GPS-финиш на дороге (0,3–25 км), закройте карту и остановитесь перед стартом.')
            if im.Button('Выбрать финиш на карте',im.ImVec2(-1,36)) then api.openMap() end
          end
          if v.startZone then
            im.TextColored(im.ImVec4(v.startZone.valid and 0.3 or 1,v.startZone.valid and 0.9 or 0.48,0.2,1),
              v.startZone.valid and 'ЗОНА СТАРТА ГОТОВА' or 'ВЫБЕРИТЕ ЗОНУ СТАРТА')
            im.TextWrapped(v.startZone.text)
          end
          if im.Button('Свернуть для подъезда к старту',im.ImVec2(-1,32)) then positioning=true end
          im.TextWrapped('Победа: прибыль равна ставке. Проигрыш: ставка потеряна. Выход из сохранённого заезда считается сходом.')
        else
          im.Text(string.format('Ставка: $%d',r.stake or r.requestedBet or 0))
          im.TextWrapped('Старт принят. Подготовка, сохранение и обратный отсчёт выполняются автоматически.')
        end
      end
      if v.message~='' then im.TextWrapped(v.message) end
    end
    im.EndChild()
    im.Separator()
    if r.phase=='offer' and not pending then
      if not bet then bet=im.IntPtr(r.profile.minBet) end
      im.SetNextItemWidth(math.max(80,im.GetContentRegionAvail().x-160))
      im.InputInt('Ставка, $',bet,50,250)
      local maximum=rules.maximumBet(v.money,r.profile)
      im.SameLine()
      im.BeginDisabled(not maximum)
      if im.Button('Max',im.ImVec2(56,0)) and maximum then bet[0]=maximum end
      im.EndDisabled()
      if primary(im,'Старт',im.ImVec2(-1,42)) then api.startRace(bet[0]) end
    end
    if im.Button('Отменить заезд',im.ImVec2(-1,30)) then api.cancelRace() end
    end
  end
  im.End()
  untheme(im,style)
  if not open[0] then api.cancelRace() end
end

function M.hud(api)
  local im, v = ui_imgui, api.getView()
  local style=theme(im)
  if v.countdown then
    local display=layout.viewport(im)
    im.SetNextWindowPos(im.ImVec2(display.x*0.5,display.y*0.34),im.Cond_Always,im.ImVec2(0.5,0.5))
    im.SetNextWindowBgAlpha(0.88)
    local flags=im.WindowFlags_NoDecoration + im.WindowFlags_NoSavedSettings + im.WindowFlags_AlwaysAutoResize
    if im.WindowFlags_NoFocusOnAppearing then flags=flags+im.WindowFlags_NoFocusOnAppearing end
    im.Begin('StreetRacers — отсчёт###StreetRacersCountdown',nil,flags)
    im.PushStyleColor2(im.Col_Text,im.ImVec4(unpack(skin.accent)))
    if im.SetWindowFontScale then im.SetWindowFontScale(2.8) end
    im.Text(v.countdown=='GO!' and 'GO!' or tostring(v.countdown))
    if im.SetWindowFontScale then im.SetWindowFontScale(1) end
    im.PopStyleColor()
    im.End()
  end
  im.SetNextWindowPos(im.ImVec2(24,24),im.Cond_FirstUseEver)
  im.SetNextWindowSize(im.ImVec2(320,130),im.Cond_FirstUseEver)
  im.Begin('StreetRacers — гонка###StreetRacersHUD', nil, im.WindowFlags_NoCollapse + im.WindowFlags_AlwaysAutoResize)
  captureWindow(im)
  im.Text(phases[v.race.phase] or '')
  if v.race.stake then im.Text(string.format('Ставка $%d  /  %.1f с', v.race.stake, v.race.elapsed or 0)) end
  if v.streetSeriesProgress then
    local p=v.streetSeriesProgress
    im.Text(string.format('Круг %d/%d / место %d из %d',p.lap,p.laps,p.place or 0,p.participants))
    im.Text(string.format('Призовой фонд: $%d',p.prizePool))
  end
  if v.race.phase=='running' and im.Button('Сойти — потерять ставку') then api.cancelRace() end
  im.End()
  untheme(im,style)
end
return M
