-- StreetRacers, 2026. MIT. Confirm pair contact and use motion before impact.
local M={}
local function snapshot(car)
  return {pos=vec3(car:getSpawnWorldOOBB():getCenter()),vel=vec3(car:getVelocity()),dir=vec3(car:getDirectionVector())}
end
function M.responsible(p,o)
  if not p or not o then return false,0 end
  local delta=o.pos-p.pos
  if delta:length()<0.1 then return false,0 end
  local normal=delta:normalized()
  local approachP=p.vel:dot(normal)
  local approachO=-o.vel:dot(normal)
  local closing=approachP+approachO
  if approachP<=2 or closing<=1 then return false,0 end
  local along=delta:dot(p.dir)
  local side=(delta-p.dir*along):length()
  -- A faster following bot hitting the player's rear is never a player ram.
  if p.dir:dot(o.dir)>0.5 and along>0.5 and side<2.5 then return true,closing end
  -- Reverse/side impacts need clear evidence the player moved into the other car.
  return approachP>approachO+2,closing
end
local function overlaps(a,b)
  local x,y=a:getSpawnWorldOOBB(),b:getSpawnWorldOOBB()
  local ex,ey=x:getHalfExtents(),y:getHalfExtents()
  return overlapsOBB_OBB(x:getCenter(),x:getAxis(0)*ex.x,x:getAxis(1)*ex.y,x:getAxis(2)*ex.z,
    y:getCenter(),y:getAxis(0)*ey.x,y:getAxis(1)*ey.y,y:getAxis(2)*ey.z)
end
function M.new()
  local previous={}
  local self={}
  function self.reset() previous={} end
  function self.sample(playerId,ids)
    local player=getObjectByID(playerId)
    if not player then self.reset() return false,0 end
    local p=snapshot(player)
    local nextSamples,charge,speed={},false,0
    for _,id in ipairs(ids) do
      local car=getObjectByID(id)
      if car then
        local pa,pb=map.objects and map.objects[playerId],map.objects and map.objects[id]
        local reported=(pa and pa.objectCollisions and pa.objectCollisions[id]==1) or
          (pb and pb.objectCollisions and pb.objectCollisions[playerId]==1)
        -- The map flag alone can outlive the impact. Require the actual pair's OBBs.
        local hit=reported and overlaps(player,car) or false
        local old=previous[id]
        if hit and old and not old.hit and old.car==car and old.player==player then
          local liable,closing=M.responsible(old.p,old.o)
          if liable then charge=true speed=math.max(speed,closing) end
        end
        nextSamples[id]={p=p,o=snapshot(car),hit=hit,car=car,player=player}
      end
    end
    previous=nextSamples
    return charge,speed
  end
  return self
end
return M
