-- StreetRacers, 2026. MIT. Read-only geometry of the stock West Coast drag strip.
local M={}
local cached
local path='/levels/west_coast_usa/dragstrips/alderStrip_main.strip.json'
local function point(t)
  if type(t)~='table' then return end
  local p=t.position
  if type(p)~='table' then return end
  for _,k in ipairs({'x','y','z'}) do
    if type(p[k])~='number' or p[k]~=p[k] or math.abs(p[k])>100000 then return end
  end
  return vec3(p.x,p.y,p.z)
end
function M.clear() cached=nil end
function M.info()
  if getCurrentLevelIdentifier()~='west_coast_usa' then return nil,'Alder Drag Strip находится на West Coast USA.' end
  if cached then return cached end
  local ok,data=pcall(jsonReadFile,path)
  if not ok or type(data)~='table' or type(data.lanes)~='table' then
    return nil,'Не удалось прочитать штатную трассу Alder Drag Strip.'
  end
  local lanes={}
  for _,row in ipairs(data.lanes) do
    local lane={}
    for _,wp in ipairs(row.waypoints or {}) do
      if wp.type=='stage' then lane.stage=point(wp.transform)
      elseif wp.type=='endLine' then lane.finish=point(wp.transform) end
    end
    local scale=row.boundary and row.boundary.transform and row.boundary.transform.scale
    lane.halfWidth=scale and type(scale.x)=='number' and math.abs(scale.x) or 0
    if not lane.stage or not lane.finish or lane.halfWidth<1.5 or lane.halfWidth>8 then
      return nil,'Повреждена геометрия полос Alder Drag Strip.'
    end
    lanes[#lanes+1]=lane
  end
  if #lanes~=2 then return nil,'Для дрэга нужны две полосы Alder Drag Strip.' end
  local start=(lanes[1].stage+lanes[2].stage)*0.5
  local finish=(lanes[1].finish+lanes[2].finish)*0.5
  local direction=(finish-start):normalized()
  local length=start:distance(finish)
  if length<390 or length>420 then return nil,'Неожиданная длина Alder Drag Strip.' end
  local right=direction:cross(vec3(0,0,1)):normalized()
  for _,lane in ipairs(lanes) do
    -- Equal start and finish planes, even when the map's individual markers differ slightly.
    lane.stage=lane.stage-direction*((lane.stage-start):dot(direction))
    lane.finish=lane.stage+direction*length
  end
  cached={lanes=lanes,start=start,finish=finish,direction=direction,right=right,length=length}
  return cached
end
return M
