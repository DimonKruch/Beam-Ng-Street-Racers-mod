-- StreetRacers, 2026. MIT. A temporary addition to the active career layout.
local M={}
local applied,original,askedVehicle,lastApi,lastLayout
local listOwner,listOriginal,listWrapper
local function api()
  return ui_appLayouts or (extensions and extensions.ui_appLayouts)
end
local function hasGraph(layout)
  for _,app in ipairs(layout and layout.apps or {}) do
    if app.appName=='streetRacersTorqueCurve' or app.appName=='torqueCurve' or app.appName=='torqueCurve2' then return true end
  end
  return false
end
local function withGraph(layout)
  if not layout or layout.type~='career' then return layout end
  if hasGraph(layout) then return layout end
  local result=deepcopy(layout)
  result.apps=result.apps or {}
  result.apps[#result.apps+1]={appName='streetRacersTorqueCurve',
    placement={left='290px',bottom='20px',width='420px',height='250px'}}
  return result
end
local function publish(api)
  if type(api.getAvailableLayouts)~='function' then return end
  if listOwner==api then return end
  if listOwner and listOwner.getAvailableLayouts==listWrapper then
    listOwner.getAvailableLayouts=listOriginal
  end
  listOwner,listOriginal=api,api.getAvailableLayouts
  local originalList=listOriginal
  listWrapper=function(...)
    local layouts=originalList(...)
    if not listOwner then return layouts end
    local result={}
    for i,layout in ipairs(layouts or {}) do result[i]=withGraph(layout) end
    return result
  end
  api.getAvailableLayouts=listWrapper
  if guihooks then guihooks.trigger('UiAppLayoutsChanged') end
end
local function requestCurve()
  local car=getPlayerVehicle and getPlayerVehicle(0)
  if not car or not car.getID or not car.queueLuaCommand then return end
  local id=car:getID()
  if askedVehicle==id then return end
  askedVehicle=id
  -- TorqueCurve subscribes to this event. Career vehicles often emit it
  -- before the career layout is mounted, so request one fresh snapshot.
  pcall(car.queueLuaCommand,car,'controller.mainController.sendTorqueData()')
end
function M.stop()
  if listOwner then
    if listOwner.getAvailableLayouts==listWrapper then listOwner.getAvailableLayouts=listOriginal end
    listOwner,listOriginal,listWrapper=nil,nil,nil
    if guihooks then guihooks.trigger('UiAppLayoutsChanged') end
  end
  local layouts=api()
  if layouts and applied and layouts.getCurrentLayout()==applied then layouts.setCurrentLayout(original) end
  applied,original,askedVehicle,lastApi,lastLayout=nil,nil,nil,nil,nil
end
function M.update(enabled)
  if not enabled then M.stop() return end
  local layouts=api()
  if not layouts or not layouts.getCurrentLayout then return end
  if layouts~=lastApi then
    lastApi=layouts
    askedVehicle=nil
    lastLayout=nil
  end
  -- 0.40's Vue app container resolves the current layout against this list.
  -- Publish the same temporary graph in both APIs, without rewriting the
  -- user's on-disk layout or affecting mission/map/pause layouts.
  publish(layouts)
  local layout=layouts.getCurrentLayout()
  if not layout or layout.type~='career' then return end
  if hasGraph(layout) then
    if layout~=lastLayout then askedVehicle=nil end
    lastLayout=layout
    requestCurve()
    return
  end
  original=layout
  applied=withGraph(layout)
  layouts.setCurrentLayout(applied)
  if guihooks then guihooks.trigger('appContainer:loadLayoutByObject',applied) end
  lastLayout=applied
  requestCurve()
end
return M
