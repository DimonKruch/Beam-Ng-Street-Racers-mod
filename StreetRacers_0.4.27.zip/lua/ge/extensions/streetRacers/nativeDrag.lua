-- StreetRacers, 2026. MIT. Own the freeroam strip only while this career is active.
local M={}
local entries={}
local enabled=false
local function blocked()
  if not enabled or getCurrentLevelIdentifier()~='west_coast_usa' then return false end
  -- The career performance certification uses the same native drag core, but
  -- it is a measured test rather than the freeroam activity we suppress for
  -- StreetRacers.  Let the certification own the core while it is running.
  local performance=career_modules_vehiclePerformance
  if performance and performance.isTestInProgress then
    local ok,r=pcall(performance.isTestInProgress)
    if ok and r then return false end
  end
  local mm=gameplay_missions_missionManager
  if mm and mm.getForegroundMissionId() then return false end
  local core=gameplay_drag_core
  return not core or not core.getGameplayContext or core.getGameplayContext()=='freeroam'
end
local function invalidate()
  if gameplay_rawPois and gameplay_rawPois.clear then gameplay_rawPois.clear() end
end
local function wrap(owner,key,fallback)
  if not owner or type(owner[key])~='function' then return end
  local original=owner[key]
  local wrapper=function(...)
    if blocked() then return fallback end
    return original(...)
  end
  entries[#entries+1]={owner=owner,key=key,original=original,wrapper=wrapper}
  owner[key]=wrapper
end
function M.start()
  if enabled then return end
  enabled=true
  local core=gameplay_drag_core
  -- isDragEnabled suppresses freshly generated POIs. The entry point guards
  -- also stop callbacks retained in an existing invisible-trigger cache.
  wrap(core,'isDragEnabled',false)
  wrap(core,'setDragRaceData',false)
  wrap(core,'startDragRaceActivity',false)
  if blocked() and core and core.getData and core.getData() and core.clear then
    core.clear({hooks=true,transitionLock=true,localRace=true,extensions=true,data=true,context=true,ui=true,treeLightStaging=true})
  end
  invalidate()
end
function M.stop()
  if not enabled then return end
  enabled=false
  for _,entry in ipairs(entries) do
    if entry.owner[entry.key]==entry.wrapper then entry.owner[entry.key]=entry.original end
  end
  entries={}
  invalidate()
end
return M
