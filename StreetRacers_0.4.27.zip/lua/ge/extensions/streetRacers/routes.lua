-- StreetRacers, 2026. MIT. All route data comes from the loaded map's navigation graph.
local M = {}
local rules = require('streetRacers/domain')
local dragStrip=require('ge/extensions/streetRacers/dragStrip')
local extents
function M.dragStripInfo() return dragStrip.info() end
function M.dragStartZone(player,opponent)
  local info,why=dragStrip.info()
  if not info then return {valid=false,text=why} end
  local distance=player and player:getPosition():distance(info.start) or math.huge
  local pos=player and player:getPosition() or info.start
  local playerLane=pos:squaredDistance(info.lanes[1].stage)+0.01<pos:squaredDistance(info.lanes[2].stage) and 1 or 2
  local opponentLane=3-playerLane
  local widthP,widthO=extents(player).x,extents(opponent).x
  local fits=widthP+0.6<info.lanes[playerLane].halfWidth*2 and widthO+0.6<info.lanes[opponentLane].halfWidth*2
  local grid={playerPos=info.lanes[playerLane].stage+vec3(0,0,0.3),opponentPos=info.lanes[opponentLane].stage+vec3(0,0,0.3),
    rotation=quatFromDir(info.direction,vec3(0,0,1)),direction=info.direction,right=info.right,
    centre=info.start,separation=info.lanes[1].stage:distance(info.lanes[2].stage),
    widthP=widthP,widthO=widthO,lengthP=math.max(4,extents(player).y+1),lengthO=math.max(4,extents(opponent).y+1)}
  return {valid=distance<=110 and fits,grid=grid,distance=distance,playerLane=playerLane,opponentLane=opponentLane,
    text=not fits and 'Машина слишком широкая для полосы Alder Drag Strip.' or
      (distance<=110 and string.format('Alder Drag Strip: прямая %.0f м, две отдельные полосы. Старт готов.',info.length) or
      string.format('До старта Alder Drag Strip %.0f м. Подъедьте ближе (до 110 м).',distance))}
end
function M.fromDragStrip(player,opponent)
  local info=dragStrip.info()
  local zone=M.dragStartZone(player,opponent)
  if not zone.valid then return nil,zone.text end
  return {kind='drag',path={},finish=info.finish,length=info.length,grid=zone.grid,drag=info,playerLane=zone.playerLane,opponentLane=zone.opponentLane,initialPlayerLane=zone.playerLane}
end
function M.dragAI(route)
  local lane=route.drag.lanes[route.opponentLane]
  -- A private straight graph prevents GPS pathfinding from joining the return road.
  -- Continue beyond the finish so native AI never brakes before the timing line.
  local points={}
  for _,distance in ipairs({8,60,160,280,route.length,route.length+180,route.length+320}) do
    local p=lane.stage+route.drag.direction*distance
    points[#points+1]={x=p.x,y=p.y,z=p.z,r=lane.halfWidth-0.5}
  end
  return points
end

local function roadPoint(pos, nodes)
  local a, b, distance = map.findClosestRoad(pos)
  if not a or not b or not nodes[a] or not nodes[b] or distance > 45 then return end
  local segment = nodes[b].pos-nodes[a].pos
  local t = rules.clamp((pos-nodes[a].pos):dot(segment)/math.max(0.001,segment:squaredLength()),0,1)
  return nodes[a].pos+segment*t, a, b
end

function M.fromGPS(player)
  local target = core_groundMarkers.getTargetPos()
  if not target then return nil, 'Сначала поставьте точку GPS на карте.' end
  local nodes = map.getMap().nodes
  if type(target) == 'string' then target = nodes[target] and nodes[target].pos end
  if not target then return nil, 'Недоступная точка GPS.' end
  target = vec3(target)
  local start = player:getPosition()
  local startPoint = roadPoint(start, nodes)
  local finish, endA, endB = roadPoint(target, nodes)
  if not startPoint or not finish then return nil, 'Старт и финиш должны быть у дорог (до 45 м).' end
  local path = map.getPointToPointPath(startPoint, finish, 0.5, 10)
  if not path or #path < 2 or (path[#path] ~= endA and path[#path] ~= endB) then return nil, 'Не найден связный автомобильный маршрут.' end
  -- Point-to-point paths finish with the edge containing the destination. Append its
  -- other endpoint when needed so AI drives THROUGH the GPS finish rather than stopping early.
  local last = path[#path]
  if last == endA and path[#path-1] ~= endB then path[#path+1] = endB
  elseif last == endB and path[#path-1] ~= endA then path[#path+1] = endA end
  local length = startPoint:distance(nodes[path[1]].pos)
  for i=2,#path-1 do length = length+nodes[path[i-1]].pos:distance(nodes[path[i]].pos) end
  length = length+nodes[path[#path-1]].pos:distance(finish)
  if length < 300 or start:distance(finish) < 200 then return nil, 'Маршрут слишком короткий: минимум 300 м.' end
  if length > 25000 then return nil, 'Максимальная длина маршрута — 25 км.' end
  return {path = path, finish = finish, length = length,
    radius = rules.clamp(math.min(nodes[endA].radius or 8, nodes[endB].radius or 8), 8, 16)}
end

extents=function(car)
  -- BeamNG safeTeleport uses collision nodes; decorative/non-colliding nodes
  -- can make initialNodePosBB much wider than the physical vehicle.
  local box=car and (car.initialCollidableNodePosBB or car.initialNodePosBB)
  local size=box and box:getExtents()
  if size and rules.finite(size.x) and size.x>0.2 and rules.finite(size.y) and size.y>0.5 then return size end
  return vec3(2,5,2)
end

local function projection(pos,a,b)
  local edge=b-a
  local t=(pos-a):dot(edge)/math.max(edge:squaredLength(),0.001)
  return rules.clamp(t,0,1),t
end

-- Only the beginning of the route can contain the grid. A later crossing of the
-- same road must not skip half the race. Distances include height (overpasses).
local function routeSegment(pos,route,nodes)
  local best,distance,travel= nil,math.huge,0
  for i=1,#(route.path or {})-1 do
    local a,b=nodes[route.path[i]],nodes[route.path[i+1]]
    if not a or not b then return end
    local edge=b.pos-a.pos
    local t,raw=projection(pos,a.pos,b.pos)
    local d=pos:squaredDistance(a.pos+edge*t)
    if d<distance-0.01 then best,distance={index=i,t=t,raw=raw,direction=edge:normalized()},d end
    travel=travel+edge:length()
    if travel>200 then break end
  end
  return best,distance
end

local function edgeGrid(pos,na,nb,widthP,widthO,direction,maxShift)
  local segment = nb.pos-na.pos
  if segment:length()<0.1 then return end
  local t=projection(pos,na.pos,nb.pos)
  local separation = (widthP+widthO)*0.5+0.65
  local requiredWidth=widthP+widthO+0.95
  local r1,r2=na.radius or 3,nb.radius or 3
  if (r1*(1-t)+r2*t)*2<requiredWidth then
    if math.max(r1,r2)*2<requiredWidth or math.abs(r2-r1)<0.001 then return end
    -- Solve the tapered edge exactly; sampling every 10 m could miss a valid strip.
    local candidate=rules.clamp((requiredWidth*0.5+0.01-r1)/(r2-r1),0,1)
    if math.abs(candidate-t)*segment:length()>maxShift then return end
    t=candidate
  end
  local centre=na.pos+segment*t
  if direction:dot(segment)<0 then direction=-segment:normalized() else direction=segment:normalized() end
  local right = direction:cross(vec3(0,0,1)):normalized()
  local playerPos = centre-right*(separation*0.5)+vec3(0,0,0.3)
  local opponentPos = centre+right*(separation*0.5)+vec3(0,0,0.3)
  -- safeTeleport performs the vehicle's 180-degree reference-axis adjustment itself.
  local rotation = quatFromDir(direction, vec3(0,0,1))
  return {playerPos = playerPos, opponentPos = opponentPos, rotation = rotation, direction = direction,
    right = right, separation = separation,centre=centre,roadWidth=(r1*(1-t)+r2*t)*2,requiredWidth=requiredWidth,
    widthP=widthP,widthO=widthO}
end

function M.grid(player, opponent, route)
  local nodes = map.getMap().nodes
  local pos=player:getPosition()
  local a,b,roadDist=map.findClosestRoad(pos)
  if not a or not b or not nodes[a] or not nodes[b] or roadDist>15 then return nil,'Остановитесь на дороге перед стартом.' end
  local segment=routeSegment(pos,route,nodes)
  if not segment then return nil,'Маршрут старта недоступен.' end
  local grid=edgeGrid(pos,nodes[a],nodes[b],extents(player).x,extents(opponent).x,segment.direction,50)
  if not grid then return nil,'Дорога слишком узкая для двух машин. Подъедьте к отмеченной зоне на более широкой дороге.' end
  grid.lengthP,grid.lengthO=math.max(4,extents(player).y+1),math.max(4,extents(opponent).y+1)
  return grid
end

function M.startZone(player,opponent,route)
  local grid,why=M.grid(player,opponent,route)
  if grid then return {valid=true,grid=grid,distance=player:getPosition():distance(grid.centre),
    text=string.format('Старт по ширине подходит: %.1f м / нужно %.1f м. Рамки показывают места машин.',grid.roadWidth,grid.requiredWidth)} end
  local nodes,pos=map.getMap().nodes,player:getPosition()
  local nearest=routeSegment(pos,route,nodes)
  local best,bestDistance
  local sizeP,sizeO=extents(player),extents(opponent)
  -- Search connected route edges nearby, once per preview refresh, not the whole map.
  local travel=0
  for i=math.max(1,(nearest and nearest.index or 1)-1),#route.path-1 do
    local a,b=nodes[route.path[i]],nodes[route.path[i+1]]
    if not a or not b then break end
    local candidate=edgeGrid(pos,a,b,sizeP.x,sizeO.x,(b.pos-a.pos):normalized(),120)
    if candidate then candidate.lengthP,candidate.lengthO=math.max(4,sizeP.y+1),math.max(4,sizeO.y+1) end
    local distance=candidate and pos:distance(candidate.centre)
    if distance and distance<=110 and (not bestDistance or distance<bestDistance) then best,bestDistance=candidate,distance end
    travel=travel+a.pos:distance(b.pos)
    if travel>240 then break end
  end
  return {valid=false,grid=best,distance=bestDistance,
    text=best and string.format('Здесь старт не помещается. Оранжевая зона по маршруту — %.0f м. Подъедьте к ней.',bestDistance) or
      (why..' В ближайших 110 м подходящей зоны нет; выберите другой участок или финиш.')}
end

function M.aiWaypoints(opponent, route)
  local nodes, path = map.getMap().nodes, route.path
  if not path or #path < 2 then return nil end
  for _, name in ipairs(path) do if not nodes[name] then return nil end end
  local segment=routeSegment(opponent:getPosition(),route,nodes)
  if not segment then return nil end
  local first=segment.index+(segment.raw>=0 and 1 or 0)
  -- Grid placement can move across several short graph edges. Trim to the
  -- actual local segment, never send already passed endpoints back to native AI.
  local result = {}
  for i=first,#path do result[#result+1] = path[i] end
  return result
end

function M.checkGrid(player, opponent, route)
  if not player or not opponent or not player:getActive() or not opponent:getActive() then
    return false, 'Одна из машин недоступна на старте. Ставка возвращена.'
  end
  -- Reference nodes differ between models. Compare body centres, as safeTeleport does.
  local p = vec3(player:getSpawnWorldOOBB():getCenter())
  local o = vec3(opponent:getSpawnWorldOOBB():getCenter())
  local delta, grid = o-p, route.grid
  local dot = player:getDirectionVector():dot(opponent:getDirectionVector())
  local forward, lateral = math.abs(delta:dot(grid.direction)), math.abs(delta:dot(grid.right))
  log('I','StreetRacers',string.format('Grid player=%d opponent=%d distance=%.2f forward=%.2f lateral=%.2f directions=%.3f',
    player:getID(),opponent:getID(),delta:length(),forward,lateral,dot))
  if math.abs(delta.z)>1.25 then return false,'На старте перепад высоты. Ставка возвращена; выберите ровный участок.' end
  if player.getDirectionVectorUp and (player:getDirectionVectorUp().z<0.8 or opponent:getDirectionVectorUp().z<0.8) then
    return false,'Машина наклонена после расстановки. Ставка возвращена.'
  end
  if dot < 0.8 or player:getDirectionVector():dot(grid.direction)<0.8 then
    return false, 'Машины развернулись в разные стороны. Ставка возвращена; выберите прямой участок дороги.'
  end
  local minimum=(extents(player).x+extents(opponent).x)*0.5+0.15
  if delta:length()>12 or forward>2 or lateral<minimum or lateral>grid.separation+2 then
    return false, 'На старте не удалось разместить машины рядом. Ставка возвращена; выберите свободный широкий участок.'
  end
  if route.kind=='drag' then
    for _,row in ipairs({{player,route.playerLane},{opponent,route.opponentLane}}) do
      local centre=vec3(row[1]:getSpawnWorldOOBB():getCenter())
      local lane=route.drag.lanes[row[2]]
      local d=centre-lane.stage
      if math.abs(d:dot(grid.right))>1 or math.abs(d:dot(grid.direction))>1.5 then
        return false,'Не удалось поставить машину в её полосу дрэга. Ставка возвращена.'
      end
    end
  end
  return true
end

function M.show(route)
  core_groundMarkers.setPath({route.finish}, {clearPathOnReachingTarget = false})
end
return M
