-- StreetRacers, 2026. MIT. Scope garage ownership to this career; preserve native APIs.
local M={}
function M.new(host)
  local self={}
  local enabled=true
  local hooks={}
  local function wrap(owner,key,fn)
    if not owner or type(owner[key])~='function' then return end
    local original=owner[key]
    local replacement=function(...) return fn(original,...) end
    owner[key]=replacement
    hooks[#hooks+1]={owner=owner,key=key,original=original,replacement=replacement}
  end
  wrap(host.facilities,'getZonesForFacility',function(original,facility,...)
    if enabled and facility and (facility.type=='garage' or host.isGarage(facility.id)) and not host.owns(facility.id) then return {} end
    return original(facility,...)
  end)
  wrap(host.computer,'openMenu',function(original,facility,...)
    local id=facility and host.computerGarage(facility.id)
    if enabled and id and not host.owns(id) then host.purchaseMenu(id) return end
    return original(facility,...)
  end)
  function self.stop()
    enabled=false
    for _,h in ipairs(hooks) do if h.owner[h.key]==h.replacement then h.owner[h.key]=h.original end end
    hooks={}
  end
  return self
end
return M
