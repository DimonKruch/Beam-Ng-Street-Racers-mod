-- Scoped grey/orange styling, shared by the career panels and condition HUD.
local M={accent={1,0.43,0.10,1},text={0.94,0.94,0.94,1},muted={0.63,0.64,0.65,1},
  track={0.22,0.23,0.24,1},warning={1,0.69,0.27,1},danger={1,0.29,0.26,1}}
function M.push(im,compact)
  local palette={
    {im.Col_WindowBg,0.09,0.095,0.10,0.97},{im.Col_ChildBg,0.11,0.115,0.12,1},
    {im.Col_Text,unpack(M.text)},{im.Col_TextDisabled,unpack(M.muted)},
    {im.Col_TitleBg,0.12,0.125,0.13,1},{im.Col_TitleBgActive,0.24,0.15,0.11,1},
    {im.Col_Button,0.23,0.24,0.25,1},{im.Col_ButtonHovered,0.52,0.27,0.12,1},
    {im.Col_ButtonActive,0.72,0.31,0.08,1},{im.Col_FrameBg,0.17,0.18,0.19,1},
    {im.Col_FrameBgHovered,0.30,0.25,0.21,1},{im.Col_FrameBgActive,0.38,0.26,0.18,1},
    {im.Col_CheckMark,unpack(M.accent)},{im.Col_Border,0.29,0.30,0.31,1},
    {im.Col_Separator,0.29,0.30,0.31,1},{im.Col_SliderGrab,unpack(M.accent)},
    {im.Col_SliderGrabActive,1,0.60,0.25,1},{im.Col_ResizeGrip,0.60,0.32,0.15,0.6},
    {im.Col_ResizeGripHovered,unpack(M.accent)},{im.Col_ResizeGripActive,unpack(M.accent)}}
  for _,c in ipairs(palette) do im.PushStyleColor2(c[1],im.ImVec4(c[2],c[3],c[4],c[5])) end
  im.PushStyleVar2(im.StyleVar_WindowPadding,im.ImVec2(compact and 10 or 16,compact and 9 or 12))
  im.PushStyleVar2(im.StyleVar_FramePadding,im.ImVec2(10,compact and 4 or 6))
  im.PushStyleVar2(im.StyleVar_ItemSpacing,im.ImVec2(10,compact and 5 or 7))
  im.PushStyleVar1(im.StyleVar_WindowRounding,6)
  im.PushStyleVar1(im.StyleVar_FrameRounding,4)
  return #palette
end
function M.pop(im,count) im.PopStyleVar(5) im.PopStyleColor(count) end
return M
