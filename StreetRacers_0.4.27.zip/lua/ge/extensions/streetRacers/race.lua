-- StreetRacers, 2026. MIT. Engine-independent state machine; host owns game side effects.
local rules = require('streetRacers/domain')
local M = {}
function M.new(host)
  local self = {phase = 'idle', mode = 'street'}
  function self.busy() return self.phase ~= 'idle' end
  function self.committed() return self.stake ~= nil end
  function self.finish(outcome, reason)
    if self.phase == 'idle' or self.phase == 'settling' then return false end
    if host.saving() then self.deferred = {outcome, reason} return false end
    local stake, opponent = self.stake, self.opponentId
    self.phase = 'settling'
    -- Clear runtime first: duplicate callbacks cannot award another payout.
    host.release(self.playerId, opponent)
    if stake then host.settle(stake, outcome, reason) end
    self.phase, self.stake, self.route, self.opponentId, self.deferred, self.requestedBet, self.mode = 'idle', nil, nil, nil, nil, nil, 'street'
    host.message(reason, outcome == 'win' and 'success' or 'info')
    return true
  end
  function self.challenge(mode,selectedId)
    mode=mode=='drag' and 'drag' or 'street'
    if self.busy() then return false, 'Сначала завершите текущий вызов.' end
    local ok, why = host.canRace()
    if not ok then return false, why end
    local player = host.player()
    local id, profile = host.findOpponent(player,mode,selectedId)
    if selectedId and not id then return false,'Выбранный водитель уже недоступен. Выберите другого в обновлённом списке.' end
    if not id then return false, mode=='drag' and 'В текущем трафике нет готового соперника. Дождитесь проверки машин или обновите трафик.' or 'Рядом впереди нет подходящего соперника. Подъедьте к полноценной машине трафика на 35 м.' end
    if not profile.pending and not profile.playerPending and not profile.accepted then return false, profile.refusal or 'Этот водитель не хочет гоняться. Найдите другого.' end
    self.phase, self.playerId, self.opponentId, self.mode = 'offer', player.id, id, mode
    self.profile, self.offerTime = profile, 0
    self.invited=selectedId~=nil
    local held,errorText=host.hold(id,mode)
    if held==false then self.finish('void',errorText) return false,errorText end
    host.showMenu()
    return true
  end
  function self.setMode(mode)
    if self.phase ~= 'offer' then return false end
    if mode ~= 'street' and mode ~= 'drag' then return false end
    self.mode=mode
    return true
  end
  function self.start(bet)
    if self.phase ~= 'offer' then return false, 'Нет согласившегося соперника.' end
    -- A click during inspection/autosave is a start request, not a discarded click.
    -- Revalidate everything after the wait, before reserving any money.
    if self.profile.pending or self.profile.playerPending or host.saving() then
      self.phase,self.requestedBet,self.waitTime='preparing',bet,0
      return true
    end
    if not self.profile.accepted then return false,self.profile.refusal or 'Этот водитель не хочет гоняться.' end
    local ok, why = host.canRace()
    if not ok then return false, why end
    if not rules.validBet(bet, host.balance(), self.profile) then return false, 'Недопустимая ставка или недостаточно денег. Шаг ставки — $50.' end
    local player, opponent = host.vehicle(self.playerId), host.vehicle(self.opponentId)
    if not player or not opponent or host.player().id ~= self.playerId then return false, 'Одна из машин недоступна.' end
    if player.speed > 2 then return false, 'Остановитесь перед стартом (скорость ниже 7 км/ч).' end
    local route, errorText = host.prepare(player, opponent, self.mode)
    if not route then return false, errorText end
    self.route, self.stake, self.phase = route, bet, 'saving'
    self.waitTime = 0
    host.reserve(bet, self.profile.name)
    host.save()
    return true
  end
  function self.saved()
    if self.phase ~= 'saving' then return end
    local ok, why = host.stage(self.playerId, self.opponentId, self.route, 'player', 1)
    if not ok then self.finish('void', why or 'Старт отменён: не удалось разместить машины.') return end
    self.phase, self.stageStep, self.stageTime, self.stageAttempt, self.stageOpponent = 'staging', 'player', 0, 1, 1
  end
  function self.cancel()
    if self.profile and self.profile.championshipId then
      return self.finish(self.phase=='running' and 'loss' or 'void',self.phase=='running' and
        'Сход. Ставка проиграна; этап можно повторить.' or 'Подготовка отменена. Ставка возвращена.')
    end
    return self.finish(self.phase == 'running' and 'loss' or 'void',
      self.phase == 'running' and 'Сход: ставка проиграна.' or 'Заезд отменён, ставка возвращена.')
  end
  function self.reset(id)
    if id ~= self.playerId and id ~= self.opponentId then return end
    if self.phase == 'running' then self.finish('loss', 'Сброс машины во время гонки: сход.')
    elseif self.phase == 'countdown' or self.phase=='staging' then self.finish('void', 'Машина сброшена до старта. Ставка возвращена.') end
  end
  function self.update(dtReal, dtSim)
    if self.deferred then
      if not host.saving() then self.finish(self.deferred[1], self.deferred[2]) end
      return
    end
    if self.phase == 'idle' then return end
    local player, opponent = host.vehicle(self.playerId), host.vehicle(self.opponentId)
    local current = host.player()
    if not player or not current or current.id ~= self.playerId then
      self.finish(self.phase == 'running' and 'loss' or 'void', 'Вы покинули гоночную машину.') return
    end
    if not opponent then self.finish('void', 'Соперник исчез. Ставка возвращена.') return end
    if self.phase=='preparing' then
      self.waitTime=self.waitTime+dtReal
      if self.waitTime>20 then self.finish('void','Подготовка старта затянулась. Заезд отменён.') return end
      if not host.saving() and not self.profile.pending and not self.profile.playerPending then
        local bet=self.requestedBet
        self.phase,self.requestedBet='offer',nil
        local ok,why=self.start(bet)
        if not ok then self.finish('void',why) end
      end
      return
    end
    if self.phase == 'saving' then
      self.waitTime = self.waitTime + dtReal
      if self.waitTime > 20 then host.saveTimeout() self.finish('void', 'Сохранение не подтверждено. Старт отменён.') end
      return
    end
    if dtSim <= 0 then return end
    if self.phase == 'offer' then
      self.offerTime = self.offerTime+dtSim
      if self.profile.pending and self.offerTime>=3 then host.finishInspection(self.opponentId) end
      if not self.profile.pending and not self.profile.playerPending and not self.profile.accepted then
        self.finish('void',self.profile.refusal or 'Этот водитель не хочет гоняться. Найдите другого.') return
      end
      if self.offerTime > 180 or (not self.invited and self.mode~='drag' and host.distance(player.pos, opponent.pos) > 150) then
        self.finish('void', 'Вызов истёк: соперник вернулся в трафик.')
      end
    elseif self.phase=='staging' then
      self.stageTime=self.stageTime+dtSim
      if self.stageTime<0.5 then return end
      self.stageTime=0
      if self.stageStep=='player' then
        local ok,why=host.stage(self.playerId,self.opponentId,self.route,'opponent',self.stageAttempt,1)
        if not ok then self.finish('void',why or 'Не удалось разместить соперника. Ставка возвращена.') return end
        self.stageStep,self.stageOpponent='opponent',1
      elseif self.stageOpponent<(self.route.opponentCount or 1) then
        self.stageOpponent=self.stageOpponent+1
        local ok,why=host.stage(self.playerId,self.opponentId,self.route,'opponent',self.stageAttempt,self.stageOpponent)
        if not ok then self.finish('void',why or 'Не удалось разместить соперника. Ставка возвращена.') return end
      else
        local ok,why=host.checkGrid(self.playerId,self.opponentId,self.route)
        if ok then
          self.phase,self.countdown,self.lastNumber='countdown',3.5,nil
        elseif self.stageAttempt<2 then
          self.stageAttempt,self.stageStep=2,'player'
          local placed,errorText=host.stage(self.playerId,self.opponentId,self.route,'player',2)
          if not placed then self.finish('void',errorText or why) end
        else self.finish('void',why or 'Не удалось подготовить безопасный старт. Ставка возвращена.') end
      end
    elseif self.phase == 'countdown' then
      self.countdown = self.countdown-dtSim
      local number = math.min(3, math.ceil(self.countdown))
      if number > 0 and number ~= self.lastNumber then host.count(number) self.lastNumber = number end
      if self.countdown <= 0 then
        local ok, why = host.go(self.playerId, self.opponentId, self.route, self.profile)
        if not ok then self.finish('void', why or 'Не удалось запустить AI. Ставка возвращена.') return end
        self.phase, self.elapsed = 'running', 0
        self.contact,self.contactCooldown=false,0
        self.opponentStart, self.opponentStarted = opponent.pos, false
        self.previousPlayer, self.previousOpponent = self.route.kind=='drag' and (player.racePos or player.pos) or player.pos,
          self.route.kind=='drag' and (opponent.racePos or opponent.pos) or opponent.pos
        host.count('GO!')
      end
    elseif self.phase == 'running' then
      if self.route.kind=='drag' then player.pos,opponent.pos=player.racePos or player.pos,opponent.racePos or opponent.pos end
      self.elapsed = self.elapsed+dtSim
      if host.contact then
        local touching,relativeSpeed=host.contact(self.playerId,self.opponentId)
        self.contactCooldown=math.max(0,(self.contactCooldown or 0)-dtSim)
        if touching and not self.contact and self.contactCooldown==0 then
          if host.collision then host.collision(relativeSpeed or 0) end
          self.contactCooldown=2
        end
        self.contact=touching
      end
      -- Teleport/discontinuity cannot count as crossing the finish.
      local allowedP = math.max(35, (player.speed+25)*dtSim*2)
      local allowedO = math.max(35, (opponent.speed+25)*dtSim*2)
      if host.distance(player.pos, self.previousPlayer) > allowedP then
        self.finish('loss', 'Телепортация во время гонки: сход.') return
      end
      if host.distance(opponent.pos, self.previousOpponent) > allowedO then
        self.finish('void', 'Нарушено положение AI. Ставка возвращена.') return
      end
      -- A queued AI command is not proof of a working opponent. Give slow gearboxes
      -- time to engage, then refund a failed launch instead of awarding a free win.
      if opponent.speed > 1 and host.distance(opponent.pos, self.opponentStart) >= 3 then
        self.opponentStarted = true
      end
      if not self.opponentStarted and self.elapsed >= 12 then
        if host.launchFailed then host.launchFailed(self.opponentId) end
        self.finish('void', 'Соперник не смог тронуться. Заезд отменён, ставка возвращена.') return
      end
      local pt,ot
      local seriesOutcome
      if self.route.kind=='series' then
        seriesOutcome=host.result(dtSim)
      elseif self.route.kind=='drag' then
        local d=self.route.drag
        pt=rules.dragCrossing(self.previousPlayer,player.pos,d.lanes[self.route.playerLane],d.direction,d.right)
        ot=rules.dragCrossing(self.previousOpponent,opponent.pos,d.lanes[self.route.opponentLane],d.direction,d.right)
        local outP=rules.dragOutOfLane(player.pos,d.lanes[self.route.playerLane],d.right)
        local outO=rules.dragOutOfLane(opponent.pos,d.lanes[self.route.opponentLane],d.right)
        if not pt and outP then self.finish(outO and 'draw' or 'loss','Выезд из своей полосы дрэга: сход.') return end
        if not ot and outO then self.finish(self.opponentStarted and 'win' or 'void','Соперник покинул свою полосу дрэга.') return end
      else
        pt=rules.crossing(self.previousPlayer, player.pos, self.route.finish, self.route.radius)
        ot=rules.crossing(self.previousOpponent, opponent.pos, self.route.finish, self.route.radius)
      end
      local outcome = seriesOutcome or rules.winner(pt, ot)
      if outcome then
        if not self.opponentStarted then
          self.finish('void', 'Соперник не смог тронуться. Заезд отменён, ставка возвращена.') return
        end
        local label = outcome == 'win' and ('Победа! Прибыль: $'..self.stake) or
          (outcome == 'void' and 'Ошибка трассы. Ставка возвращена.' or
          (outcome == 'draw' and 'Одновременный финиш. Ставки возвращены.' or ('Поражение. Потеряно: $'..self.stake)))
        if self.profile.championshipId then
          label=outcome=='win' and ('Победа! Прибыль: $'..self.stake..(self.profile.round==5 and '. Чемпионат пройден!' or '.')) or
            (outcome=='draw' and 'Ничья. Ставка возвращена; повторите этап.' or
              'Поражение. Потеряно: $'..self.stake..'. Этап можно повторить.')
        elseif self.profile.streetSeries and outcome=='win' then
          local pool=self.stake*(self.profile.participants or 2)
          label='Победа! Призовой фонд: $'..pool..'. Прибыль: $'..(pool-self.stake)..'.'
        end
        self.finish(outcome, label) return
      end
      self.previousPlayer, self.previousOpponent = player.pos, opponent.pos
      if self.elapsed > math.max(180, self.route.length/5) then self.finish('loss', 'Время гонки истекло. Сход.') end
    end
  end
  return self
end
return M
