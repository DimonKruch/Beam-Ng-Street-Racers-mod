-- StreetRacers, 2026. MIT. Persistent tyre identities live in stock part tags.
local rules = require('streetRacers/domain')
local M = {}

function M.new(host, state)
  local self = {connections = {}, suspended = false}
  local epoch = tostring(os.time()) .. ':' .. tostring(math.random(100000, 999999))
  local serial = 0
  local pollClock = 0

  local function isTyre(part)
    local name = string.lower(part.name or '')
    local slot = string.lower(part.containingSlot or '')
    return name:find('tire', 1, true) or name:find('tyre', 1, true) or slot:find('/tire', 1, true)
  end

  local function record(part)
    part.tags = part.tags or {}
    local token = part.tags.streetRacersTyreId
    if type(token) ~= 'string' or not state.tyres[token] then
      state.nextTyreId = state.nextTyreId+1
      token = 'sr-' .. state.nextTyreId
      part.tags.streetRacersTyreId = token
      state.tyres[token] = {name = part.name, wheels = {}}
    end
    return token, state.tyres[token]
  end

  function self.parts(inventoryId)
    local result = {}
    for id, part in pairs(host.parts()) do
      if part.location == inventoryId and isTyre(part) then
        local token, saved = record(part)
        local condition, count, punctured = 1, 0, {}
        for name, w in pairs(saved.wheels) do
          condition = math.min(condition, w.condition) count = count+1
          if w.deflated or w.condition<=0 then punctured[#punctured+1]=name end
        end
        table.sort(punctured)
        local price = math.ceil(math.max(50, tonumber(part.value) or 100)+25)
        result[#result+1] = {id = id, part = part, token = token, condition = condition, measured = count > 0,
          compound = rules.tyreCompound(part), price = price, punctured = punctured,
          roadsidePrice = math.ceil(price*1.5)+150}
      end
    end
    table.sort(result, function(a,b) return a.id < b.id end)
    return result
  end

  function self.roadsideParts(inventoryId)
    -- Every physical inventory slot remains a separate purchase target.
    return self.parts(inventoryId)
  end

  function self.choices(inventoryId,part)
    local result={}
    local found=false
    for _,source in ipairs(host.choices and host.choices(inventoryId,part) or {}) do
      local choice={name=source.name,value=source.value,description=source.description}
      result[#result+1]=choice
      if choice.name==part.name then choice.value=part.value end
      choice.price=math.ceil(math.max(50,tonumber(choice.value) or 100)+25)
      choice.roadsidePrice=math.ceil(choice.price*1.5)+150
      choice.compound=rules.tyreCompound(choice)
      if choice.name==part.name then found=true end
    end
    if not found then
      local price=math.ceil(math.max(50,tonumber(part.value) or 100)+25)
      table.insert(result,1,{name=part.name,value=part.value,description=part.description,
        price=price,roadsidePrice=math.ceil(price*1.5)+150,compound=rules.tyreCompound(part)})
    end
    return result
  end

  function self.resaleValue(part, base)
    local value=tonumber(base) or 0
    if not isTyre(part) then return value end
    local token=part.tags and part.tags.streetRacersTyreId
    local saved=token and state.tyres[token]
    if not saved or type(saved.wheels)~='table' then return value end
    local condition=1
    for _,wheel in pairs(saved.wheels) do condition=math.min(condition,math.max(0,math.min(1,tonumber(wheel.condition) or 0))) end
    return math.floor(value*(0.15+0.85*condition)+0.5)
  end

  local function bestPart(wheel, parts)
    local best, bestScore = nil, -1
    for _, entry in ipairs(parts) do
      local p, score = entry.part, 0
      local a, b = wheel.partPath or '', p.partPath or ''
      for i = 1, math.min(#a, #b) do if a:sub(i,i) ~= b:sub(i,i) then break end score = i end
      if wheel.partOrigin == p.name then score = score+10000 end
      local name = string.upper(wheel.name or '')
      local text = string.upper(p.name .. ' ' .. (p.containingSlot or ''))
      local axle = name:sub(1,1)
      if (axle == 'F' or axle == 'R') and (text:find('_'..axle..'_',1,true) or text:find('_'..axle..'/',1,true)) then score = score+1000 end
      if score > bestScore then best, bestScore = entry, score end
    end
    return bestScore > 0 and best or nil
  end

  function self.attach(vehicleId, force)
    if self.suspended then return end
    local inventoryId = host.inventoryId(vehicleId)
    if not inventoryId or not host.owned(inventoryId) then return end
    local connection = self.connections[vehicleId]
    if connection and not force then return end
    serial = serial+1
    connection = {session = epoch .. ':' .. serial, inventoryId = inventoryId, sequence = 0, generation = 0, requestedAt = pollClock}
    self.connections[vehicleId] = connection
    host.command(vehicleId, "extensions.load('streetRacersVehicle'); streetRacersVehicle.connect(" .. string.format('%q', connection.session) .. ')')
  end

  function self.ready(data)
    local c = self.connections[data.vehicleId]
    if not c or data.session ~= c.session or self.suspended then return false end
    if host.inventoryId(data.vehicleId) ~= c.inventoryId then return false end
    c.acknowledged = true
    local parts = self.parts(c.inventoryId)
    if #parts == 0 then c.needsRetry = true return false end
    c.needsRetry, c.description, c.bindings, c.damage = false, data.wheels, {}, {}
    c.generation = c.generation+1
    for _, wheel in ipairs(data.wheels or {}) do
      local part = bestPart(wheel, parts)
      if part then
        local saved = state.tyres[part.token]
        local tyre = saved.wheels[wheel.name]
        if not tyre then
          local axle = string.upper(wheel.name or ''):sub(1,1)
          local pc = part.part.partCondition or {}
          local used = (tonumber(pc.odometer) or 0)>0
          local axleValues = state.initialTyreAxles or {}
          state.initialTyreAxles = axleValues
          local vehicleAxles = axleValues[tostring(c.inventoryId)] or {}
          axleValues[tostring(c.inventoryId)] = vehicleAxles
          local condition = 1
          if used then
            if not vehicleAxles[axle] then vehicleAxles[axle]=math.random(27,70)/100 end
            condition=vehicleAxles[axle]
          end
          for _, old in pairs(saved.wheels) do condition = math.min(condition, old.condition) end
          tyre = {condition = condition, temperature = 21}
          saved.wheels[wheel.name] = tyre
        end
        tyre.deflated = tyre.deflated == true or wheel.deflated == true or tyre.condition<=0
        c.damage[wheel.name] = {broken=wheel.broken == true}
        c.bindings[wheel.name] = {token = part.token, condition = tyre.condition, temperature = tyre.temperature,
          partId = part.id, compound = part.compound, deflated = tyre.deflated}
      end
    end
    host.command(data.vehicleId, 'streetRacersVehicle.apply(' .. serialize({session = c.session,
      generation = c.generation, bindings = c.bindings, multiplier = state.settings.wearMultiplier}) .. ')')
    return true
  end

  function self.receive(data)
    local c = self.connections[data.vehicleId]
    if not c or c.session ~= data.session or c.generation ~= data.generation or
      not rules.finite(data.sequence) or data.sequence <= c.sequence then return false end
    c.lastSampleAt = pollClock
    c.sequence = data.sequence
    for name, incoming in pairs(data.wheels or {}) do
      local binding = c.bindings and c.bindings[name]
      local saved = binding and state.tyres[binding.token]
      local part = binding and host.parts()[binding.partId]
      if saved and part and part.location == c.inventoryId and part.tags and part.tags.streetRacersTyreId == binding.token then
        local tyre = saved.wheels[name]
        tyre.condition = rules.acceptWear(tyre.condition, incoming.condition)
        if rules.finite(incoming.temperature) then tyre.temperature = rules.clamp(incoming.temperature, -50, 240) end
        -- A reset or an old 'inflated' sample is not a paid tyre replacement.
        tyre.deflated = tyre.deflated == true or incoming.deflated == true or tyre.condition<=0
        c.damage[name] = {broken=incoming.broken == true}
      end
    end
    return true
  end

  function self.poll()
    pollClock = pollClock+1
    if self.suspended then return end
    for inventoryId, vehicleId in pairs(host.spawned()) do
      if host.owned(inventoryId) then
        local c = self.connections[vehicleId]
        if not c then self.attach(vehicleId)
        elseif c.needsRetry or (not c.acknowledged and pollClock-(c.requestedAt or 0)>=3) or (c.acknowledged and pollClock-(c.lastSampleAt or c.requestedAt or 0)>=8) then self.attach(vehicleId, true) end
      end
    end
    for id in pairs(self.connections) do if not host.exists(id) then self.connections[id] = nil end end
  end

  function self.hud(vehicleId)
    local c = self.connections[vehicleId]
    local result = {}
    if not c or host.inventoryId(vehicleId) ~= c.inventoryId then return result end
    for name, binding in pairs(c.bindings or {}) do
      local part = host.parts()[binding.partId]
      local saved = state.tyres[binding.token]
      local wheel = saved and saved.wheels[name]
      if wheel and part and part.location == c.inventoryId and part.tags.streetRacersTyreId == binding.token then
        result[#result+1] = {name = name, condition = wheel.condition, temperature = wheel.temperature,
          compound = binding.compound or 'road', deflated = wheel.deflated == true}
      end
    end
    table.sort(result, function(a,b) return a.name < b.name end)
    return result
  end

  function self.snapshot(request, vehicleId)
    local pending = {}
    for id, c in pairs(self.connections) do
      if (not vehicleId or id==vehicleId) and c.bindings and host.exists(id) and not self.suspended then
        pending[id] = c.session
        host.command(id, 'streetRacersVehicle.snapshot(' .. serialize(request) .. ')')
      end
    end
    return pending
  end

  function self.quote(inventoryId, partId, mode, model)
    if mode ~= nil and mode ~= 'garage' and mode ~= 'roadside' then return nil, 'Неизвестный вид обслуживания.' end
    local ok, why = host.canService(inventoryId, mode)
    if not ok then return nil, why end
    local entry
    for _, candidate in ipairs(self.parts(inventoryId)) do if candidate.id == partId then entry = candidate end end
    if not entry then return nil, 'Деталь шин не найдена.' end
    if not entry.measured then return nil, 'Дождитесь считывания шин автомобиля.' end
    if mode=='roadside' then
      local id = host.vehicleId(inventoryId)
      local c = id and self.connections[id]
      if not c or not c.bindings then return nil, 'Дождитесь считывания шин автомобиля.' end
      local matched = 0
      for name, binding in pairs(c.bindings) do
        if binding.token==entry.token then
          matched=matched+1
          if c.damage[name] and c.damage[name].broken then return nil, 'Колесо повреждено или оторвано. Нужен ремонт в сервисе.' end
        end
      end
      if matched==0 then return nil, 'Этот комплект не установлен на колёсах машины.' end
    end
    if model and model~=entry.part.name then
      for _,choice in ipairs(self.choices(inventoryId,entry.part)) do
        if choice.name==model then entry.replacement=choice break end
      end
      if not entry.replacement then return nil,'Эта модель шин несовместима с выбранной осью.' end
      entry.price,entry.roadsidePrice=entry.replacement.price,entry.replacement.roadsidePrice
    end
    entry.charge = mode=='roadside' and entry.roadsidePrice or entry.price
    if not host.canPay(entry.charge) then return nil, 'Недостаточно денег.' end
    return entry
  end

  function self.replace(inventoryId, partId, mode, expectedToken, model)
    local entry, why = self.quote(inventoryId, partId, mode, model)
    if not entry then return false, why end
    if expectedToken and expectedToken~=entry.token then return false, 'Комплект шин изменился. Откройте заказ заново.' end
    host.pay(entry.charge, (mode=='roadside' and 'StreetRacers: техпомощь — ' or 'StreetRacers: новые шины ') .. entry.part.name)
    -- A paid replacement gets a new identity; delayed packets still reference the discarded set.
    entry.part.tags.streetRacersTyreId = nil
    if entry.replacement then
      local choice=entry.replacement
      entry.part.name,entry.part.value,entry.part.description=choice.name,choice.value,choice.description
      entry.part.partPath=entry.part.containingSlot..choice.name
    end
    entry.part.partCondition = {integrityValue = 1, visualValue = 1, odometer = 0}
    record(entry.part)
    local vehicleId = host.vehicleId(inventoryId)
    -- Never bind a new purchase to the old, still-punctured physics object.
    -- The career coordinator respawns it and performs a fresh session handshake.
    if vehicleId then self.connections[vehicleId]=nil end
    host.dirty(inventoryId)
    host.save()
    return true
  end

  function self.suspend()
    self.snapshot()
    for id in pairs(self.connections) do host.command(id, 'if streetRacersVehicle then streetRacersVehicle.disable() end') end
    self.suspended = true
  end

  function self.resume()
    self.connections, self.suspended = {}, false
    self.poll()
  end

  function self.forget(vehicleId) self.connections[vehicleId] = nil end

  function self.stop()
    for id in pairs(self.connections) do host.command(id, 'if streetRacersVehicle then streetRacersVehicle.disable() end') end
    self.connections = {}
  end
  return self
end
return M
