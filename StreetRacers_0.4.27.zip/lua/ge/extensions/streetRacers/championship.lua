-- StreetRacers, 2026. MIT. One private entrant, never borrowed from traffic.
local rules=require('streetRacers/domain')
local ladder=require('streetRacers/championshipRules')
local M={}
function M.new(host,state)
  local self={phase='idle'}
  local job,serial,elapsed=nil,0,0
  function self.busy() return job~=nil end
  function self.owns(id) return job and job.id==id and host.vehicle(id)==job.car end
  function self.release(id)
    if not job or (id and id~=job.id) then return false end
    local old=job job=nil self.phase='idle'
    for _,car in ipairs(old.cars or {}) do
      if host.vehicle(car:getID())==car then host.delete(car) end
    end
    return true
  end
  function self.start(power,inventoryId)
    if job then return false,'Соперник уже готовится.' end
    local c=state.championship
    if c and not ladder.valid(c) then return false,'Таблица чемпионата повреждена. Начните новый чемпионат.' end
    local created=false
    if not c or c.failed or c.round>5 then
      local nextId=(state.nextChampionshipId or 0)+1
      local why
      c,why=ladder.create(power,inventoryId,host.catalog(),nextId)
      if not c then return false,why end
      created=true
    end
    if c.inventoryId~=inventoryId or math.abs(power/c.playerPower-1)>0.05 then
      return false,'Состав подобран под другую машину или настройку мощности. Начните новый чемпионат.'
    end
    local row=c.rounds[c.round]
    if host.balance and host.balance()<row.reward then
      return false,'Недостаточно денег для ставки этапа ($'..row.reward..').'
    end
    if created then
      state.nextChampionshipId=c.id
      state.championship=c
      host.save()
    end
    serial=serial+1
    job={row=row,championshipId=c.id,round=c.round,token=tostring(c.id)..':'..serial..':'..tostring(os.time()),at=elapsed,cars={}}
    self.phase='spawning'
    local ok,car,cars=pcall(host.spawn,row)
    if not ok or not car then self.release() return false,'Не удалось загрузить машину этапа. Деньги не списаны.' end
    job.car,job.id,job.cars=car,car:getID(),cars or {car}
    return true
  end
  local function launch()
    if not job or self.phase~='ready' or (host.waiting and host.waiting()) then return true end
    self.phase='racing'
    local ok,why=host.ready(job.id,job.profile)
    if not ok then self.release() host.message(why,'warning') end
    return ok
  end
  function self.receive(data)
    if not job or self.phase~='measuring' or data.token~=job.token or data.vehicleId~=job.id or not self.owns(job.id) then return false end
    if not rules.finite(data.power) or math.abs(data.power/job.row.targetPower-1)>0.025 then
      self.release() host.message(data.error or 'Не удалось настроить мощность соперника. Повторите подготовку.','warning') return false
    end
    job.row.power=data.power
    self.phase='ready'
    job.profile={name=job.row.name,class='drag',power=data.power,playerPower=state.championship.playerPower,
      playerPowerSource='engine',accepted=true,pending=false,playerPending=false,minBet=job.row.reward,maxBet=job.row.reward,aggression=1,
      championshipId=job.championshipId,round=job.round,reward=job.row.reward}
    return launch()
  end
  function self.update(dt,dtSim,allowed)
    elapsed=elapsed+math.max(0,dt)
    if not job or self.phase=='racing' then return end
    if not allowed or not self.owns(job.id) or elapsed-job.at>20 then
      self.release() host.message('Подготовка этапа отменена. Прогресс и деньги сохранены.','warning') return
    end
    job.sim=(job.sim or 0)+math.max(0,dtSim)
    if self.phase=='spawning' and elapsed-job.at>=1 and job.sim>=0.25 then
      self.phase='measuring'
      host.configure(job.id,job.row.targetPower,job.token)
    end
    if self.phase=='ready' then launch() end
  end
  return self
end
return M
