-- StreetRacers, 2026. MIT. Use the native slot tree: tyre size alone is not compatibility.
local M={}
function M.node(tree,path)
  if type(tree)~='table' then return end
  if tree.path==path then return tree end
  for _,child in pairs(tree.children or {}) do
    local found=M.node(child,path)
    if found then return found end
  end
end
function M.choices(data,part,io)
  local node=data and data.config and M.node(data.config.partsTree,part.containingSlot)
  if not node or not data.ioCtx then return {} end
  local available=io.getAvailableParts(data.ioCtx) or {}
  local result={}
  for _,name in ipairs(node.suitablePartNames or {}) do
    local raw=io.getPart(data.ioCtx,name)
    -- Replacing a leaf tyre cannot silently install/remove child components.
    if raw and not raw.slots and not raw.slots2 and raw.information and not raw.information.isAuxiliary then
      local info=available[name] or {}
      result[#result+1]={name=name,value=tonumber(raw.information.value) or 100,
        description={description=info.description or raw.information.name or name}}
    end
  end
  table.sort(result,function(a,b) return a.name<b.name end)
  return result
end
return M
