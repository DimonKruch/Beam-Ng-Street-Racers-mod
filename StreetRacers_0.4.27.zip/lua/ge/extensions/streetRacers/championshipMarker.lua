-- StreetRacers, 2026. MIT. Registration marker outside the two racing lanes.
local M={}
local icon
local function renderer() return gameplay_playmodeMarkers and gameplay_playmodeMarkers.getBigmapRendererObj() end
function M.position(info) return info and info.start-info.direction*25+info.right*18 end
function M.near(info,car)
  local pos=M.position(info)
  return pos and car and car:getPosition():distance(pos)<18 and car:getVelocity():length()<2 or false
end
function M.clear()
  local r=renderer()
  if icon and r then r:removeIconById(icon) end
  icon=nil
end
function M.update(info,car,enabled,bigmap)
  if not enabled or not info then M.clear() return end
  local pos=M.position(info)
  local r=renderer()
  if r and bigmap then
    local name='streetRacersChampionship'
    if not r:getIconByName(name) then icon=r:addIcon(name,'mission_airace01_triangle',pos) end
    local data=r:getIconByName(name)
    if data then data.worldPosition=pos+vec3(0,0,2) data.color=ColorI(255,130,32,255) data.customSizeFactor=1 end
  elseif icon then M.clear() end
  if not bigmap and car and car:getPosition():distance(pos)<100 and debugDrawer then
    debugDrawer:drawSphere(pos+vec3(0,0,0.6),1.6,ColorF(1,0.4,0.08,0.55))
    debugDrawer:drawTextAdvanced(pos+vec3(0,0,3),'ALDER / ДРЭГ-ЧЕМПИОНАТ\nГудок — открыть таблицу',
      ColorF(1,0.65,0.25,1),true,false,ColorI(20,20,20,220))
  end
end
return M
