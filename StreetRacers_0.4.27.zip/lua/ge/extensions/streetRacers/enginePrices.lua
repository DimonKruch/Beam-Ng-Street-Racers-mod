-- StreetRacers, 2026. MIT. Cooperatively evaluate engines; never spawn market cars.
local rules=require('streetRacers/domain')
local cacheFactory=require('ge/extensions/streetRacers/priceCache')
local engineData=require('ge/extensions/streetRacers/engineData')
local M={}
function M.new(changed,workerFactory)
  local self,records,queue,current={},{},{},nil
  local enabled,cacheTimer=true,0
  local cache=cacheFactory.new()
  local worker=(workerFactory or engineData).new()
  local function key(config) return tostring(config.model_key)..':'..tostring(config.key) end
  local function finish(power,reason)
    local job=current
    if not job then return end
    current=nil
    local result=records[job.key]
    if not rules.finite(power) or power<=0 or power>10000 then power=nil reason=reason or 'Двигатель не сообщил мощность.' end
    result.pending,result.power,result.error=false,power,reason
    if power then cache.put(job.key,power) end
    log(power and 'I' or 'W','StreetRacers','Engine data '..job.key..': '..(power and string.format('%.1f PS',power) or tostring(reason)))
    if changed then changed(job.model,job.config) end
  end
  function self.request(config,priority)
    if type(config)~='table' or not config.model_key or not config.key or config.Source=='BeamNG - Official' then return nil end
    local id=key(config)
    if not records[id] then
      local power=cache.get(id)
      records[id]={pending=not power,power=power}
      if not power then queue[#queue+1]={key=id,model=config.model_key,config=config.key} end
    end
    if priority and records[id].pending then
      for i,job in ipairs(queue) do
        if job.key==id then table.remove(queue,i) table.insert(queue,1,job) break end
      end
    end
    return records[id]
  end
  function self.get(config) return type(config)=='table' and records[key(config)] or nil end
  function self.cached(config)
    if type(config)~='table' then return nil end
    local result=records[key(config)]
    if result then return result end
    local power=cache.get(key(config))
    return power and {power=power,pending=false} or nil
  end
  function self.status()
    local pending,failed=0,0
    for _,r in pairs(records) do if r.pending then pending=pending+1 elseif r.error then failed=failed+1 end end
    return pending,failed
  end
  -- Reject asynchronous replies from pre-upgrade temporary vehicles.
  function self.receive() return false end
  function self.update(dt,allowStart,allowedKeys)
    if not enabled then return end
    cacheTimer=cacheTimer+dt
    if cacheTimer>=1 then cache.flush() cacheTimer=0 end
    -- Pause even an unfinished calculation when another menu/race takes over.
    if not allowStart then return end
    if current and allowedKeys and not allowedKeys[current.key] then
      queue[#queue+1]=current
      current=nil
    end
    if not current then
      local index
      for i,job in ipairs(queue) do if not allowedKeys or allowedKeys[job.key] then index=i break end end
      if not index then return end
      current=table.remove(queue,index)
      if not current.work then
        local ok,job=pcall(worker.start,current.model,current.config)
        if not ok or not job then finish(nil,'Не удалось прочитать двигатель: '..tostring(job)) return end
        current.work=job
      end
    end
    current.steps=(current.steps or 0)+1
    if current.steps>4096 then finish(nil,'Превышен объём анализа двигателя.') return end
    local ok,done,power,reason=pcall(worker.step,current.work,0.004)
    if not ok then finish(nil,'Ошибка анализа двигателя: '..tostring(done))
    elseif done then finish(power,reason) end
  end
  function self.stop(invalidate)
    if invalidate then cache.clear() engineData.clear() end
    cache.flush()
    enabled=false
    current=nil
    queue={}
  end
  return self
end
return M
