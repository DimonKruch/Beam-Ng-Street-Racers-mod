-- StreetRacers, 2026. MIT. Reuse measured engines only for the same installed content.
local rules=require('streetRacers/domain')
local M={}
local path='/settings/streetRacersEnginePrices.json'
local function signature()
  if not beamng_versiond or not core_modmanager or not FS or not jsonReadFile or not jsonWriteFile then return nil end
  local ok,mods=pcall(core_modmanager.getMods)
  if not ok or type(mods)~='table' then return nil end
  local entries={tostring(beamng_versiond)}
  for name,mod in pairs(mods) do
    if type(mod)=='table' and mod.active~=false then
      if not mod.fullpath then return nil end
      if mod.unpackedPath then
        -- An unrelated unpacked UI/map mod must not disable every saved engine.
        -- Validate the actual input files, since folder mtime misses edits inside.
        local root=type(mod.unpackedPath)=='string' and mod.unpackedPath or mod.fullpath
        root=root:gsub('/+$','')..'/'
        entries[#entries+1]=tostring(name)..'|'..root
        for _,input in ipairs({{'vehicles/','*.jbeam'},{'vehicles/','*.pc'},
          {'vehicles/','*.lua'},{'lua/vehicle/','*.lua'}}) do
          local valid,files=pcall(function() return FS:findFiles(root..input[1],input[2],-1,false,false) end)
          if not valid or type(files)~='table' then return nil end
          for _,file in ipairs(files) do
            local ok,stat=pcall(function() return FS:stat(file) end)
            if not ok or type(stat)~='table' or not stat.filesize or not stat.modtime then return nil end
            entries[#entries+1]=file..'|'..stat.filesize..'|'..stat.modtime
          end
        end
      else
        local valid,stat=pcall(function() return FS:stat(mod.fullpath) end)
        if not valid or type(stat)~='table' or stat.filetype~='file' or not stat.filesize or not stat.modtime then return nil end
        entries[#entries+1]=tostring(name)..'|'..mod.fullpath..'|'..stat.filesize..'|'..stat.modtime
      end
    end
  end
  table.sort(entries)
  return table.concat(entries,'\n')
end
function M.new()
  local identity=signature()
  local entries,dirty={},false
  if identity then
    local ok,saved=pcall(jsonReadFile,path)
    if ok and type(saved)=='table' and saved.version==2 and saved.signature==identity and type(saved.entries)=='table' then
      entries=saved.entries
    end
  end
  return {
    get=function(key)
      local power=entries[key]
      return rules.finite(power) and power>0 and power<=10000 and power or nil
    end,
    put=function(key,power) entries[key]=power dirty=true end,
    flush=function()
      if not dirty or not identity then return end
      local ok,result=pcall(jsonWriteFile,path,{version=2,signature=identity,entries=entries},true)
      if ok and result~=false then dirty=false end
    end,
    clear=function()
      entries={} dirty=true
    end
  }
end
return M
