-- StreetRacers, 2026. MIT. Native JBeam/engine calculation without a vehicle spawn.
-- Native modules are read from the installed game, never copied or patched.
local M={}
local sources={}
function M.clear() sources={} end
local function source(path)
  if sources[path]==nil then sources[path]=readFile(path) or false end
  return sources[path]
end
local function loadModule(path,env)
  local code=source(path)
  if not code then error('Нет Lua-модуля: '..path) end
  local chunk,err=loadstring(code,'@'..path)
  if not chunk then error(err) end
  setfenv(chunk,env)
  return chunk()
end
local function environment(values)
  values=values or {}
  values._G=values
  return setmetatable(values,{__index=_G})
end
-- These sections have no effect on the engine's JBeam data or torque curves.
-- Keep slots, variables, components, powertrain and all unknown/custom sections.
local geometry={nodes=true,beams=true,triangles=true,flexbodies=true,props=true,
  pressureWheels=true,wheels=true,hydros=true,rails=true,slidenodes=true,
  torsionbars=true,torsionHydros=true,refNodes=true,camerasInternal=true,
  camerasExternal=true,camerasRelative=true,glowMap=true,events=true,triggers=true,
  soundscape=true,meshes=true,visualRopes=true,mirrors=true}
local function project(part)
  for section in pairs(geometry) do part[section]=nil end
  return part
end

function M.new()
  local self={}
  local timer=hptimer and hptimer()
  local clock=timer and function() return timer:stop()/1000 end or os.clock
  local deadline=0
  local warnings=0
  local function checkpoint(force)
    if force or clock()>=deadline then coroutine.yield() end
  end
  local function quietLog(level,tag,message)
    if level=='E' or level=='W' then warnings=warnings+1 end
  end
  local ioEnv=environment({profilerPushEvent=nop,profilerPopEvent=nop,log=quietLog})
  ioEnv.jsonReadFile=function(path)
    local data=jsonReadFile(path)
    if type(data)=='table' then
      for _,part in pairs(data) do if type(part)=='table' then project(part) end end
    end
    checkpoint()
    return data
  end
  local jio
  local slotSystem
  local function nativeParts()
    if jio then return end
    jio=loadModule('/lua/common/jbeam/io.lua',ioEnv)
    local proxy=setmetatable({}, {__index=jio})
    proxy.getPart=function(...)
      local part,path=jio.getPart(...)
      checkpoint()
      return part,path
    end
    local slotEnv=environment({profilerPushEvent=nop,profilerPopEvent=nop,log=quietLog})
    slotEnv.require=function(name) return name=='jbeam/io' and proxy or require(name) end
    slotSystem=loadModule('/lua/common/jbeam/slotSystem.lua',slotEnv)
  end
  local function assemble(model,key)
    nativeParts()
    local dir='/vehicles/'..model..'/'
    local config=assert(jsonReadFile(dir..key..'.pc'),'Нет комплектации '..model..'/'..key)
    checkpoint()
    local ctx=jio.startLoading({dir,'/vehicles/common/'})
    config.model=model
    config.mainPartName=config.mainPartName or jio.getMainPartName(ctx)
    config.mainPartPath='/'..assert(config.mainPartName,'Нет главной детали '..model)
    checkpoint()
    local vehicle,journal,componentJournal=slotSystem.findParts(ctx,config)
    assert(vehicle,'Не удалось собрать комплектацию '..model..'/'..key)
    vehicle.partOrigin=vehicle.partName
    vehicle.partPath='/'..vehicle.partName
    checkpoint()
    local variables=require('jbeam/variables')
    local vars=variables.getAllVariables(vehicle,journal,config)
    variables.processComponents(vehicle,componentJournal,config,vars)
    checkpoint()
    local allVars=variables.processParts(vehicle,journal,config,vars)
    checkpoint()
    for _,entry in ipairs(journal) do
      assert(slotSystem.unifyPartJournal(ctx,{entry}),'Ошибка объединения деталей')
      checkpoint()
    end
    variables.postProcessVariables(vehicle,allVars)
    variables.cleanup(vehicle)
    checkpoint()
    assert(require('jbeam/tableSchema').process(vehicle),'Ошибка таблиц двигателя')
    assert(require('jbeam/sectionMerger').process(vehicle,{}),'Ошибка секций двигателя')
    jio.finishLoading()
    vehicle.vehicleDirectory=dir
    -- Geometry is not linked/compiled. Constructors only need a display reference.
    vehicle.refNodes={[0]={ref=0}}
    checkpoint(true)
    return vehicle
  end
  local function engines(model,data)
    local modules,devices={},{}
    local env=environment({v={data=data},obj={getId=function() return -1 end},
      electrics={values={ignitionLevel=0}},damageTracker={setDamage=nop},
      profilerPushEvent=nop,profilerPopEvent=nop,log=quietLog,
      physicsDt=1/2000,vehiclePath='/vehicles/'..model..'/',
      powertrain={currentEnvPressure=101325,currentEnvTemperature=293.15,
        currentGravity=9.81,getDevice=function(name) return devices[name] end}})
    loadModule('/lua/vehicle/ve_utils.lua',env)
    local curve=env.createCurve
    env.createCurve=function(...)
      local result=curve(...)
      checkpoint()
      return result
    end
    local nativeRequire=require
    local function module(name,fresh)
      if name=='powertrain/combustionEngineThermals' then return {init=nop} end
      if not fresh and modules[name] then return modules[name] end
      local localPath='/vehicles/'..model..'/lua/'..name..'.lua'
      local code=source(localPath)
      local path=code and localPath or '/lua/vehicle/'..name..'.lua'
      local result
      if source(path) then result=loadModule(path,env) else result=nativeRequire(name) end
      if not fresh then modules[name]=result end
      checkpoint()
      return result
    end
    env.require=function(name) return module(name,false) end
    env.rerequire=function(name) return module(name,true) end
    -- A fresh module environment per config/engine prevents induction state leaks.
    local total,count=0,0
    for _,row in pairs(data.powertrain or {}) do
      if type(row)=='table' and type(row.type)=='string' and type(row.name)=='string' then
        local factory=module('powertrain/'..row.type,false)
        -- Mod wrappers may export only new(); the resulting device owns its
        -- categories. Do not require metadata that native powertrain never needs.
        if not factory.deviceCategories or factory.deviceCategories.engine then
          local input=deepcopy(row)
          tableMergeRecursive(input,data[row.name] or {})
          -- Visual node links are immaterial to rated power; no chassis is compiled.
          input.torqueReactionNodes_nodes=nil
          input.gearRatio=input.gearRatio or 1
          input.cumulativeGearRatio=input.gearRatio
          input.isPhysicallyDisconnected=true
          local device=assert(factory.new(input),'Не удалось создать двигатель '..row.name)
          devices[row.name]=device
          if device.deviceCategories and device.deviceCategories.engine then
            local power=device.maxPower or (device.torqueData and device.torqueData.maxPower)
            if not power and device.getTorqueData then power=device:getTorqueData().maxPower end
            assert(type(power)=='number' and power==power and power>0 and power<=10000,'Двигатель не сообщил мощность')
            total,count=total+power,count+1
          end
          checkpoint(true)
        end
      end
    end
    assert(count>0,'Нет двигателя в комплектации '..model)
    return total
  end
  function self.start(model,key)
    warnings=0
    local co=coroutine.create(function() return engines(model,assemble(model,key)) end)
    return {thread=co,model=model,key=key}
  end
  function self.step(job,budget)
    deadline=clock()+(budget or 0.004)
    local ok,result=coroutine.resume(job.thread)
    if not ok then return true,nil,tostring(result) end
    if coroutine.status(job.thread)=='dead' then return true,result,nil,warnings end
    return false
  end
  return self
end
return M
