-- Live validation while selecting a race finish. Does not rebuild the native GPS route.
local M = {}
local savedColor, appliedColor, text, valid
function M.clear()
  if appliedColor and core_groundMarkers.color==appliedColor then core_groundMarkers.color=savedColor end
  savedColor,appliedColor,text,valid=nil,nil,nil,nil
end
function M.update(enabled,player)
  if not enabled or not player then M.clear() return end
  local route,why=require('ge/extensions/streetRacers/routes').fromGPS(player)
  valid=route~=nil
  text=route and string.format('Маршрут: %.0f м — можно гоняться',route.length) or why
  if not appliedColor or core_groundMarkers.color~=appliedColor then savedColor=core_groundMarkers.color end
  appliedColor=valid and {0.1,0.9,0.35} or {1,0.08,0.08}
  core_groundMarkers.color=appliedColor
end
function M.draw()
  if not text or not ui_imgui then return end
  local im=ui_imgui
  im.SetNextWindowPos(im.ImVec2(20,110),im.Cond_FirstUseEver)
  im.Begin('GPS-ФИНИШ###StreetRacersRoutePreview',nil,im.WindowFlags_AlwaysAutoResize+im.WindowFlags_NoCollapse)
  im.TextColored(im.ImVec4(valid and 0.2 or 1,valid and 0.95 or 0.25,0.3,1),text)
  im.End()
end
return M
