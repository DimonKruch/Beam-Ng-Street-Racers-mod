-- StreetRacers, 2026. MIT. Separate series; native missions/progress are read only.
local rules=require('streetRacers/seriesRules')
local domain=require('streetRacers/domain')
local driving=require('ge/extensions/streetRacers/raceDriving')
local M={}
function M.new(host)
  local self={phase='idle'}
  local catalog,job,serial={},nil,0
  function self.busy() return job~=nil end
  function self.owns(id)
    for _,entry in ipairs(job and job.entries or {}) do if entry.id==id and host.vehicle(id)==entry.car then return true end end
    return false
  end
  function self.opponents() return job and job.entries or {} end
  function self.release()
    if not job then return end
    local old=job job=nil self.phase='idle'
    if old.tracker then pcall(old.tracker.stopRace,old.tracker) end
    if old.markers then old.markers.onClientEndMission() end
    for _,car in ipairs(old.cars or {}) do
      local ok,id=pcall(function() return car:getID() end)
      if ok and host.vehicle(id)==car then host.delete(car) end
    end
  end
  function self.catalog()
    if #catalog>0 then return catalog end
    for _,file in ipairs(FS:findFiles('/gameplay/missions/west_coast_usa/aiRace/','info.json',-1,false,false) or {}) do
      local data=jsonReadFile(file)
      local track=data and data.missionTypeData
      if track and type(track.raceFile)=='string' and track.raceFile~='' then
        catalog[#catalog+1]={id=file,name=data.name or file,mode='race',file=track.raceFile,
          participants=rules.participants(track.racerCount,'race'),laps=math.max(1,tonumber(track.lapCount) or 1)}
      end
    end
    table.sort(catalog,function(a,b) return a.id<b.id end)
    catalog[#catalog+1]={id='alder',name='Alder Drag Strip',mode='drag',length=402,laps=1,participants=2}
    return catalog
  end
  function self.track(id)
    for _,row in ipairs(self.catalog()) do
      if row.id==id then
        if row.mode=='drag' then local d=host.dragInfo() row.length=d and d.length or 402 return row end
        if not row.path then
          local p=require('/lua/ge/extensions/gameplay/race/path')('Street championship')
          p:onDeserialized(assert(jsonReadFile(row.file),'Нет файла трассы')) p:autoConfig()
          local ai=p:getAiPath()
          assert(ai and #ai>=2,'На трассе нет маршрута AI')
          -- Native routing measures the roads between checkpoints, not the chords.
          local length=p.aiPathDistance
          assert(domain.finite(length) and length>0,'Не удалось измерить длину трассы')
          local starts={}
          for _,sp in ipairs(p.startPositions.sorted) do if sp.group=='start' then starts[#starts+1]=sp end end
          assert(starts[1],'На трассе нет стартовой позиции')
          local direction=starts[1].rot*vec3(0,1,0)
          local segment=p.config.graph and p.config.graph[p.config.startSegments[1]]
          local target=segment and p.pathnodes.objects[segment.targetNode]
          if target and direction:dot(target.pos-starts[1].pos)<0 then direction=-direction end
          while #starts<row.participants do
            -- Extend the private grid behind all native slots, never inside a
            -- native row or in front of the timing line.
            local back=0
            for _,sp in ipairs(starts) do back=math.min(back,(sp.pos-starts[1].pos):dot(direction)) end
            local sp=p.startPositions:create('Street championship opponent '..#starts)
            sp:set(starts[1].pos+direction*(back-12),starts[1].rot)
            starts[#starts+1]=sp
          end
          assert(#starts>=2,'На трассе недостаточно стартовых позиций')
          row.starts,row.direction=starts,direction
          row.path=p row.mode=p.config.closed and 'circuit' or 'sprint'
          row.laps=p.config.closed and row.laps or 1
          row.length=length*row.laps
        end
        return row
      end
    end
  end
  function self.start(id,power,inventoryId,stake)
    if job then return false,'Заезд уже готовится.' end
    local ok,row=pcall(self.track,id)
    if not ok or not row then return false,'Трасса недоступна: '..tostring(row) end
    if not rules.valid(stake,power,row.length,host.balance()) then return false,'Ставка недоступна для мощности, длины трассы или баланса.' end
    local lineup=rules.lineup(power,host.catalog(),row.mode,row.participants-1)
    if not lineup then return false,'Нет подходящих машин соперников.' end
    serial=serial+1
    job={track=row,playerId=host.playerId(),inventoryId=inventoryId,power=power,stake=stake,
      token='streetSeries:'..serial..':'..os.time(),elapsed=0,cars={},entries={},lineup=lineup}
    self.phase='spawning'
    return self.spawnNext()
  end
  function self.spawnNext()
    local index=#job.entries+1
    local success,car,cars=pcall(host.spawn,job.lineup[index],job.track,index)
    if not success or not car then self.release() return false,'Не удалось загрузить соперника; ставка не списана.' end
    local found=false
    for _,object in ipairs(cars or {}) do job.cars[#job.cars+1]=object if object==car then found=true end end
    if not found then job.cars[#job.cars+1]=car end
    job.entries[index]={car=car,id=car:getID(),token=job.token..':'..index}
    job.id=job.entries[1].id
    job.elapsed,job.sim=0,0 self.phase='spawning'
    host.freeze(car:getID(),true)
    return true
  end
  function self.receive(data)
    local entry=job and job.entries[#job.entries]
    if not entry or self.phase~='measuring' or data.token~=entry.token or data.vehicleId~=entry.id or not self.owns(entry.id) then return false end
    if not domain.finite(data.power) or data.power<=0 or math.abs(data.power/job.power-1)>0.025 then
      self.release() host.message(data.error or 'Соперник не прошёл замер мощности.','warning') return false
    end
    entry.power=data.power
    if #job.entries<#job.lineup then self.phase='next' return true end
    local name=_tr and _tr(job.track.name) or job.track.name
    job.profile={name='Street championship / '..(type(name)=='string' and name or job.track.name),power=data.power,playerPower=job.power,
      accepted=true,pending=false,playerPending=false,playerPowerSource='engine',minBet=50,maxBet=rules.limit(job.power,job.track.length),
      streetSeries=true,aggression=1,participants=job.track.participants,prizePool=job.track.participants*job.stake}
    self.phase='ready'
    return true
  end
  function self.route(p,o)
    if not job then return end
    if job.track.mode=='drag' then return host.dragRoute(p,o) end
    local starts=job.track.starts
    return {kind='series',length=job.track.length,series=job.track,path={},opponentCount=#job.entries,grid={
      playerPos=starts[1].pos,opponentPos=starts[2].pos,direction=job.track.direction,starts=starts}}
  end
  function self.stage(id,index)
    if not job then return false end
    if id~=job.playerId then id=job.entries[index or 1].id end
    local sp=job.track.starts[id==job.playerId and 1 or (index or 1)+1]
    if not sp then return false,'На трассе недостаточно стартовых позиций.' end
    sp:moveResetVehicleTo(id,false,false)
    host.freeze(id,true)
    return true
  end
  function self.checkGrid()
    if not job then return false end
    local cars,ids={},{job.playerId}
    for _,entry in ipairs(job.entries) do ids[#ids+1]=entry.id end
    for i,id in ipairs(ids) do
      local car=host.vehicle(id)
      if not car or not car:getActive() or car:getPosition():distance(job.track.starts[i].pos)>15 then return false end
      local centre=vec3(car:getSpawnWorldOOBB():getCenter())
      for _,other in ipairs(cars) do if centre:distance(other)<4 then return false end end
      cars[#cars+1]=centre
    end
    return true
  end
  function self.go()
    if not self.checkGrid() then return false end
    local r=require('/lua/ge/extensions/gameplay/race/race')()
    r:setPath(job.track.path) r.lapCount=job.track.laps r.autoAiMode=false
    r.useLapTimesApp=false r.useHotlappingApp=false
    local ids={job.playerId}
    for _,entry in ipairs(job.entries) do ids[#ids+1]=entry.id end
    r:setVehicleIds(ids) r:startRace()
    job.time=0
    job.tracker=r
    local markers=require('scenario/race_marker')
    job.markers=markers
    markers.init()
    local checkpoints={}
    for _,pn in ipairs(job.track.path.pathnodes.sorted) do
      checkpoints[#checkpoints+1]={name=pn.id,pos=pn.pos,radius=pn.radius,normal=pn.hasNormal and pn.normal or nil}
    end
    for i,cp in ipairs(checkpoints) do cp.nextPos=checkpoints[i%#checkpoints+1].pos end
    markers.setupMarkers(checkpoints)
    self.refreshMarkers()
    for _,entry in ipairs(job.entries) do
      entry.start=vec3(entry.car:getPosition()) entry.previous=entry.start
      r:startAiVehicle(entry.id,driving.aggression)
      driving.configure(entry.car)
      host.freeze(entry.id,false)
    end
    host.freeze(job.playerId,false)
    return true
  end
  function self.refreshMarkers()
    if not job or not job.markers or not job.tracker then return end
    local p=job.tracker.states[job.playerId]
    local modes={}
    for _,e in ipairs(p and p.nextPathnodes or {}) do modes[e[1].id]=e[2]=='recovery' and 'default' or e[2] end
    for _,e in ipairs(p and p.overNextPathnodes or {}) do modes[e[1].id]=modes[e[1].id] or 'next' end
    job.markers.setModes(modes)
  end
  function self.render(dt,dtSim)
    if job and job.markers then job.markers.render(dt,dtSim) end
  end
  function self.minimap(td)
    if job and job.markers then job.markers.drawOnMinimap(td) end
  end
  function self.progress()
    if not job or not job.tracker then return end
    local p=job.tracker.states[job.playerId]
    return p and {lap=math.min(job.track.laps,(p.currentLap or 0)+1),laps=job.track.laps,place=p.placement,
      participants=job.track.participants,prizePool=job.stake*job.track.participants} or nil
  end
  function self.result(dt)
    if not job or not job.tracker then return end
    job.time=job.time+dt
    local launched=true
    for _,entry in ipairs(job.entries) do
      if not self.owns(entry.id) then return 'void' end
      local pos=vec3(entry.car:getPosition()) local speed=entry.car:getVelocity():length()
      if pos:distance(entry.previous)>math.max(35,(speed+25)*dt*2) then return 'void' end
      if speed>1 and pos:distance(entry.start)>=3 then entry.launched=true end
      entry.previous=pos launched=launched and entry.launched
    end
    if job.time>=12 and not launched then return 'void' end
    local r=job.tracker r:onUpdate(dt)
    self.refreshMarkers()
    local opponents={}
    for _,entry in ipairs(job.entries) do
      if not r.states[entry.id] then return 'void' end
      opponents[#opponents+1]=r.states[entry.id]
    end
    if not r.states[job.playerId] then return 'void' end
    local outcome=rules.outcome(r.states[job.playerId],opponents)
    if outcome and not launched then return 'void' end
    return outcome
  end
  function self.update(dt,dtSim,allowed)
    if not job or self.phase=='racing' then return end
    job.elapsed=job.elapsed+dt job.sim=(job.sim or 0)+dtSim
    local present=true
    for _,entry in ipairs(job.entries) do present=present and self.owns(entry.id) end
    if not allowed or host.playerId()~=job.playerId or not present or job.elapsed>25 then
      self.release() host.message('Подготовка Street championship отменена. Деньги не списаны.','warning') return
    end
    if self.phase=='next' then
      local ok,why=self.spawnNext()
      if not ok then host.message(why,'warning') end
      return
    end
    if self.phase=='spawning' and job.elapsed>=1 and job.sim>=0.25 then
      local entry=job.entries[#job.entries]
      self.phase='measuring' host.configure(entry.id,job.power,entry.token)
    end
    if self.phase=='ready' and not host.waiting() then
      self.phase='racing'
      local success,ok,why=pcall(host.ready,job.id,job.profile,job.stake,job.track.mode)
      if not success or not ok then self.release() host.message(why or tostring(ok),'warning') end
    end
  end
  return self
end
return M
