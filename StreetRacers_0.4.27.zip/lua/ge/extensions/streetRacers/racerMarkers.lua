-- StreetRacers, 2026. MIT. Dynamic icons share the native big-map atlas.
local M = {}
local icons={}
local function renderer()
  return gameplay_playmodeMarkers and gameplay_playmodeMarkers.getBigmapRendererObj()
end
function M.clear()
  local r=next(icons) and renderer()
  if r then for _,id in pairs(icons) do r:removeIconById(id) end end
  icons={}
end
function M.update(rows,enabled)
  if not enabled then M.clear() return end
  local r=renderer()
  if not r then return end
  local live={}
  for _,row in ipairs(rows) do
    local name='streetRacersReady:'..row.id
    local info=r:getIconByName(name)
    if not info then
      icons[row.id]=r:addIcon(name,'mission_airace01_triangle',row.pos)
      info=r:getIconByName(name)
    end
    if info then
      info.worldPosition=row.pos+vec3(0,0,2)
      info.color=ColorI(80,240,187,255)
      info.customSizeFactor=0.65
      live[row.id]=true
    end
  end
  for vehicleId,id in pairs(icons) do
    if not live[vehicleId] then r:removeIconById(id) icons[vehicleId]=nil end
  end
end
function M.minimap(td,rows)
  local utils=ui_apps_minimap_utils
  if not utils then return end
  local xx,xy,yx,yy,ox,oy=utils.getWorldToMapTransform()
  local fill,border=color(80,240,187,255),color(15,32,39,255)
  for _,row in ipairs(rows) do
    local p=row.pos
    td:circleMarker(p.x,p.y,5,2,utils.dpi or 1,fill,border,xx,xy,yx,yy,ox,oy,90)
  end
end
return M
