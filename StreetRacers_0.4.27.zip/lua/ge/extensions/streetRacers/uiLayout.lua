-- Geometry uses the current font and display size, including an expanded HUD.
local M={gap=12,margin=20}
function M.viewport(im)
  local size=im.GetIO and im.GetIO().DisplaySize
  return {x=size and size.x or 1920,y=size and size.y or 1080}
end
function M.window(im,width,height)
  local display=M.viewport(im)
  return math.min(width,display.x-2*M.margin),math.min(height,display.y-2*M.margin)
end
function M.hudPosition(display,size,bounds)
  local m,g=M.margin,M.gap
  if not bounds then return {x=m,y=math.max(m,math.min(240,display.y-size.y-m))} end
  local x=math.max(m,math.min(bounds.x,display.x-size.x-m))
  if bounds.y+bounds.h+g+size.y<=display.y-m then return {x=x,y=bounds.y+bounds.h+g} end
  if bounds.x+bounds.w+g+size.x<=display.x-m then
    return {x=bounds.x+bounds.w+g,y=math.max(m,math.min(bounds.y,display.y-size.y-m))}
  end
  if bounds.x-g-size.x>=m then return {x=bounds.x-g-size.x,y=math.max(m,bounds.y)} end
  if bounds.y-g-size.y>=m then return {x=x,y=bounds.y-g-size.y} end
  -- Extremely small displays: keep Start accessible by suppressing this passive
  -- overlay while the menu is open. The HUD returns as soon as the menu closes.
  return nil
end
return M
