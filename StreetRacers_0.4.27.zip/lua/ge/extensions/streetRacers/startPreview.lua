-- StreetRacers, 2026. MIT. Read-only, throttled preview of the actual grid rules.
local M={}
local routes=require('ge/extensions/streetRacers/routes')
local view,timer=nil,1
local cachedRoute,cachedReason,origin,targetPoint,targetName,playerId
function M.clear()
  view,timer=nil,1
  cachedRoute,cachedReason,origin,targetPoint,targetName,playerId=nil,nil,nil,nil,nil,nil
end
function M.getView() return view end
function M.update(dt,enabled,player,opponent,mode)
  if not enabled or not player or not opponent then M.clear() return end
  timer=timer+dt
  if timer<0.5 then return end
  timer=0
  if mode=='drag' then view=routes.dragStartZone(player,opponent) return end
  local target=core_groundMarkers.getTargetPos()
  local isName=type(target)=='string'
  local point=target and not isName and vec3(target) or nil
  local sameTarget=(isName and targetName==target) or (point and targetPoint and point:squaredDistance(targetPoint)<0.01) or
    (not target and not targetName and not targetPoint)
  if not origin or playerId~=player:getID() or player:getPosition():squaredDistance(origin)>1 or not sameTarget then
    cachedRoute,cachedReason=routes.fromGPS(player)
    origin,playerId=vec3(player:getPosition()),player:getID()
    targetPoint,targetName=point,isName and target or nil
  end
  view=cachedRoute and routes.startZone(player,opponent,cachedRoute) or {valid=false,text=cachedReason}
end
local function line(a,b,c,w)
  debugDrawer:drawLineInstance(a,b,w or 3,c)
end
local function slot(pos,grid,width,length,c)
  local p=pos+vec3(0,0,0.08)
  local halfF=grid.direction*(length*0.5)
  local halfR=grid.right*(width*0.5+0.10)
  local a,b,d,e=p+halfF+halfR,p+halfF-halfR,p-halfF-halfR,p-halfF+halfR
  if debugDrawer.drawQuadSolid then
    local cr,cg,cb=c.r or c[1],c.g or c[2],c.b or c[3]
    debugDrawer:drawQuadSolid(a,b,d,e,ColorF(cr,cg,cb,0.16))
    local stripe=grid.direction*0.18+vec3(0,0,0.025)
    debugDrawer:drawQuadSolid(a+vec3(0,0,0.025),b+vec3(0,0,0.025),b+stripe,a+stripe,ColorF(cr,cg,cb,0.85))
  end
  line(a,b,c,5) line(b,d,c,3) line(d,e,c,3) line(e,a,c,3)
  for i=0,2 do
    local centre=p-halfF+grid.direction*(0.8+i*1.1)
    local tip=centre+grid.direction*0.45
    line(centre-grid.right*0.32,tip,c,3)
    line(tip,centre+grid.right*0.32,c,3)
  end
end
function M.draw()
  if not view or not view.grid or not debugDrawer then return end
  local g=view.grid
  local c=view.valid and ColorF(0.96,0.46,0.10,0.98) or ColorF(1,0.20,0.12,0.98)
  -- Draw at road level; the staging pose's lift is only for safeTeleport.
  slot(g.playerPos-vec3(0,0,0.3),g,g.widthP,g.lengthP or 6,c)
  slot(g.opponentPos-vec3(0,0,0.3),g,g.widthO,g.lengthO or 6,c)
  debugDrawer:drawTextAdvanced(g.centre+vec3(0,0,2.5),
    view.valid and 'СТАРТ' or string.format('ЗОНА СТАРТА  •  %.0f м',view.distance or 0),
    c,true,false,ColorI(20,22,25,235),false,true)
  local lineHalf=g.separation*0.5+math.max(g.widthP or 2,g.widthO or 2)*0.5+0.4
  line(g.centre-g.right*lineHalf,g.centre+g.right*lineHalf,c,5)
end
return M
