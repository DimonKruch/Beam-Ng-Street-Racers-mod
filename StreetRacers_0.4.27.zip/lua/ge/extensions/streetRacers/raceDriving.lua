-- StreetRacers, 2026. MIT. Applied AFTER native driveUsingPath resets AI options.
local M={aggression=0.78}
function M.configure(car)
  car:queueLuaCommand([[ai.setRacing(false); ai.setAggressionMode('off'); ai.setAggression(0.78);
    ai.setAvoidCars('on'); ai.setParameters({staticFrictionCoefMult=0.85,turnForceCoef=2,
      understeerThrottleControl='on',oversteerThrottleControl='on',throttleTcs='on',
      abBrakeControl='on',underSteerBrakeControl='on'})]])
end
return M
