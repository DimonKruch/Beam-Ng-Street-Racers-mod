-- StreetRacers, 2026. MIT. Vector HUD shared with the development preview renderer.
local rules = require('streetRacers/domain')
local layout = require('ge/extensions/streetRacers/uiLayout')
local skin = require('ge/extensions/streetRacers/uiTheme')
local M = {}
local colors={text=skin.text,muted=skin.muted,normal=skin.accent,amber=skin.warning,red=skin.danger,track=skin.track}

function M.scene(view)
  local items, byName, extra = {}, {}, {}
  local function rect(x,y,w,h,color,radius) items[#items+1]={kind='rect',x=x,y=y,w=w,h=h,color=color,radius=radius or 0} end
  local function text(x,y,value,color) items[#items+1]={kind='text',x=x,y=y,text=value,color=color or colors.text} end
  for _, wheel in ipairs(view.wheels or {}) do
    local name = string.upper(wheel.name)
    if name=='FL' or name=='FR' or name=='RL' or name=='RR' then byName[name] = wheel else extra[#extra+1]=wheel end
  end
  local rows={}
  for _,name in ipairs({'FL','FR','RL','RR'}) do rows[#rows+1]={name=name,wheel=byName[name]} end
  table.sort(extra,function(a,b) return a.name<b.name end)
  for _,wheel in ipairs(extra) do rows[#rows+1]={name=wheel.name,wheel=wheel} end
  local worst, hottest, punctured, y = 1, false, false, 0
  for _,row in ipairs(rows) do
    local wheel = row.wheel
    local condition = wheel and rules.clamp(wheel.condition,0,1) or 0
    local color = not wheel and colors.muted or ((wheel.deflated or condition<=0.25) and colors.red or condition<=0.55 and colors.amber or colors.normal)
    text(0,y,row.name,colors.muted)
    rect(28,y+5,66,5,colors.track,2)
    if wheel then rect(28,y+5,66*condition,5,color,2) end
    text(104,y,wheel and (wheel.deflated and 'ПРОКОЛ' or string.format('%.0f%%',condition*100)) or '--',color)
    local hot = wheel and wheel.temperature > (rules.tyreProfiles[wheel.compound] or rules.tyreProfiles.road).hot
    text(166,y,wheel and string.format('%.0f °C',wheel.temperature) or '--',hot and colors.red or colors.text)
    if wheel then
      worst, hottest = math.min(worst,condition), hottest or hot
      punctured = punctured or wheel.deflated
    end
    y=y+20
  end
  local kindLabels={engine='Двигатель',gearbox='Коробка',differential='Редуктор',clutch='Сцепление'}
  local byKind={}
  for _,row in ipairs(view.mechanical or {}) do
    if kindLabels[row.kind] and rules.finite(row.condition) then
      byKind[row.kind]=math.min(byKind[row.kind] or 1,rules.clamp(row.condition,0,1))
    end
  end
  if next(byKind) then
    y=y+6
    text(0,y,'УЗЛЫ',colors.amber)
    y=y+18
    for _,kind in ipairs({'engine','gearbox','differential','clutch'}) do
      local condition=byKind[kind]
      local color=not condition and colors.muted or condition<=0.25 and colors.red or condition<=0.55 and colors.amber or colors.normal
      text(0,y,kindLabels[kind],colors.muted)
      rect(94,y+5,96,5,colors.track,2)
      if condition then rect(94,y+5,96*condition,5,color,2) end
      text(200,y,condition and string.format('%.0f%%',condition*100) or '--',color)
      y=y+18
    end
  end
  local oil,coolant,engineAlert,critical
  for _,row in ipairs(view.mechanical or {}) do
    if row.kind=='engine' then
      if rules.finite(row.oilTemperature) then oil=math.max(oil or row.oilTemperature,row.oilTemperature) end
      if rules.finite(row.coolantTemperature) then coolant=math.max(coolant or row.coolantTemperature,row.coolantTemperature) end
      if row.alert and (not engineAlert or row.critical) then engineAlert,critical=row.alert,row.critical end
    end
  end
  if oil or coolant then
    text(0,y,string.format('Масло %s / ОЖ %s',oil and string.format('%.0f°C',oil) or '--',coolant and string.format('%.0f°C',coolant) or '--'),colors.muted)
    y=y+18
  end
  if engineAlert then text(0,y,engineAlert,critical and colors.red or colors.amber) y=y+20 end
  local status, color
  if #(view.wheels or {})==0 then status,color='Ожидание данных шин',colors.muted
  elseif view.suspended then status,color='Обслуживание',colors.muted
  elseif punctured then status,color='Нужна техпомощь',colors.red
  elseif worst<=0.25 then status,color='Нужна замена шин',colors.red
  elseif hottest then status,color='Перегрев шин',colors.red end
  if status then text(0,y+2,status,color) y=y+20 end
  return {width=244,height=y,items=items}
end

function M.draw(view,position)
  if not ui_imgui or not view then return end
  local im = ui_imgui
  local scene = M.scene(view)
  local display=layout.viewport(im)
  local size={x=scene.width*im.GetFontSize()/13+20,y=scene.height*im.GetFontSize()/13+im.GetFontSize()+26}
  local hudPos=layout.hudPosition(display,size,position)
  if not hudPos then return end
  im.SetNextWindowPos(im.ImVec2(hudPos.x,hudPos.y),position and im.Cond_Always or im.Cond_Appearing)
  local style=skin.push(im,true)
  im.SetNextWindowBgAlpha(0.92)
  im.SetNextWindowCollapsed(false,im.Cond_Always)
  local visible = im.Begin('ШИНЫ И УЗЛЫ###StreetRacersTyreHUDCompact',nil,
    im.WindowFlags_AlwaysAutoResize + im.WindowFlags_NoCollapse + im.WindowFlags_NoFocusOnAppearing)
  if visible then
    local origin, drawList = im.GetCursorScreenPos(), im.GetWindowDrawList()
    local scale = im.GetFontSize()/13
    local function point(x,y) return im.ImVec2(origin.x+x*scale,origin.y+y*scale) end
    for _, item in ipairs(scene.items) do
      local color = im.GetColorU322(im.ImVec4(unpack(item.color)))
      if item.kind=='rect' then
        im.ImDrawList_AddRectFilled(drawList,point(item.x,item.y),point(item.x+item.w,item.y+item.h),color,item.radius*scale)
      elseif item.kind=='line' then
        im.ImDrawList_AddLine(drawList,point(item.x,item.y),point(item.x2,item.y2),color,item.width*scale)
      else
        im.ImDrawList_AddText1(drawList,point(item.x,item.y),color,item.text)
      end
    end
    im.Dummy(im.ImVec2(scene.width*scale,scene.height*scale))
  end
  im.End()
  skin.pop(im,style)
end
return M
