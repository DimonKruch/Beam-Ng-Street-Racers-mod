-- StreetRacers, 2026. MIT. Native driving AI on a private, straight lane graph.
local M={}
local active=false
local previousAliases,previousRules
local previousSetMap,mapHook,privateMap
local telemetry={}
function M.getTelemetry()
  return {active=active,privateMap=active and mapmgr.mapData==privateMap,ignoredMaps=telemetry.ignoredMaps or 0,
    mode=ai.mode,steering=input.state and input.state.steering and input.state.steering.val}
end

function M.stop()
  if not active then return end
  active=false
  if mapmgr.setMap==mapHook then mapmgr.setMap=previousSetMap end
  previousSetMap,mapHook,privateMap=nil,nil,nil
  ai.setMode('disabled')
  ai.setRacing(false)
  mapmgr.clearCustomMap()
  mapmgr.nodeAliases=previousAliases
  mapmgr.rules=previousRules
  previousAliases,previousRules=nil,nil
  mapmgr.requestMap()
end
function M.start(points)
  M.stop()
  local graph=require('graphpath').newGraphpath()
  local path={}
  for i,p in ipairs(points) do
    path[i]='sr_drag_'..i
    graph:setPointPositionRadius(path[i],vec3(p.x,p.y,p.z),p.r)
    if i>1 then graph:uniEdge(path[i-1],path[i],graph.positions[path[i-1]]:distance(graph.positions[path[i]]),1,160,nil,false) end
  end
  -- driveUsingPath normally requests the world map when changing AI mode.
  -- This single synchronous call supplies its own graph; never request a world
  -- map reply that could overwrite it. Always restore the public function.
  local request=mapmgr.requestMap
  previousAliases=mapmgr.nodeAliases
  previousRules=mapmgr.rules
  -- Private entrants have never requested the world map. Native AI still
  -- validates path names through this table even when using a custom graph.
  mapmgr.nodeAliases={}
  mapmgr.rules=mapmgr.rules or {rightHandDrive=false}
  mapmgr.requestMap=function() end
  -- Circuit racing builds offset/overtaking plans, even with a private graph.
  -- A drag entrant must follow the lane centre with the normal path follower.
  ai.setRacing(false)
  local ok,why=pcall(ai.driveUsingPath,{path=path,aggression=1,avoidCars='off',driveInLane='off',routeSpeedMode='off',turnForceCoef=4})
  mapmgr.requestMap=request
  if not ok then
    mapmgr.nodeAliases,mapmgr.rules=previousAliases,previousRules
    previousAliases,previousRules=nil,nil
    error(why)
  end
  mapmgr.setCustomMap(graph)
  active=true
  privateMap=graph
  telemetry={}
  -- Spawn/tracking can already have a world-map reply in flight. Applying it
  -- would invalidate native AI's currentRoute after the first driving frame.
  local applyMap=mapmgr.setMap
  local guard
  guard=function(...)
    if active and mapHook==guard then telemetry.ignoredMaps=(telemetry.ignoredMaps or 0)+1 return end
    return applyMap(...)
  end
  previousSetMap,mapHook=applyMap,guard
  mapmgr.setMap=guard
  ai.setAggressionMode('off')
  controller.setFreeze(0)
  input.event('parkingbrake',0,1)
end
M.onReset=M.stop
M.onExtensionUnloaded=M.stop
return M
