-- StreetRacers, 2026. MIT. Uses native powertrain damage so stock saves/repairs work.
local rules=require('streetRacers/domain')
local fatigue=require('streetRacers/mechanics')
local M={}
function M.new()
  local self,entries,floors={},{},{}
  local power,rpmMax=150,6000
  local pendingReset=false
  local function condition(device)
    local ok,value=pcall(device.getPartCondition,device)
    return ok and rules.finite(value) and rules.clamp(value,0,1) or nil
  end
  local function engineStatus(d)
    local t=type(d.thermals)=='table' and d.thermals or {}
    local e=electrics.values
    local function native(flag)
      return damageTracker and damageTracker.getDamage and damageTracker.getDamage('engine',flag)==true
    end
    local oil=rules.finite(t.oilTemperature) and t.oilTemperature or e.oiltemp
    local coolant=rules.finite(t.coolantTemperature) and t.coolantTemperature or nil
    local alert,critical
    if d.isBroken then alert,critical='Двигатель повреждён',true
    elseif t.engineBlockMelted or t.cylinderWallsMelted then alert,critical='Тепловое повреждение двигателя',true
    elseif t.connectingRodBearingsDamaged then alert,critical='Повреждены вкладыши',true
    elseif native('starvedOfOil') or native('oilLevelCritical') then alert,critical='Нет смазки — сбросьте газ',true
    elseif native('oilOverheating') then alert,critical='Перегрев масла — сбросьте газ',true
    elseif t.headGasketBlown then alert,critical='Повреждена прокладка ГБЦ',true
    elseif t.pistonRingsDamaged then alert,critical='Повреждены кольца',true
    elseif rules.finite(oil) and oil>=130 then alert='Горячее масло — сбросьте газ'
    elseif rules.finite(coolant) and coolant>=110 then alert='Горячий двигатель — сбросьте газ' end
    return rules.finite(oil) and oil or nil,rules.finite(coolant) and coolant or nil,alert,critical
  end
  function self.connect()
    entries={}
    if not powertrain or not powertrain.getDevices then return end
    local paths={}
    for _,row in pairs(v.data.powertrain or {}) do
      if type(row)=='table' and row.name then paths[row.name]=row.partPath end
    end
    local total=0
    for name,d in pairs(powertrain.getDevices()) do
      local categories=d.deviceCategories or {}
      if categories.engine and rules.finite(d.maxPower) then total=total+d.maxPower end
      if categories.engine and rules.finite(d.maxRPM) then rpmMax=d.maxRPM end
      local kind=categories.engine and 'engine' or categories.gearbox and 'gearbox' or
        categories.differential and 'differential' or categories.clutch and 'clutch'
      local field=kind=='engine' and 'damageDynamicFrictionCoef' or kind=='clutch' and 'damageClutchFreePlayCoef' or 'damageFrictionCoef'
      if kind and d.getPartCondition and rules.finite(d[field]) then
        entries[#entries+1]={name=name,device=d,kind=kind,path=paths[name],field=field,
          range=kind=='engine' and 4 or kind=='clutch' and 19 or kind=='differential' and 9 or 49}
      end
    end
    if total>0 then power=total end
  end
  function self.update(dt,speed)
    local e=electrics.values
    if (controller and controller.isFrozen) or e.freezeState==true or e.freezeState==1 then return end
    local rpmRatio=rules.clamp((tonumber(e.rpm) or 0)/math.max(1000,rpmMax),0,1.3)
    local engineLoad,boost,nitrous=0,0,0
    local oilTemperature,coolantTemperature
    for _,entry in ipairs(entries) do
      if entry.kind=='engine' then
        local d=entry.device
        if rules.finite(d.instantEngineLoad) then engineLoad=math.max(engineLoad,math.abs(d.instantEngineLoad)) end
        if rules.finite(d.forcedInductionCoef) then boost=math.max(boost,d.forcedInductionCoef-1) end
        if rules.finite(d.nitrousOxideTorque) and d.nitrousOxideTorque>0 then
          nitrous=math.max(nitrous,d.nitrousOxideTorque/math.max(1,math.abs(d.outputTorque1 or 0),d.nitrousOxideTorque))
        end
        local oil,coolant=engineStatus(d)
        if oil then oilTemperature=math.max(oilTemperature or oil,oil) end
        if coolant then coolantTemperature=math.max(coolantTemperature or coolant,coolant) end
      end
    end
    for _,entry in ipairs(entries) do
      local d=entry.device
      local id=entry.name..':'..tostring(entry.path)
      if pendingReset and floors[id] then d[entry.field]=math.max(d[entry.field],floors[id]) end
      local av=d.outputAV1 or d.inputAV or 0
      local load=engineLoad
      if entry.kind~='engine' then
        local torque=d.parent and d.parentOutputTorqueName and d.parent[d.parentOutputTorqueName] or d.inputTorque
        if rules.finite(torque) then load=rules.clamp(math.abs(torque)/math.max(100,rules.finite(d.maxExpectedInputTorque) and d.maxExpectedInputTorque or power*2),0,1.5) end
        -- A disconnected driveline or an open clutch is not doing transmission work.
        if d.isPhysicallyDisconnected then load=0 end
      end
      if not d.isBroken then
        local loss=fatigue.loss(entry.kind,{power=power,rpmRatio=rpmRatio,load=load,av=av,speed=speed,
          boost=boost,nitrous=nitrous,
          temperature=entry.kind=='engine' and (oilTemperature or coolantTemperature or e.oiltemp or e.watertemp) or 90},dt)
        -- Never reduce a native damage coefficient already above our fatigue cap.
        if d[entry.field]<1+entry.range then d[entry.field]=math.min(1+entry.range,d[entry.field]+entry.range*loss) end
        if entry.kind=='engine' and d[entry.field]>=1+entry.range and d.lockUp then d:lockUp() end
      end
      floors[id]=d[entry.field]
    end
    pendingReset=false
  end
  function self.snapshot()
    local rows={}
    for _,entry in ipairs(entries) do
      local value=condition(entry.device)
      if value then
        local row={name=entry.name,kind=entry.kind,path=entry.path,condition=value}
        if entry.kind=='engine' then row.oilTemperature,row.coolantTemperature,row.alert,row.critical=engineStatus(entry.device) end
        rows[#rows+1]=row
      end
    end
    return rows
  end
  function self.reset()
    pendingReset=true
    for _,entry in ipairs(entries) do
      local floor=floors[entry.name..':'..tostring(entry.path)]
      if floor then entry.device[entry.field]=math.max(entry.device[entry.field],floor) end
      if entry.kind=='engine' and entry.device[entry.field]>=1+entry.range and entry.device.lockUp then entry.device:lockUp() end
    end
  end
  function self.serialize() return floors end
  function self.deserialize(saved) floors=type(saved)=='table' and saved or {} pendingReset=true end
  return self
end
return M
