-- StreetRacers, 2026. MIT. Tyres run only for owned cars; opponents allow a read-only power query.
local M = {}
local rules = require('streetRacers/domain')
local session, generation, states, bindings = nil, nil, {}, {}
local lastHorn, timer, sequence, multiplier = false, 0, 0, 1
local baseline = {}
local mechanics=require('vehicle/extensions/streetRacersMechanics').new()

local function send(method, data)
  obj:queueGameEngineLua('if career_modules_streetRacers then career_modules_streetRacers.' .. method .. '(' .. serialize(data) .. ') end')
end

local function inspect(method, token)
  local power, count, complete = 0, 0, true
  local devicesOk, devices = pcall(function() return powertrain.getDevicesByCategory('engine') end)
  if not devicesOk then complete=false end
  for _, engine in pairs(devicesOk and devices or {}) do
    count = count+1
    local value = engine.maxPower
    if (not rules.finite(value) or value<=0) and type(engine.torqueData)=='table' then value=engine.torqueData.maxPower end
    if (not rules.finite(value) or value<=0) and engine.getTorqueData then
      local ok, data = pcall(engine.getTorqueData,engine)
      value = ok and data and data.maxPower or nil
    end
    if rules.finite(value) and value>0 then power=power+value else complete=false end
  end
  local ok, stats
  if method~='receivePricePerformance' then ok,stats=pcall(function() return obj:calcBeamStats() end) end
  send(method,{vehicleId=obj:getID(),token=token,
    power=complete and count>0 and power or nil,weight=ok and stats and stats.total_weight or nil})
end

function M.inspectOpponent(token) inspect('receiveOpponentPerformance',token) end
function M.inspectPrice(token) inspect('receivePricePerformance',token) end
function M.inspectRacer(token) inspect('receivePlayerPerformance',token) end

local function describe()
  local result = {}
  for _, wheel in pairs(wheels.wheelRotators or {}) do
    if wheel.hasTire and wheel.rotatorType == 'wheel' then
      local raw = v.data.wheels[wheel.cid] or v.data.wheels[wheel.wheelID] or {}
      result[#result+1] = {name = wheel.name, partPath = raw.partPath or '', partOrigin = raw.partOrigin or '',
        deflated = wheel.isTireDeflated == true or wheel.isPunctured == true, broken = wheel.isBroken == true}
    end
  end
  return result
end

function M.snapshot(request)
  if not session then return end
  for _, w in pairs(wheels.wheelRotators or {}) do
    local state = states[w.name]
    if state then
      state.deflated = state.deflated == true or w.isTireDeflated == true or w.isPunctured == true or state.condition<=0
      state.broken = w.isBroken == true
    end
  end
  sequence = sequence+1
  send('receiveTyres', {vehicleId = obj:getID(), session = session, generation = generation,
    sequence = sequence, request = request, wheels = states, mechanical=mechanics.snapshot()})
end

function M.connect(token)
  if token ~= session then
    session, generation, sequence, states, bindings = token, nil, 0, {}, {}
  end
  mechanics.connect()
  send('vehicleReady', {vehicleId = obj:getID(), session = session, wheels = describe()})
end

function M.apply(data)
  if data.session ~= session then return end
  generation, bindings = data.generation, data.bindings or {}
  states = {}
  for name, entry in pairs(bindings) do
    states[name] = {condition = entry.condition, temperature = entry.temperature or 21, deflated = entry.deflated == true}
  end
  multiplier = data.multiplier or 1
end

local function restore()
  for wheelId, values in pairs(baseline) do
    local wheel = obj:getWheel(wheelId)
    if wheel then wheel:setFrictionThermalSensitivity(unpack(values)) end
  end
end

function M.disable()
  M.snapshot()
  restore()
  session, generation, states, bindings = nil, nil, {}, {}
end

function M.onReset()
  mechanics.reset()
  -- Reset is not a purchase. Report wear before asking GE to restore the saved set.
  M.snapshot()
  baseline = {}
  if session then M.connect(session) end
end

-- Serialize is used on Lua reload. Normal gameplay snapshots run twice per second.
function M.onSerialize() M.snapshot() return {mechanical=mechanics.serialize()} end
function M.onDeserialized(data) if data then mechanics.deserialize(data.mechanical) end end

function M.updateGFX(dt)
  if not session then return end
  local horn = electrics.values.horn
  horn = horn == true or (type(horn) == 'number' and horn > 0)
  if horn and not lastHorn then send('onHorn', {vehicleId = obj:getID(), session = session}) end
  lastHorn = horn
  if generation then
    local speed = obj:getVelocity():length()
    mechanics.update(dt,speed)
    for _, w in pairs(wheels.wheelRotators or {}) do
      local state = states[w.name]
      local wheel = obj:getWheel(w.wheelID)
      if state and wheel then
        local grip = rules.stepTyre(state, {speed = speed, wheelSpeed = w.wheelSpeed,
          slip = w.lastSlip or 0, load = w.downForceRaw or 0, ambient = 21}, dt, multiplier, bindings[w.name].compound)
        if not baseline[w.wheelID] then
          local raw = v.data.wheels[w.cid] or v.data.wheels[w.wheelID] or {}
          baseline[w.wheelID] = {raw.frictionLowTemp or -300, raw.frictionHighTemp or 1e7,
            raw.frictionLowSlope or 1e-10, raw.frictionHighSlope or 1e-10, raw.frictionSlopeSmoothCoef or 10,
            raw.frictionCoefLow or 1, raw.frictionCoefMiddle or 1, raw.frictionCoefHigh or 1}
        end
        local base = baseline[w.wheelID]
        wheel:setFrictionThermalSensitivity(base[1], base[2], base[3], base[4], base[5], base[6]*grip, base[7]*grip, base[8]*grip)
        state.deflated = state.deflated == true or w.isTireDeflated == true or w.isPunctured == true or state.condition<=0
        state.broken = w.isBroken == true
        if state.deflated and not w.isTireDeflated and not w.isBroken then beamstate.deflateTire(w.cid) end
      end
    end
  end
  timer = timer+dt
  if timer >= 0.5 then timer = 0 M.snapshot() end
end

function M.onTireDeflated() M.snapshot() end

M.onExtensionUnloaded = restore
return M
