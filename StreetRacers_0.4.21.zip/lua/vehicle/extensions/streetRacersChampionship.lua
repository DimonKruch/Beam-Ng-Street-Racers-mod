-- StreetRacers, 2026. MIT. Private entrants receive real engine torque, not a UI-only power number.
local rules=require('streetRacers/domain')
local M={}
local configuredToken
local function measure(d)
  local data=d:getTorqueData()
  local peak=0
  for _,curve in ipairs(data.curves or {}) do
    if not tostring(curve.name):find('N2O',1,true) then
      for _,power in pairs(curve.power or {}) do if rules.finite(power) then peak=math.max(peak,power) end end
    end
  end
  return peak,data
end
function M.configure(target,token)
  if configuredToken==token then return end
  local result={vehicleId=obj:getID(),token=token}
  local ok,why=pcall(function()
    assert(rules.finite(target) and target>0 and target<=15000,'Неподдерживаемая мощность этапа.')
    local engines,total={},0
    for _,d in pairs(powertrain.getDevicesByCategory('engine') or {}) do
      assert(type(d.torqueCurve)=='table' and d.getTorqueData,'Нужен ДВС с поддерживаемой кривой момента.')
      local p=measure(d)
      assert(p>0,'Двигатель не сообщил мощность.')
      engines[#engines+1]={device=d,power=p} total=total+p
    end
    assert(total>0,'В машине нет поддерживаемого двигателя.')
    for _,entry in ipairs(engines) do
      local d=entry.device
      local goal=target*entry.power/total
      local accumulated=1
      for _=1,8 do
        local p=measure(d)
        if math.abs(p/goal-1)<0.005 then break end
        local scale=rules.clamp(goal/p,0.1,10)
        accumulated=accumulated*scale
        for rpm,torque in pairs(d.torqueCurve) do if type(rpm)=='number' and rules.finite(torque) then d.torqueCurve[rpm]=torque*scale end end
      end
      -- These are purpose-built entrants; scale the engine's torque rating with its tune.
      if rules.finite(d.maxTorqueRating) then d.maxTorqueRating=d.maxTorqueRating*accumulated end
      local p,data=measure(d)
      d.torqueData=data d.maxPower=p
      entry.measured=p
    end
    local measured=0 for _,entry in ipairs(engines) do measured=measured+entry.measured end
    assert(math.abs(measured/target-1)<=0.025,'Двигатель не достиг мощности этапа.')
    result.power=measured configuredToken=token
  end)
  if not ok then result.error=tostring(why) end
  obj:queueGameEngineLua('if career_modules_streetRacers then career_modules_streetRacers.receiveChampionshipPower('..serialize(result)..') end')
end
return M
