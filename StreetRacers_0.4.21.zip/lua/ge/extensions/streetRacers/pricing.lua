-- StreetRacers, 2026. MIT. Price mod vehicles from a physically loaded engine.
-- Original mod Power/Value metadata is untrusted. No game or mod files are edited.
local rules = require('streetRacers/domain')
local enginePrices = require('ge/extensions/streetRacers/enginePrices')
local M = {}

local function copy(t)
  local result = {}
  for k,v in pairs(t or {}) do result[k] = v end
  return result
end

function M.isModVehicle(config)
  if type(config)~='table' then return false end
  local source=config.Source
  if source=='BeamNG - Official' then return false end
  local types = type(config.aggregates)=='table' and config.aggregates.Type or {}
  if type(types)~='table' then types={} end
  if config.Type=='Trailer' or config.Type=='Prop' or types.Trailer or types.Prop then return false end
  -- Mod metadata uses inconsistent Type values or omits them. A complete market
  -- configuration is safe to inspect; official configs identify themselves.
  return config.model_key~=nil and config.key~=nil
end

function M.powerPrice(power)
  power=tonumber(power)
  if not rules.finite(power) or power<=0 then return nil end
  power=rules.clamp(power,40,2500)
  local value
  if power<=150 then
    value=10000+(power-40)*(15000/110)
  elseif power<=600 then
    value=25000+(power-150)*(20000/450)
  elseif power<=1000 then
    value=45000+(power-600)*62.5
  else
    value=70000+(power-1000)*(130000/1500)
  end
  return math.floor(value/500+0.5)*500
end

function M.baseValue(config, measured)
  if not M.isModVehicle(config) then return type(config)=='table' and tonumber(config.Value) or nil end
  return measured and M.powerPrice(measured.power) or tonumber(config.Value)
end

function M.needsEngine(config)
  return M.isModVehicle(config)
end

function M.correctConfig(config, measured)
  if not config then return config end
  local value = M.baseValue(config,measured)
  if not value then return config end
  local result = copy(config)
  result.Value = value
  result.streetRacersPricing = {version=4, baseValue=value, originalBaseValue=tonumber(config.Value) or 0,
    power=measured and measured.power,powerSource=measured and 'engine' or nil}
  if config.aggregates then
    result.aggregates = copy(config.aggregates)
    result.aggregates.Value = {min=value,max=value}
  end
  return result
end

function M.new(scannerFactory)
  local self, hooks, enabled = {}, {}, true
  local nativeConfig = core_vehicles.getConfig
  local function catalogConfig(model,key)
    local ok,config=pcall(nativeConfig,model,key)
    if not ok then log('W','StreetRacers','Cannot read vehicle config '..tostring(model)..'/'..tostring(key)) return nil end
    if type(config)=='table' and (not config.model_key or not config.key) then
      config=copy(config)
      config.model_key=config.model_key or model
      config.key=config.key or key
    end
    return config
  end
  local scanner, shopping, pendingAction = nil, false, nil
  local currentUiState
  local uiRefreshCooldown, pendingUiRefresh = 0, false
  local function measuredConfig(config)
    if not M.needsEngine(config) then return config end
    local measured = scanner.get(config)
    -- Missing/broken engines never become cheap guesses.
    if not measured or not measured.power then return config end
    return M.correctConfig(config,measured)
  end
  local function hook(target, key, fn)
    local original = target[key]
    if type(original) ~= 'function' then return end
    local wrapper = function(...)
      if not enabled then return original(...) end
      return fn(original, ...)
    end
    hooks[#hooks+1] = {target=target,key=key,original=original,wrapper=wrapper}
    target[key] = wrapper
  end
  local function refreshOffer(offer)
    if type(offer)~='table' then return nil end
    local config = catalogConfig(offer.model_key, offer.key)
    local needs=M.needsEngine(config)
    local measured = needs and scanner.get(config) or nil
    if needs and shopping and not measured then measured=scanner.request(config) end
    offer.streetRacersEnginePending = measured and measured.pending or nil
    offer.streetRacersEngineError = measured and measured.error
      or (not config and 'Нет конфигурации автомобиля.' or nil)
      or (needs and not measured and 'Не удалось поставить двигатель в очередь.' or nil)
    if measured and measured.power then
      offer.Power = measured.power
      local base=M.powerPrice(measured.power)
      local current=offer.streetRacersPricing
      if base and (not current or current.version~=4 or not current.askingPriceSet
        or current.baseValue~=base or current.power~=measured.power) then
        local markup=rules.clamp((offer.negotiationPersonality or {}).priceMultiplier or 1,0.95,1.05)
        offer.marketValue=base
        offer.Value=math.floor(base*markup/50+0.5)*50
        offer.streetRacersPricing={version=4,baseValue=base,originalBaseValue=tonumber(config.Value) or 0,
          power=measured.power,powerSource='engine',askingPriceSet=true}
      end
    end
    return offer
  end

  function self.refreshOffers()
    local shop=career_modules_vehicleShopping
    if not enabled or not shop or not shop.getVehiclesInShop then return end
    for _,offer in pairs(shop.getVehiclesInShop() or {}) do refreshOffer(offer) end
  end

  local function requestOffer(shopId)
    local shop = career_modules_vehicleShopping
    local offer = shop and shop.getVehicleInfoByShopId and shop.getVehicleInfoByShopId(shopId)
    if not offer then return nil end
    local config = catalogConfig(offer.model_key, offer.key)
    local measured = M.needsEngine(config) and scanner.request(config,true) or nil
    offer.streetRacersEnginePending = measured and measured.pending or nil
    offer.streetRacersEngineError = measured and measured.error
      or (not config and 'Нет конфигурации автомобиля.' or nil)
      or (M.needsEngine(config) and not measured and 'Не удалось поставить двигатель в очередь.' or nil)
    return offer
  end

  function self.refreshInventory()
    if not enabled then return end
    for id, car in pairs(career_modules_inventory.getVehicles()) do
      local filename = car.config and car.config.partConfigFilename
      local key = type(filename)=='string' and filename:match('([^/\\]+)%.pc$')
      local config = key and catalogConfig(car.model, key)
      if M.needsEngine(config) then scanner.request(config) end
      local corrected = measuredConfig(config)
      if corrected and corrected.streetRacersPricing and car.configBaseValue ~= corrected.Value then
        car.configBaseValue = corrected.Value
        career_modules_inventory.setVehicleDirty(id)
      end
    end
  end

  -- Reprice persisted offers before UI reads or opens a purchase/negotiation.
  local shop = career_modules_vehicleShopping
  local function pricesChanged()
    self.refreshOffers()
    self.refreshInventory()
    if shopping and shop and shop.getShoppingData and guihooks then
      pendingUiRefresh=true
    end
  end
  scanner = (scannerFactory or enginePrices).new(pricesChanged)
  if shop then
    local function notify(text)
      if guihooks then guihooks.trigger('toastrMsg',{type='info',title='StreetRacers',msg=text}) end
    end
    local function action(original,key,shopId,...)
      shopping=true
      local offer=requestOffer(shopId)
      if not offer or offer.streetRacersEngineError then
        pendingAction=nil
        notify(offer and offer.streetRacersEngineError or 'Объявление больше не доступно.')
        return
      end
      if offer.streetRacersEnginePending then
        if not pendingAction or pendingAction.offer~=offer or pendingAction.key~=key then
          pendingAction={offer=offer,shopId=shopId,key=key,original=original,
            args={n=select('#',...),...},uiState=currentUiState,model=offer.model_key,config=offer.key}
          notify('Проверяем двигатель выбранной машины. Окно откроется автоматически.')
        end
        return
      end
      pendingAction=nil
      refreshOffer(offer)
      return original(...)
    end
    local function shoppingData(data)
      -- Never expose an unverified metadata quote. Mod entries appear in the
      -- native list as their sequential physical engine checks finish.
      local rows={}
      for _, offer in pairs(data.vehiclesInShop or {}) do
        refreshOffer(offer)
        if type(offer)=='table' and not offer.streetRacersEnginePending
          and not offer.streetRacersEngineError then rows[#rows+1]=offer end
      end
      data.vehiclesInShop=rows
      return data
    end
    hook(shop,'getShoppingData',function(original,...)
      shopping=true
      return shoppingData(original(...))
    end)
    -- Native onRouteMount/selectSeller call local functions. Filter the event
    -- too, so those paths cannot briefly expose an unverified metadata quote.
    if guihooks then hook(guihooks,'trigger',function(original,event,data,...)
      if event=='vehicleShoppingData' then shopping=true data=shoppingData(data) end
      return original(event,data,...)
    end) end
    hook(shop,'openPurchaseMenu',function(original,purchaseType,shopId,...)
      return action(original,'openPurchaseMenu',shopId,purchaseType,shopId,...)
    end)
    for _,key in ipairs({'showVehicle','quickTravelToVehicle'}) do
      hook(shop,key,function(original,shopId,...) return action(original,key,shopId,shopId,...) end)
    end
    for _,key in ipairs({'selectSeller','endShopping','cancelShopping','requestExit','requestVehicleListExit'}) do
      hook(shop,key,function(original,...) pendingAction=nil return original(...) end)
    end
  end
  function self.update(dt,allowStart)
    uiRefreshCooldown=math.max(0,uiRefreshCooldown-dt)
    local listOpen=currentUiState==nil or currentUiState=='career.computer.vehicleShopping'
      or currentUiState=='career.computer.vehicleShopping.vehicles'
    scanner.update(dt,allowStart and shopping and listOpen)
    if pendingAction and allowStart and shopping then
      local queued=pendingAction
      local offer=shop.getVehicleInfoByShopId(queued.shopId)
      if offer~=queued.offer or currentUiState~=queued.uiState or offer.model_key~=queued.model or offer.key~=queued.config then
        pendingAction=nil
      elseif offer.streetRacersEngineError then
        pendingAction=nil
        if guihooks then guihooks.trigger('toastrMsg',{type='error',title='StreetRacers',msg=offer.streetRacersEngineError}) end
      elseif not offer.streetRacersEnginePending then
        pendingAction=nil -- navigation hooks and repeated clicks cannot run it twice
        pendingUiRefresh=false
        queued.original(unpack(queued.args,1,queued.args.n))
      end
    end
    if pendingUiRefresh and uiRefreshCooldown<=0 and shopping and shop and shop.getShoppingData and guihooks then
      pendingUiRefresh=false
      uiRefreshCooldown=0.5
      guihooks.trigger('vehicleShoppingData',shop.getShoppingData())
    end
  end
  function self.receivePerformance(data) return scanner.receive(data) end
  function self.setShopping(value)
    shopping=value
    if not value then pendingAction=nil pendingUiRefresh=false end
  end
  function self.onUiChangedState(name)
    currentUiState=name
    if pendingAction and name~=pendingAction.uiState then pendingAction=nil end
    if type(name)=='string' and not name:find('career.computer.vehicleShopping',1,true) then self.setShopping(false) end
  end
  function self.invalidate()
    pendingAction=nil
    scanner.stop()
    scanner=(scannerFactory or enginePrices).new(pricesChanged)
    self.refreshOffers()
    self.refreshInventory()
  end
  -- Do not scan the whole showroom during career initialization. The first
  -- market opening requests its offers lazily; owned inventory is tiny and can
  -- be corrected immediately without touching the virtualized showroom list.
  self.refreshInventory()
  function self.stop()
    enabled = false
    pendingAction=nil
    scanner.stop()
    for i=#hooks,1,-1 do
      local h = hooks[i]
      if h.target[h.key] == h.wrapper then h.target[h.key] = h.original end
    end
  end
  return self
end
return M
