-- StreetRacers, 2026. MIT. Clear only road traffic around the two start slots.
local M={}
local parked={}
local zone
local function protected(id,entry,p,o)
  return id==p or id==o or not entry.isAi or entry.reserved or entry.claimed or
    (career_modules_inventory and career_modules_inventory.getInventoryIdFromVehicleId(id)~=nil)
end
local function nearby(car)
  if not zone then return false end
  local pos=car:getPosition()
  return pos:squaredDistance(zone.a)<=2500 or pos:squaredDistance(zone.b)<=2500
end
local function scatter(id,car)
  if gameplay_traffic.forceTeleport then
    pcall(gameplay_traffic.forceTeleport,id,zone.a,zone.direction,120,500,250)
  end
  return not nearby(car)
end
function M.clear(grid,p,o)
  zone={a=vec3(grid.playerPos),b=vec3(grid.opponentPos),direction=grid.direction,p=p,o=o}
  local ids={}
  for id,entry in pairs(gameplay_traffic.getTrafficData()) do
    local car=getObjectByID(id)
    if not protected(id,entry,p,o) and car and car:getActive() and nearby(car) then ids[#ids+1]=id end
  end
  for _,id in ipairs(ids) do
    local car=getObjectByID(id)
    if not scatter(id,car) then
      -- Some maps/settings cannot supply a spawn point. Remove this car from
      -- the active pool temporarily so it cannot reappear during the countdown.
      gameplay_traffic.removeTraffic(id,true)
      car:setActive(0)
      parked[id]=car
    end
  end
end
function M.stop()
  for id,car in pairs(parked) do
    if getObjectByID(id)==car then
      car:setActive(1)
      gameplay_traffic.insertTraffic(id,false,false)
      scatter(id,car)
    end
  end
  parked,zone={},nil
end
function M.update(race)
  if not zone then return end
  if race.phase=='offer' and race.mode=='drag' then return end
  if race.phase=='staging' or race.phase=='countdown' or (race.phase=='running' and race.elapsed<3) then
    M.clear(race.route.grid,zone.p,zone.o)
  elseif race.phase~='running' then M.stop()
  else
    local p,o=getObjectByID(zone.p),getObjectByID(zone.o)
    if not p or not o or (p:getPosition():squaredDistance(zone.a)>65*65 and o:getPosition():squaredDistance(zone.a)>65*65) then M.stop() end
  end
end
return M
