-- StreetRacers, 2026. MIT. Read engines from complete configs, one temporary car at a time.
-- Results live for this career session: a mod update/restart cannot reuse stale power.
local rules = require('streetRacers/domain')
local M = {}
local instanceSerial=0

function M.new(changed)
  local self, records, queue, current = {}, {}, {}, nil
  local elapsed, serial, enabled, nextStartAt = 0, 0, true, 0
  instanceSerial=instanceSerial+1
  local epoch = tostring(os.time())..':'..instanceSerial
  local function key(config) return tostring(config.model_key)..':'..tostring(config.key) end
  local function cleanup(job)
    for _, id in ipairs(job.ids or {}) do
      local car = getObjectByID(id)
      if car then car:delete() end
    end
  end
  local function finish(power, reason)
    local job = current
    if not job then return end
    current = nil -- destruction hooks and stale replies must not complete the next job
    local result = records[job.key]
    result.pending, result.power, result.error = false, power, reason
    cleanup(job)
    log(power and 'I' or 'W','StreetRacers', 'Engine price '..job.key..': '..(power and string.format('%.1f PS',power) or tostring(reason)))
    if changed then changed() end
  end

  function self.request(config, priority)
    if type(config)~='table' or not config.model_key or not config.key then return nil end
    local id = key(config)
    if not records[id] then
      records[id] = {pending=true}
      queue[#queue+1] = {key=id,model=config.model_key,config=config.key,ids={}}
    end
    if priority and records[id].pending then
      for i,job in ipairs(queue) do
        if job.key==id then table.remove(queue,i) table.insert(queue,1,job) break end
      end
    end
    return records[id]
  end
  function self.get(config) return type(config)=='table' and records[key(config)] or nil end
  function self.status()
    local pending, failed = 0, 0
    for _, result in pairs(records) do
      if result.pending then pending=pending+1 elseif result.error then failed=failed+1 end
    end
    return pending, failed
  end
  function self.receive(data)
    if not enabled or type(data)~='table' or not current or current.vehicleId~=data.vehicleId or current.token~=data.token then return false end
    local power = tonumber(data.power)
    if rules.finite(power) and power>0 and power<=10000 then finish(power)
    else finish(nil,'Двигатель не сообщил мощность.') end
    return true
  end
  function self.update(dt, allowStart)
    if not enabled then return end
    elapsed = elapsed+dt
    if current then
      if elapsed-current.started>12 then finish(nil,'Нет ответа двигателя за 12 секунд.') end
      return
    end
    if not allowStart or elapsed<nextStartAt or #queue==0 or not getPlayerVehicle(0) then return end
    current = table.remove(queue,1)
    nextStartAt = elapsed + 0.65
    local job = current
    serial=serial+1
    job.token, job.started = 'price:'..epoch..':'..serial, elapsed
    local ok, car, cars = pcall(core_vehicles.spawnNewVehicle,job.model,{
      config=job.config,autoEnterVehicle=false,canSpawnAnotherVehicleCheck=false,
      pos=getPlayerVehicle(0):getPosition()+vec3(0,0,2000),rot=quat(0,0,0,1),
      cling=false,safeSpawn=false,removeTraffic=false,vehicleName='streetRacersEnginePrice',spawnMeta='streetRacersPricing'})
    if not ok or not car then finish(nil,'Конфигурация не загрузилась.') return end
    local setupOk=pcall(function()
      for _, object in ipairs(cars or {car}) do job.ids[#job.ids+1]=object:getID() object:setMeshAlpha(0,'') end
      job.vehicleId = car:getID()
      car:queueLuaCommand('controller.setFreeze(1); extensions.load("streetRacersVehicle"); streetRacersVehicle.inspectPrice('..serialize(job.token)..')')
    end)
    if not setupOk then finish(nil,'Не удалось запросить двигатель конфигурации.') end
  end
  function self.stop()
    enabled=false
    local job=current
    current=nil
    if job then cleanup(job) end
    queue={}
  end
  return self
end
return M
