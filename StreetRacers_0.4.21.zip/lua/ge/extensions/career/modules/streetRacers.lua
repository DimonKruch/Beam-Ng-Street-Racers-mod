-- StreetRacers, 2026. MIT. Career integration targeting BeamNG.drive 0.40.
local M = {}
M.dependencies = {'career_career', 'career_modules_inventory', 'career_modules_partInventory',
  'career_modules_playerAttributes', 'career_modules_playerDriving', 'career_modules_vehicleShopping',
  'career_modules_valueCalculator', 'career_modules_computer', 'core_groundMarkers', 'freeroam_facilities', 'gameplay_drag_core'}
local rules = require('streetRacers/domain')
local raceFactory = require('ge/extensions/streetRacers/race')
local tyreFactory = require('ge/extensions/streetRacers/tyres')
local traffic = require('ge/extensions/streetRacers/traffic')
local routes = require('ge/extensions/streetRacers/routes')
local nativeDrag = require('ge/extensions/streetRacers/nativeDrag')
local startTraffic = require('ge/extensions/streetRacers/startTraffic')
local ui = require('ge/extensions/streetRacers/ui')
local tyreHud = require('ge/extensions/streetRacers/tyreHud')
local routePreview = require('ge/extensions/streetRacers/routePreview')
local startPreview = require('ge/extensions/streetRacers/startPreview')
local racerMarkers = require('ge/extensions/streetRacers/racerMarkers')
local torqueApp = require('ge/extensions/streetRacers/torqueApp')
local priceFactory = require('ge/extensions/streetRacers/pricing')
local ladder=require('streetRacers/championshipRules')
local tyreCatalog=require('ge/extensions/streetRacers/tyreCatalog')
local championshipFactory=require('ge/extensions/streetRacers/championship')
local championshipMarker=require('ge/extensions/streetRacers/championshipMarker')
local menuNavigation=require('ge/extensions/streetRacers/menuNavigation')
local garageAccessFactory=require('ge/extensions/streetRacers/garageAccess')
local starterGarage,garagePrice='servicestationGarage',100000
local garageAccess
local menuKeys
local state, race, tyres, pricing, championship
local championshipProfile
local active, saving, saveRequested, serviceBusy = false, false, false, false
local saveContext, heldOpponent, serviceInventory, serviceContext
local attachPending, resumeAt = {}, nil
local clock, pollTimer, saveSerial, hornAt, serviceAt = 0, 0, 0, -10, nil
local menuOpen, lastMessage, lastMessageAt = false, '', 0
local lastCountdown, countdownAt
local policeReapply = false
local serviceSerial = 0
local uiState = 'play'
local catalogChanged = false
local deferredFines = {}
local garageCache, garagePositions, pendingGarage = nil, {}, nil
local autoGarageAttempted=false
local towJob
local readyRacers, markerTimer, viewCache, viewAt = {}, 0, nil, -1
-- Recover only the native traffic wait, after the world and player are ready.
-- Releasing this one request never hides other modules' loading screens.
local trafficLoadingAt, trafficLoadingReleased = nil, false
local mechanicalViews={}
local fileName = '/career/streetRacers.json'

local function isMode()
  return career_career and career_career.isActive() and career_career.startingOptions and career_career.startingOptions.startMode == 'streetRacers'
end

local function saveFingerprint()
  local profile = career_saveSystem.getCurrentProfile()
  return profile
end

local function message(text, kind)
  lastMessage, lastMessageAt = text, clock
  log(kind == 'error' and 'E' or 'I', 'StreetRacers', text)
  guihooks.trigger('toastrMsg', {type = kind or 'info', title = 'StreetRacers', msg = text})
end

local function waitForLoading()
  local gs=core_gamestate
  if not gs or not gs.loading or not gs.loading() then
    trafficLoadingAt,trafficLoadingReleased=nil,false
    return false
  end
  local tags={}
  local worldLoading=false
  for _,tag in ipairs({'careerActivate','freeroam','levels','server.lua','worldReadyState','serverConnection'}) do
    tags[tag]=gs.getLoadingStatus(tag) or false
    worldLoading=worldLoading or tags[tag]
  end
  tags.careerVehicles=gs.getLoadingStatus('careerVehicles') or false
  local vehicle=getPlayerVehicle(0)
  if tags.careerVehicles and not worldLoading and vehicle and vehicle:getActive() then
    trafficLoadingAt=trafficLoadingAt or clock
    if not trafficLoadingReleased and clock-trafficLoadingAt>=90 then
      trafficLoadingReleased=true
      -- Keep evidence in the affected user's own folder, without changing saves,
      -- deleting cars, guessing which config failed or restarting a spawn queue.
      local report={version=1,modVersion='0.4.21',reason='trafficLoadingTimeout',waitSeconds=clock-trafficLoadingAt,
        level=getCurrentLevelIdentifier(),loadingRequests=tags}
      pcall(jsonWriteFile,'/settings/streetRacersStartup.json',report,true)
      log('W','StreetRacers','Traffic wait exceeded 90 seconds after the world was ready. Releasing careerVehicles only. Diagnostic: /settings/streetRacersStartup.json')
      gs.requestExitLoadingScreen('careerVehicles')
      message('Трафик не завершил загрузку. Карьера открыта с уже загруженными машинами.', 'warning')
    end
  else
    trafficLoadingAt,trafficLoadingReleased=nil,false
  end
  return true
end

local function command(id, code)
  local car = id and getObjectByID(id)
  if car then car:queueLuaCommand(code) return true end
  return false
end

local function clearService()
  if serviceContext and (serviceContext.mode=='roadside' or serviceContext.mode=='tow' or serviceContext.mode=='mechanical') then
    command(serviceContext.vehicleId, 'controller.setFreeze(0)')
    local id = career_modules_inventory.getVehicleIdFromInventoryId(serviceContext.id)
    if id and id~=serviceContext.vehicleId then command(id, 'controller.setFreeze(0)') end
  end
  serviceBusy, serviceAt, serviceContext = false, nil, nil
  towJob=nil
end

local function player() return getPlayerVehicle(0) end
local function inventoryId(id) return career_modules_inventory.getInventoryIdFromVehicleId(id) end
local function owned(id)
  local vehicle = career_modules_inventory.getVehicles()[id]
  return vehicle and vehicle.owned and not vehicle.loanType
end
local function money() return career_modules_playerAttributes.getAttributeValue('money') end
local function changeMoney(amount, label)
  career_modules_playerAttributes.addAttributes({money = amount}, {label = label, tags = {'streetRacers'}})
end
local function requestSave() saveRequested = true end

local function vehicleInfo(id)
  local car = id and getObjectByID(id)
  if not car then return nil end
  return {id = id, pos = vec3(car:getPosition()), racePos=vec3(car:getSpawnWorldOOBB():getCenter()), speed = car:getVelocity():length(), object = car}
end

local function canRace()
  if not active then return false, 'Создайте карьеру с вариантом старта StreetRacers.' end
  if getCurrentLevelIdentifier() ~= 'west_coast_usa' then return false, 'Первая версия рассчитана на West Coast USA.' end
  if not state.homeGarage then return false, 'Дождитесь подготовки стартового гаража Belasco.' end
  if serviceBusy or tyres.suspended then return false, 'Завершите обслуживание машины.' end
  if saving then return false, 'Дождитесь окончания сохранения.' end
  if championship and championship.busy() and championship.phase~='racing' then return false,'Завершите подготовку чемпионата.' end
  if gameplay_missions_missionManager.getForegroundMissionId() then return false, 'Сначала завершите текущее задание.' end
  if career_modules_vehiclePerformance and career_modules_vehiclePerformance.isTestInProgress and career_modules_vehiclePerformance.isTestInProgress() then return false,'Дождитесь завершения теста индекса производительности.' end
  if gameplay_drag_core and gameplay_drag_core.getDragIsStarted and gameplay_drag_core.getDragIsStarted() then return false,'Завершите штатный дрэг-заезд перед вызовом StreetRacers.' end
  local car = player()
  if not car or not owned(inventoryId(car:getID())) then return false, 'Для гонки нужна ваша собственная машина.' end
  if gameplay_police.isVehicleInPursuit(car:getID()) then return false, 'Сначала уйдите от погони.' end
  return true
end

local function release(playerId, opponentId)
  startTraffic.stop()
  command(playerId, 'controller.setFreeze(0)')
  if championship and championship.owns(opponentId) then
    championship.release(opponentId)
  elseif opponentId and getObjectByID(opponentId) then
    command(opponentId, 'if streetRacersDragAI then streetRacersDragAI.stop() end; ai.setRacing(false); ai.setAggressionMode("off"); controller.setFreeze(0)')
    if not gameplay_traffic.getTrafficData()[opponentId] then gameplay_traffic.insertTraffic(opponentId, false, false) end
    local restored = gameplay_traffic.getTrafficData()[opponentId]
    if restored then restored:setAiMode('traffic') end
  end
  heldOpponent = nil
end

local function chargeCollision(fine)
  changeMoney(-fine,'StreetRacers: столкновение с соперником')
  state.stats.fines=(state.stats.fines or 0)+fine
  state.stats.net=state.stats.net-fine
  if state.pendingRace then state.pendingRace.fines=(state.pendingRace.fines or 0)+fine end
  requestSave()
  message('Столкновение с соперником: штраф $'..fine,'warning')
end

local function makeRace()
  return raceFactory.new({
    player = function() local car = player() return car and vehicleInfo(car:getID()) end,
    vehicle = vehicleInfo, balance = money, canRace = canRace,
    finishInspection = traffic.finishInspection,
    saving = function() return saving or serviceBusy end,
    distance = function(a,b) return a:distance(b) end,
    findOpponent = function(p,mode,selectedId)
      if championshipProfile and championship and championship.owns(selectedId) then return selectedId,championshipProfile end
      if selectedId then
        return traffic.selectRacer(selectedId,p.object)
      end
      if mode=='drag' then
        traffic.inspectPlayer(p.object)
        local rows=traffic.ready(p.object)
        local best
        for _,row in ipairs(rows) do
          if not best or math.abs(row.profile.power-traffic.playerPower())<math.abs(best.profile.power-traffic.playerPower()) then best=row end
        end
        return best and best.id,best and best.profile
      end
      local id = traffic.nearest(p.object)
      return id, id and traffic.profile(id)
    end,
    hold = function(id,mode)
      heldOpponent = id
      gameplay_traffic.removeTraffic(id, true)
      command(id, 'ai.setMode("stop")')
      local car=getObjectByID(id)
      if not car then return false,'Соперник недоступен. Выберите другого.' end
      car:setActive(1)
      car:setMeshAlpha(1,'')
      if mode=='drag' then return M.placeDragOpponent(id) end
      return true
    end,
    release = release,
    prepare = function(p,o,mode)
      local route, why
      if mode=='drag' then route,why=routes.fromDragStrip(p.object,o.object)
      else route,why=routes.fromGPS(p.object) end
      if not route then return nil, why end
      if not route.grid then
        local grid, errorText = routes.grid(p.object, o.object, route)
        if not grid then return nil, errorText end
        route.grid = grid
      end
      return route
    end,
    stage = function(playerId, opponentId, route, step, attempt)
      local p, o = getObjectByID(playerId), getObjectByID(opponentId)
      if not p or not o or not p:getActive() or not o:getActive() then
        return false, 'Одна из машин недоступна. Ставка возвращена.'
      end
      local grid = route.grid
      o:setActive(1)
      o:setMeshAlpha(1,'')
      if step=='player' then
        startTraffic.clear(grid,playerId,opponentId)
        if route.kind=='drag' then
          route.playerLane=attempt==1 and route.initialPlayerLane or 3-route.initialPlayerLane
          route.opponentLane=3-route.playerLane
        end
        command(playerId, 'controller.setFreeze(1)')
        command(opponentId, 'ai.setMode("disabled"); controller.setFreeze(1)')
        -- Each teleport gets its own physics update; the next car sees the new pose.
        spawn.safeTeleport(p, attempt==1 and grid.playerPos or grid.opponentPos, grid.rotation, nil, nil, false, true, false)
      else
        local centre = vec3(p:getSpawnWorldOOBB():getCenter())
        local pos = route.kind=='drag' and (route.drag.lanes[route.opponentLane].stage+vec3(0,0,0.3)) or
          (centre+grid.right*grid.separation*(attempt==1 and 1 or -1))
        spawn.safeTeleport(o, pos, grid.rotation, nil, nil, false, true, false)
      end
      routes.show(route)
      menuOpen = false
      return true
    end,
    checkGrid = function(playerId, opponentId, route)
      return routes.checkGrid(getObjectByID(playerId),getObjectByID(opponentId),route)
    end,
    go = function(playerId, opponentId, route, profile)
      startTraffic.clear(route.grid,playerId,opponentId)
      local p, o = getObjectByID(playerId), getObjectByID(opponentId)
      local ok, why=routes.checkGrid(p,o,route)
      if not ok then return false,why end
      if route.kind=='drag' then
        command(opponentId,'extensions.load("streetRacersDragAI"); streetRacersDragAI.start('..serialize(routes.dragAI(route))..')')
        command(playerId,'controller.setFreeze(0); input.event("parkingbrake",0,1)')
        return true
      end
      local waypoints = routes.aiWaypoints(o,route)
      if not waypoints then return false,'Маршрут AI не совпадает со стартом. Ставка возвращена; выберите прямой участок.' end
      local args = {wpTargetList = waypoints, aggression = math.max(profile.aggression or 0.92,0.96), avoidCars = 'on',
        driveInLane = 'off', routeSpeedMode = 'off',turnForceCoef=4}
      log('I','StreetRacers',string.format('AI start opponent=%d waypoints=%d first=%s last=%s',
        opponentId,#waypoints,waypoints[1],waypoints[#waypoints]))
      command(opponentId, 'if ai.setAggressionMode then ai.setAggressionMode("off") end; '..
        'if ai.setRacing then ai.setRacing(true) end; if ai.setParameters then ai.setParameters({minStTargetDist=4.5,turnForceCoef=4}) end; '..
        'ai.driveUsingPath(' .. serialize(args) .. '); input.event("parkingbrake",0,1); controller.setFreeze(0)')
      command(playerId, 'controller.setFreeze(0); input.event("parkingbrake",0,1)')
      return true
    end,
    launchFailed = function(opponentId)
      command(opponentId, [[local e=electrics.values
        log('W','StreetRacers','Opponent launch timeout '..serialize({vehicleId=obj:getID(),
          mode=ai.mode,speed=obj:getVelocity():length(),rpm=e.rpm,ignition=e.ignitionLevel,
          throttle=e.throttle,brake=e.brake,parkingbrake=e.parkingbrake,gear=e.gearIndex,freeze=e.freezeState}))]])
    end,
    contact = function(a,b)
      local pa,pb=map.objects and map.objects[a],map.objects and map.objects[b]
      local ca,cb=getObjectByID(a),getObjectByID(b)
      return (pa and pa.objectCollisions and pa.objectCollisions[b]==1) or
        (pb and pb.objectCollisions and pb.objectCollisions[a]==1) or false,
        ca and cb and (ca:getVelocity()-cb:getVelocity()):length() or 0
    end,
    collision = function(speed)
      local fine=rules.collisionFine(speed)
      if fine<=0 then return end
      if saving then deferredFines[#deferredFines+1]=fine else chargeCollision(fine) end
    end,
    reserve = function(bet, opponent)
      state.nextRaceId = state.nextRaceId+1
      state.pendingRace = {id = state.nextRaceId, stake = bet, opponent = opponent,walletKey=race.profile.fingerprint,kind=race.mode,
        championshipId=race.profile.championshipId,round=race.profile.round}
      changeMoney(-bet, 'StreetRacers: ставка зарезервирована')
    end,
    settle = function(stake, outcome, reason)
      if not state.pendingRace then return end
      local pending = state.pendingRace
      state.pendingRace = nil
      if pending.championshipId then
        local _,accepted=ladder.settle(state.championship,pending.championshipId,pending.round,outcome,race.elapsed)
        local payout=accepted and rules.payout(stake,outcome) or 0
        if payout>0 then changeMoney(payout,outcome=='win' and 'StreetRacers: победа в этапе чемпионата' or 'StreetRacers: возврат ставки чемпионата') end
        state.stats[outcome]=(state.stats[outcome] or 0)+1
        state.stats.net=state.stats.net+payout-stake
        state.history[#state.history+1]={id=pending.id,opponent=pending.opponent,stake=stake,
          outcome=outcome,reason=reason,kind='championship',fines=pending.fines or 0,
          net=payout-stake-(pending.fines or 0),date=os.date('!%Y-%m-%dT%H:%M:%SZ')}
        if #state.history>50 then table.remove(state.history,1) end
        state.reputation=math.max(0,state.reputation+rules.reputationChange(outcome,race.profile.power))
        traffic.setReputation(state.reputation)
        championshipProfile=nil
        requestSave() menuOpen=true ui.selectTab('championship')
        return
      end
      if pending.walletKey then traffic.settleWallet(pending.walletKey,stake,outcome)
      else traffic.settle(race.opponentId,stake,outcome) end
      state.reputation=math.max(0,state.reputation+rules.reputationChange(outcome,race.profile.power))
      traffic.setReputation(state.reputation)
      local payout = rules.payout(stake, outcome)
      if payout > 0 then changeMoney(payout, reason) end
      state.stats[outcome] = (state.stats[outcome] or 0)+1
      state.stats.net = state.stats.net+payout-stake
      state.history[#state.history+1] = {id = pending.id, opponent = pending.opponent, stake = stake,
        outcome = outcome, reason = reason, kind=pending.kind or 'street', fines=pending.fines or 0, net = payout-stake-(pending.fines or 0), date = os.date('!%Y-%m-%dT%H:%M:%SZ')}
      if #state.history > 50 then table.remove(state.history, 1) end
      requestSave()
      menuOpen = true
      ui.selectTab('career')
    end,
    save = requestSave, saveTimeout = function() saving = false end,
    showMenu = function() menuOpen = false ui.newOffer() end,
    count = function(value)
      lastCountdown, countdownAt = tostring(value), clock
      guihooks.trigger('Message', {ttl = 1, msg = tostring(value), category = 'streetRacersCountdown', icon = 'flag'})
    end,
    message = message
  })
end

local function canService(id, mode)
  if not active or not owned(id) then return false, 'Выберите собственный автомобиль.' end
  if gameplay_missions_missionManager.getForegroundMissionId() then return false, 'Сначала завершите текущее задание.' end
  if saving or race.busy() or (championship and championship.busy()) or tyres.suspended then return false, 'Завершите гонку, сохранение или магазин запчастей.' end
  local vehicleId = career_modules_inventory.getVehicleIdFromInventoryId(id)
  local car = vehicleId and getObjectByID(vehicleId)
  if not car or car:getVelocity():length() > 0.5 then return false, 'Полностью остановите машину перед обслуживанием.' end
  if mode=='roadside' and (not player() or player():getID()~=vehicleId) then return false, 'Сядьте в свою машину, которой нужна техпомощь.' end
  if gameplay_police.isVehicleInPursuit(car:getID()) then return false, 'Обслуживание недоступно во время погони.' end
  if mode~='roadside' then
    local found = false
    for _, candidate in ipairs(career_modules_inventory.getInventoryIdsInClosestGarage()) do if candidate == id then found = true end end
    if not found then return false, 'Заезжайте машиной в зону гаража.' end
  end
  local permission = career_modules_permissions.getStatusForTag({'partBuying','vehicleModification'}, {inventoryId = id})
  if permission and not permission.allow then return false, 'Сейчас изменение деталей недоступно.' end
  return true
end

local function makeTyres()
  local cachedData,cachedChoices=nil,{}
  return tyreFactory.new({
    parts = career_modules_partInventory.getInventory, inventoryId = inventoryId, owned = owned,
    vehicleId = career_modules_inventory.getVehicleIdFromInventoryId,
    spawned = career_modules_inventory.getMapInventoryIdToVehId,
    exists = function(id) return getObjectByID(id) ~= nil end,
    command = command, canService = canService, canPay = function(amount) return money() >= amount end,
    choices = function(id,part)
      local vehicleId=career_modules_inventory.getVehicleIdFromInventoryId(id)
      local data=vehicleId and core_vehicle_manager.getVehicleData(vehicleId)
      if not data or not data.ioCtx then return {} end
      if cachedData~=data then cachedData,cachedChoices=data,{} end
      if cachedChoices[part.containingSlot] then return cachedChoices[part.containingSlot] end
      local ok,choices=pcall(tyreCatalog.choices,data,part,require('jbeam/io'))
      if ok then cachedChoices[part.containingSlot]=choices end
      return ok and choices or {}
    end,
    pay = function(amount, label) changeMoney(-amount, label) end,
    dirty = career_modules_inventory.setVehicleDirty, save = requestSave
  }, state)
end

local function makeChampionship()
  return championshipFactory.new({
    vehicle=getObjectByID,catalog=traffic.championshipCatalog,save=requestSave,message=message,balance=money,
    waiting=function() return saving or serviceBusy end,
    delete=function(car) car:delete() end,
    spawn=function(row)
      local info=assert(routes.dragStripInfo())
      return core_vehicles.spawnNewVehicle(row.model,{config=row.config,autoEnterVehicle=false,
        canSpawnAnotherVehicleCheck=false,pos=info.start-info.direction*12+info.right*12,
        rot=quatFromDir(info.direction,vec3(0,0,1)),cling=true,safeSpawn=true,removeTraffic=false,
        vehicleName='streetRacersChampionship',spawnMeta='streetRacersChampionship'})
    end,
    configure=function(id,power,token)
      command(id,'ai.setMode("disabled"); controller.setFreeze(1); extensions.load("streetRacersChampionship"); streetRacersChampionship.configure('..serialize(power)..','..serialize(token)..')')
    end,
    ready=function(id,profile)
      championshipProfile=profile
      local ok,why=race.challenge('drag',id)
      if ok then ok,why=race.start(profile.reward) end
      if not ok and race.busy() then race.finish('void',why) end
      championshipProfile=nil
      return ok,why
    end
  },state)
end

local function initialize()
  if active or not isMode() then return end
  local _, path = career_saveSystem.getCurrentProfile()
  local loaded = path and jsonReadFile(path .. fileName)
  if loaded and (loaded.version ~= 1 or type(loaded.settings) ~= 'table' or type(loaded.tyres) ~= 'table' or
      type(loaded.stats) ~= 'table' or type(loaded.history) ~= 'table' or not rules.finite(loaded.nextTyreId) or not rules.finite(loaded.nextRaceId)) then
    message('Повреждённое или неподдерживаемое сохранение StreetRacers. Загрузите другой автосейв.', 'error') return
  end
  state = loaded or {version = 1, settings = {police = true, wearMultiplier = 1}, tyres = {}, nextTyreId = 0,
    nextRaceId = 0, stats = {win = 0, loss = 0, draw = 0, void = 0, net = 0}, history = {}}
  state.reputation=math.max(0,tonumber(state.reputation) or 0)
  local migratedGarages=type(state.ownedGarages)~='table'
  state.ownedGarages=type(state.ownedGarages)=='table' and state.ownedGarages or {}
  for id,value in pairs(state.ownedGarages) do if value~=true then state.ownedGarages[id]=nil end end
  state.ownedGarages[starterGarage]=true
  if state.homeGarage and not state.ownedGarages[state.homeGarage] then
    state.homeGarage=starterGarage
    migratedGarages=true
  end
  state.racerWallets=type(state.racerWallets)=='table' and state.racerWallets or {}
  local migratedChampionship=false
  if type(state.championship)=='table' and state.championship.economyVersion~=4 then
    local old=state.championship
    state.nextChampionshipId=math.max(tonumber(state.nextChampionshipId) or 0,tonumber(old.id) or 0)
    -- Pay a valid unclaimed 0.4.15-17 bank once; completed/failed banks are zero.
    if old.economyVersion==2 and ladder.valid(old,true) and old.bank>0 then
      changeMoney(old.bank,'StreetRacers: выплата банка при обновлении правил')
      state.stats.net=(state.stats.net or 0)+old.bank
    end
    state.championship=nil
    migratedChampionship=true
    message('Правила чемпионата обновлены: начните заново. Ранее выплаченные деньги сохранены.','info')
  elseif state.championship and not ladder.valid(state.championship) then
    message('Повреждённая таблица чемпионата сброшена. Основная карьера сохранена.','warning')
    state.championship=nil
  end
  if not rules.finite(state.nextChampionshipId) or state.nextChampionshipId<0 or state.nextChampionshipId%1~=0 then
    state.nextChampionshipId=state.championship and state.championship.id or 0
  end
  traffic.bindWallets(state.racerWallets)
  if not rules.racerDensities[state.settings.racerDensity] then state.settings.racerDensity='high' end
  traffic.setReputation(state.reputation)
  if state.settings.tyreHud == nil then state.settings.tyreHud = true end
  if state.settings.torqueCurve == nil then state.settings.torqueCurve = true end
  active, saving, saveRequested = true, false, migratedChampionship or (migratedGarages and state.homeGarage~=nil)
  nativeDrag.start()
  for _, record in pairs(state.tyres) do
    for _, wheel in pairs(record.wheels or {}) do wheel.temperature = 21 end
  end
  clock, pollTimer, menuOpen = 0, 0, not state.homeGarage
  trafficLoadingAt, trafficLoadingReleased = nil, false
  garageCache,garagePositions,pendingGarage=nil,{},nil
  autoGarageAttempted=false
  garageAccess=garageAccessFactory.new({facilities=freeroam_facilities,computer=career_modules_computer,
    -- Native queries also run while the map is loading: do not populate the UI catalogue here.
    isGarage=function(id) return id==starterGarage or id=='commercialGarage' or id=='alderDragwayGarage' end,
    owns=function(id) return state.ownedGarages[id]==true end,
    computerGarage=function(id)
      if type(id)~='string' then return end
      local native=id:match('^(.-Garage)Computer')
      if native then return native end
      for _,g in ipairs(garageCache or {}) do if id:sub(1,#g.id+8)==g.id..'Computer' then return g.id end end
    end,
    purchaseMenu=function() career_career.closeAllMenus() M.openMenu() ui.selectTab('career')
      message('Этот гараж продаётся за $100 000. Покупка — в разделе «Гаражи».','info') end})
  readyRacers,markerTimer,viewCache,viewAt={},0,nil,-1
  hornAt, lastCountdown, countdownAt = -10, nil, nil
  race, tyres = makeRace(), makeTyres()
  championship=makeChampionship()
  championshipProfile=nil
  pricing = priceFactory.new()
  menuKeys=menuNavigation.new({
    canCollapse=function()
      return active and menuOpen and uiState=='play' and not core_gamestate.loading() and
        not freeroam_bigMapMode.bigMapActive() and not gameplay_missions_missionManager.getForegroundMissionId()
    end,
    collapse=function() M.closeMenu() end
  },guihooks)
  traffic.startGuard()
  if state.pendingRace then
    -- The matching career snapshot already contains the debit. Never debit twice.
    if state.pendingRace.championshipId then
      ladder.settle(state.championship,state.pendingRace.championshipId,state.pendingRace.round,'loss')
    end
    if state.pendingRace.walletKey then traffic.settleWallet(state.pendingRace.walletKey,state.pendingRace.stake,'loss') end
    state.reputation=math.max(0,state.reputation-10)
    traffic.setReputation(state.reputation)
    state.stats.loss = state.stats.loss+1
    state.stats.net = state.stats.net-state.pendingRace.stake
    state.history[#state.history+1] = {id = state.pendingRace.id, opponent = state.pendingRace.opponent,
      stake = state.pendingRace.stake, outcome = 'loss', fines=state.pendingRace.fines or 0, net = -state.pendingRace.stake-(state.pendingRace.fines or 0), reason = 'interrupted'}
    state.pendingRace = nil
    requestSave()
    message('Незавершённая сохранённая гонка засчитана как сход. Повторного списания нет.')
  end
  traffic.register(true, state.settings.police, state.settings.racerDensity)
  traffic.applyPolice(state.settings.police)
end

function M.openMenu(id)
  if not active then return end
  serviceInventory = tonumber(id)
  menuOpen = true
end
function M.toggleMenu() if active then menuOpen = not menuOpen end end
function M.closeMenu()
  menuOpen = false
  if ui.clearBounds then ui.clearBounds() end
end
function M.isActive() return active end

function M.challenge()
  if not active then return end
  local ok, why = race.challenge()
  if not ok then message(why) end
end
function M.onHorn(data)
  if not active or clock-hornAt < 2 then return end
  local c = tyres.connections[data.vehicleId]
  if not c or c.session ~= data.session or not player() or player():getID() ~= data.vehicleId then return end
  hornAt = clock
  if championshipMarker.near(routes.dragStripInfo(),player()) and not race.busy() then M.openChampionship() else M.challenge() end
end
function M.startRace(bet)
  if not active then return end
  local ok, why = race.start(tonumber(bet))
  if not ok then message(why, 'warning') end
end

function M.placeDragOpponent(id)
  local car=id and getObjectByID(id)
  if not car then return false,'Соперник недоступен. Выберите другого.' end
  local zone=routes.dragStartZone(player(),car)
  if not zone.valid then return false,zone.text end
  startTraffic.clear(zone.grid,player():getID(),id)
  local ok=pcall(spawn.safeTeleport,car,zone.grid.opponentPos,zone.grid.rotation,nil,nil,false,true,false)
  if not ok then return false,'Не удалось поставить бота на дрэг-стрип. Деньги не списаны.' end
  car:setActive(1)
  car:setMeshAlpha(1,'')
  command(id,'ai.setMode("disabled"); controller.setFreeze(1)')
  return true
end

function M.selectRaceMode(mode)
  if not active or not race or race.phase~='offer' then return false end
  if mode=='drag' then
    local p,o=player(),race.opponentId and getObjectByID(race.opponentId)
    local zone=p and o and routes.dragStartZone(p,o)
    if not zone or not zone.valid then
      message(zone and zone.text or 'Подъедьте к Alder Drag Strip для дрэг-заезда.','warning')
      return false
    end
    if race.mode~='drag' then
      local placed,why=M.placeDragOpponent(race.opponentId)
      if not placed then message(why,'warning') return false end
    end
    race.setMode('drag')
    core_groundMarkers.setPath({routes.dragStripInfo().finish})
    startPreview.clear()
    message('Выбран дрэг-заезд Alder Drag Strip: около 400 м по штатной прямой.','success')
    return true
  end
  if mode=='street' then
    race.setMode('street')
    command(race.opponentId,'controller.setFreeze(0); ai.setMode("stop")')
    startPreview.clear()
    return true
  end
  return false
end

function M.dragStripAvailable()
  local info=active and routes.dragStripInfo()
  local p=active and player()
  return p and info and p:getPosition():squaredDistance(info.start)<=110*110 or false
end
function M.navigateDragStrip()
  if not active or race.committed() then return false end
  local info,why=routes.dragStripInfo()
  if not info then message(why,'warning') return false end
  core_groundMarkers.setPath({championshipMarker.position(info)})
  message('GPS до регистрации чемпионата Alder. Подъедьте к оранжевому маркеру и подайте гудок либо откройте чемпионат в меню.','info')
  return true
end
function M.openChampionship()
  if not active then return end
  menuOpen=true ui.selectTab('championship')
end
function M.startChampionshipRound()
  local ok,why=canRace()
  if not ok then message(why,'warning') return false end
  if race.busy() or championship.busy() then return false end
  if not M.dragStripAvailable() then message('Подъедьте к регистрации у Alder Drag Strip.','warning') return false end
  if player():getVelocity():length()>0.5 then message('Остановитесь перед подготовкой этапа.','warning') return false end
  traffic.inspectPlayer(player())
  local power=traffic.measuredPlayerPower()
  if not power then message('Считываем мощность двигателя. Повторите через секунду.','info') return false end
  ok,why=championship.start(power,inventoryId(player():getID()))
  if not ok then message(why,'warning') end
  return ok
end
function M.resetChampionship()
  if not active or saving or serviceBusy or race.busy() or championship.busy() then return false end
  state.championship=nil requestSave() return true
end
function M.cancelChampionshipPreparation()
  if championship and championship.phase~='racing' then championship.release() end
end
function M.receiveChampionshipPower(data)
  if not active or not championship or type(data)~='table' then return false end
  return championship.receive(data)
end

function M.challengeRacer(id,mode)
  if not active or not tonumber(id) then return false end
  if mode=='drag' then return M.challengeDrag(tonumber(id)) end
  if mode~='street' then return false end
  local ok,why=race.challenge('street',tonumber(id))
  if not ok then message(why,'warning') end
  return ok
end
function M.challengeDrag(id)
  if not active then return false end
  local allowed,why=canRace()
  if not allowed then message(why,'warning') return false end
  local zone=routes.dragStartZone(player())
  if not zone.valid then message(zone.text,'warning') return false end
  local ok,reason=race.challenge('drag',id)
  if not ok then message(reason,'warning') return false end
  core_groundMarkers.setPath({routes.dragStripInfo().finish})
  return true
end
function M.receiveOpponentPerformance(data)
  if active and type(data)=='table' then traffic.receivePerformance(data) end
end
function M.receivePlayerPerformance(data)
  if active and type(data)=='table' then traffic.receivePlayerPerformance(data) end
end

function M.receivePricePerformance(data)
  if active and pricing then pricing.receivePerformance(data) end
end
function M.cancelRace() if active then race.cancel() end end
function M.openMap()
  if not active or (race.committed()) then return end
  menuOpen = false
  ui.focusOffer()
  freeroam_bigMapMode.enterBigMap()
end

function M.garages()
  if garageCache then return garageCache end
  local result = {}
  local labels = {servicestationGarage = 'Belasco — городской автосервис', commercialGarage = 'Промзона — большой гараж', alderDragwayGarage = 'Alder Dragway — гараж у дрэг-стрипа'}
  for _, garage in ipairs(freeroam_facilities.getFacilitiesByType('garage') or {}) do
    local descriptions={servicestationGarage='Город и дилер рядом. Удобная база для первых заездов.',commercialGarage='Промышленные кварталы и широкие дороги.',alderDragwayGarage='Рядом дрэг-стрип. База для мощных проектов.'}
    result[#result+1] = {id = garage.id, name = labels[garage.id] or _tr(garage.name),description=descriptions[garage.id] or 'Личный гараж на West Coast USA.',
      starter=garage.id==starterGarage,price=garage.id==starterGarage and 0 or garagePrice}
  end
  garageCache=result
  return result
end

function M.chooseGarage(id)
  if not active or state.homeGarage or pendingGarage or saving or serviceBusy or race.busy() then return end
  if id~=starterGarage then return end
  local found = false
  for _, garage in ipairs(M.garages()) do if garage.id == id then found = true end end
  if not found or not player() then return end
  pendingGarage={id=id,vehicleId=player():getID()}
  message('Подготавливаем гараж…')
end

local function garagePose(id,car)
  local pos,rot=freeroam_facilities.getGaragePosRot({id=id},car)
  if pos and rot then garagePositions[id]=vec3(pos) return pos,rot end
end
local function teleportGarage(id,car,pos,rot)
  spawn.safeTeleport(car,pos,rot,nil,nil,false,true,false)
  if core_camera then core_camera.resetCamera(0) end
  if extensions then extensions.hook('onTeleportedToGarage',id,car) end
end
local function chooseGarageNow()
  local job=pendingGarage
  if not job or saving then return end
  pendingGarage=nil
  local car=player()
  if not car or car:getID()~=job.vehicleId then return end
  local pos,rot=garagePose(job.id,car)
  if not pos then message('Не найдено свободное место в этом гараже.','warning') return end
  local ok,why=pcall(teleportGarage,job.id,car,pos,rot)
  if not ok then log('E','StreetRacers',tostring(why)) message('Не удалось подготовить гараж. Повторите подготовку Belasco.','warning') return end
  state.homeGarage=job.id
  requestSave()
  message('Гараж готов. Купите первую машину у дилера на стартовые $15 000.','success')
end

local function garageTransactionAllowed()
  return active and state.homeGarage and not saving and not saveRequested and not serviceBusy and not pendingGarage and
    not race.busy() and not championship.busy() and not gameplay_missions_missionManager.getForegroundMissionId()
end

function M.buyGarage(id,expectedPrice)
  if not garageTransactionAllowed() or id==starterGarage or state.ownedGarages[id] then return false end
  local found
  for _,g in ipairs(M.garages()) do if g.id==id then found=g break end end
  if not found or expectedPrice~=garagePrice then return false end
  if money()<garagePrice then message('Для покупки гаража нужно $100 000.','warning') return false end
  changeMoney(-garagePrice,'StreetRacers: покупка гаража — '..found.name)
  state.ownedGarages[id]=true
  requestSave()
  message('Гараж куплен. Можно пользоваться им и назначить домашней базой.','success')
  return true
end

function M.setHomeGarage(id)
  if not garageTransactionAllowed() or not state.ownedGarages[id] then return false end
  for _,g in ipairs(M.garages()) do if g.id==id then
    state.homeGarage=id requestSave() message('Домашний гараж изменён.','success') return true
  end end
  return false
end

function M.navigateHome()
  if not active or not state.homeGarage or race.committed() or not player() then return end
  local pos = garagePositions[state.homeGarage] or garagePose(state.homeGarage,player())
  if pos then core_groundMarkers.setPath({pos}) menuOpen = false end
end

function M.getReadyRacers() return readyRacers end
function M.navigateRacer(id)
  if not active or race.busy() then return end
  for _,row in ipairs(traffic.ready(player())) do
    if row.id==id then core_groundMarkers.setPath({row.pos}) menuOpen=false return end
  end
  message('Этот водитель больше не готов к гонке. Выберите другого.','warning')
end
function M.showRacersMap()
  if not active or race.busy() then return end
  menuOpen=false
  freeroam_bigMapMode.enterBigMap()
end

-- Quotes use a garage centre cached once, not the expensive parking search per frame.
local function towQuote()
  local car=player()
  local id=car and inventoryId(car:getID())
  if not state.homeGarage then return nil,'Дождитесь подготовки стартового гаража Belasco.' end
  local allowed,why=canService(id,'roadside')
  if not allowed or serviceBusy then return nil,why or 'Дождитесь завершения обслуживания.' end
  local pos=garagePositions[state.homeGarage]
  if not pos then
    local facility=freeroam_facilities.getGarage and freeroam_facilities.getGarage(state.homeGarage)
    -- The menu only queues this lookup; no loading parking sites inside draw().
    if facility and facility.pos then pos=vec3(facility.pos) garagePositions[state.homeGarage]=pos end
  end
  if not pos then return nil,'Рассчитываем эвакуацию…' end
  local distance=car:getPosition():distance(pos)
  local price=300+math.ceil(distance/1000)*100
  if money()<price then return nil,'Недостаточно денег для эвакуации ($'..price..').' end
  return {price=price,distance=distance,inventoryId=id,vehicleId=car:getID(),garage=state.homeGarage}
end

function M.requestTow(expectedPrice)
  if not active then return end
  local quote,why=towQuote()
  if not quote then message(why,'warning') return end
  if quote.price~=expectedPrice then message('Стоимость эвакуации изменилась. Повторите заказ.','warning') return end
  serviceBusy,serviceAt=true,clock
  serviceSerial=serviceSerial+1
  local serial,profile=serviceSerial,saveFingerprint()
  local ctx={mode='tow',id=quote.inventoryId,vehicleId=quote.vehicleId,token='service:'..serviceSerial}
  serviceContext=ctx
  ctx.capture=function()
    career_modules_inventory.updatePartConditions(nil,ctx.id,function()
      if not active or serviceContext~=ctx or serial~=serviceSerial or profile~=saveFingerprint() then return end
      -- Freeze plus fresh tyre/damage snapshots preserve punctures and broken parts.
      towJob={ctx=ctx,quote=quote}
    end)
  end
  command(ctx.vehicleId,'controller.setFreeze(1)')
  ctx.waiting=tyres.snapshot(ctx.token,ctx.vehicleId)[ctx.vehicleId]
  if not ctx.waiting then clearService() message('Дождитесь связи с машиной и повторите вызов.','warning') end
end

local function finishTow(dt)
  local job=towJob
  if not job then return end
  local ctx,q=job.ctx,job.quote
  local car=player()
  if serviceContext~=ctx or not car or car:getID()~=ctx.vehicleId or inventoryId(ctx.vehicleId)~=ctx.id or saving then
    clearService() message('Эвакуация отменена: машина или состояние карьеры изменились.','warning') return
  end
  if job.destination then
    job.wait=job.wait+(dt or 0)
    if job.wait<0.35 then return end
    local centre=vec3(car:getSpawnWorldOOBB():getCenter())
    if centre:distance(job.destination)>30 then
      clearService() message('Эвакуатор не смог разместить машину. Деньги не списаны.','warning') return
    end
    changeMoney(-q.price,'StreetRacers: эвакуация в гараж')
    career_modules_inventory.setVehicleDirty(ctx.id)
    if core_camera then core_camera.resetCamera(0) end
    if extensions then extensions.hook('onTeleportedToGarage',q.garage,car) end
    clearService()
    viewCache=nil
    requestSave()
    message('Машина доставлена в гараж за $'..q.price..'. Ремонт заказывается отдельно.','success')
    return
  end
  local allowed,why=canService(ctx.id,'roadside')
  if not allowed then clearService() message(why,'warning') return end
  local pos,rot=garagePose(q.garage,car)
  if not pos or money()<q.price then clearService() message('Нет свободного места в гараже или денег на эвакуацию.','warning') return end
  local ok,err=pcall(spawn.safeTeleport,car,pos,rot,nil,nil,false,true,false)
  if not ok then
    if not ok then log('E','StreetRacers',tostring(err)) end
    clearService() message('Эвакуатор не смог разместить машину. Деньги не списаны.','warning') return
  end
  job.destination,job.wait=vec3(pos),0
end

function M.navigateDealer()
  if not active or race.committed() then return end
  -- Verified pedestrian entrance of the starting dealership on West Coast USA 0.39.4.
  core_groundMarkers.setPath({vec3(905.54,-542.39,164.31)})
  menuOpen = false
end

function M.setPolice(enabled)
  if not active or type(enabled) ~= 'boolean' or race.busy() or saving then return end
  state.settings.police = enabled
  traffic.register(true, enabled)
  traffic.applyPolice(enabled)
  if enabled then gameplay_traffic.ensureReservedVehicles('streetRacersPolice', 1) end
  requestSave()
  message(enabled and 'Полиция включена. Патруль появится после загрузки машины.' or 'Полиция отключена, текущие погони прекращены.')
end

function M.setTyreHud(enabled)
  if not active or type(enabled)~='boolean' or saving then return end
  state.settings.tyreHud = enabled
  requestSave()
end
function M.setTorqueCurve(enabled)
  if not active or type(enabled)~='boolean' or saving then return end
  state.settings.torqueCurve=enabled
  torqueApp.update(enabled)
  requestSave()
end
function M.setRacerMarkers(enabled)
  if active and type(enabled)=='boolean' then state.settings.racerMarkers=enabled requestSave() end
end
function M.setRacerDensity(value)
  if not active or not rules.racerDensities[value] or race.busy() or saving or serviceBusy then return end
  state.settings.racerDensity=value
  traffic.register(true,state.settings.police,value)
  requestSave()
  message('Гонщиков: '..rules.racerDensities[value].label..'. Готовность водителей обновлена. Для смены состава нажмите «Обновить трафик».')
end
function M.clearTrafficExclusions() if active then traffic.clearExclusions() end end

function M.refreshTraffic()
  if not active or race.busy() or saving or serviceBusy then return end
  traffic.refresh()
  message('Формируется новый трафик с гоночными конфигурациями.')
end

function M.getPoliceStatus() return active and traffic.policeStatus() or nil end

local function tyreServiceMode(id,mode)
  for _,candidate in ipairs(career_modules_inventory.getInventoryIdsInClosestGarage()) do
    if candidate==id then return 'garage' end
  end
  return mode=='garage' and 'garage' or 'roadside'
end

function M.replaceTyres(id, partId, mode, expectedToken, expectedPrice, model)
  id, partId = tonumber(id), tonumber(partId)
  if not active or serviceBusy then return end
  if mode~=nil and mode~='garage' and mode~='roadside' then message('Неизвестный вид обслуживания.','warning') return end
  mode=tyreServiceMode(id,mode)
  local entry, why = tyres.quote(id, partId, mode, model)
  if not entry then message(why, 'warning') return end
  if (expectedToken and entry.token~=expectedToken) or (expectedPrice and entry.charge~=expectedPrice) then
    message('Комплект или цена изменились. Откройте заказ заново.', 'warning') return
  end
  serviceBusy, serviceAt = true, clock
  serviceSerial = serviceSerial+1
  local transaction = serviceSerial
  local expectedProfile = saveFingerprint()
  local ctx = {id=id,partId=partId,mode=mode,vehicleId=career_modules_inventory.getVehicleIdFromInventoryId(id),
    token='service:'..transaction,tyreToken=entry.token}
  serviceContext = ctx
  -- Capture all vehicle damage first; a tyre purchase must not repair the rest of the car.
  ctx.capture = function() career_modules_inventory.updatePartConditions(nil, id, function()
    if not active or expectedProfile ~= saveFingerprint() or not serviceBusy or transaction ~= serviceSerial then return end
    if career_modules_inventory.getVehicleIdFromInventoryId(id)~=ctx.vehicleId then
      clearService() message('Машина изменилась. Вызовите обслуживание заново.', 'warning') return
    end
    local part = career_modules_partInventory.getInventory()[partId]
    local car = career_modules_inventory.getVehicles()[id]
    if not part or not car then clearService() return end
    local latest, quoteError = tyres.quote(id, partId, mode, model)
    if not latest or latest.token~=entry.token or latest.charge~=entry.charge then
      clearService() message(quoteError or 'Комплект или цена изменились. Откройте заказ заново.', 'warning') return
    end
    local oldPart,oldConfig=deepcopy(part),deepcopy(car.config)
    local oldChanged,oldList=deepcopy(car.changedSlots),deepcopy(car.partList)
    local oldConditions = deepcopy(car.partConditions)
    local config
    if model and model~=part.name then
      local data=core_vehicle_manager.getVehicleData(ctx.vehicleId)
      config=deepcopy(car.config or (data and data.config))
      if config and not config.partsTree and data and data.config then config.partsTree=deepcopy(data.config.partsTree) end
      local node=config and tyreCatalog.node(config.partsTree,part.containingSlot)
      if not node then clearService() message('Не удалось прочитать слот шин. Откройте заказ заново.','warning') return end
      node.chosenPartName,node.partPath,node.children=model,part.containingSlot..model,nil
      -- partsTree is the native 0.40 source of truth; discard the obsolete flat map.
      config.parts=nil
    end
    local success, errorText = tyres.replace(id, partId, mode, ctx.tyreToken, model)
    if success then
      if config then car.config=config car.partConditions[oldPart.partPath]=nil end
      car.changedSlots=car.changedSlots or {}
      car.changedSlots[part.containingSlot]=true
      car.partList=nil
      local fresh = {integrityValue = 1, visualValue = 1, odometer = 0}
      part.partCondition, car.partConditions[part.partPath] = fresh, fresh
      -- Core spawnVehicle can repair minor damage as a convenience. Restore the precise
      -- captured conditions after spawning so buying tyres cannot repair other parts.
      local conditions = deepcopy(car.partConditions)
      local replacement = career_modules_inventory.spawnVehicle(id, 2, function()
        if not active or expectedProfile ~= saveFingerprint() or transaction ~= serviceSerial then return end
        car.partConditions = conditions
        if not ctx.restorationQueued then career_modules_inventory.applyPartConditions(id) end
        clearService()
        local vehicleId = career_modules_inventory.getVehicleIdFromInventoryId(id)
        if vehicleId then tyres.attach(vehicleId, true) end
        requestSave()
        viewCache=nil
        if career_modules_vehiclePerformance and career_modules_vehiclePerformance.invalidateCertification then
          career_modules_vehiclePerformance.invalidateCertification(id)
        end
        message(mode=='roadside' and 'Выездной шиномонтаж: выбранные шины установлены.' or 'Новые шины установлены. Цена включает монтаж.', 'success')
      end)
      if replacement and serviceContext==ctx then
        -- Queue restoration immediately, after native initialization, even if the
        -- later bridge callback never arrives. Do not persist convenience repairs.
        car.partConditions = conditions
        career_modules_inventory.applyPartConditions(id)
        ctx.restorationQueued = true
      end
      if not replacement and serviceContext==ctx then
        -- Failed before respawn: restore the old tyre and refund this transaction.
        state.tyres[part.tags.streetRacersTyreId] = nil
        for key in pairs(part) do part[key]=nil end
        for key,value in pairs(oldPart) do part[key]=value end
        car.config,car.partConditions=oldConfig,oldConditions
        car.changedSlots,car.partList=oldChanged,oldList
        changeMoney(entry.charge, 'StreetRacers: возврат за несостоявшуюся замену шин')
        clearService()
        tyres.attach(ctx.vehicleId, true)
        requestSave()
        message('Не удалось установить шины. Оплата возвращена.', 'warning')
      end
    else
      clearService()
      message(errorText, 'warning')
    end
  end) end
  if mode=='roadside' then
    command(ctx.vehicleId, 'controller.setFreeze(1)')
    ctx.waiting = tyres.snapshot(ctx.token, ctx.vehicleId)[ctx.vehicleId]
    if not ctx.waiting then clearService() message('Дождитесь связи с машиной и повторите вызов.', 'warning') end
  else
    ctx.capture()
  end
end

function M.getStoredParts()
  local rows={}
  for id,part in pairs(career_modules_partInventory.getInventory()) do
    if part.location==0 then
      local value=tyres.resaleValue(part,career_modules_valueCalculator.getPartValue(part))
      if rules.finite(value) and value>=0 then
        rows[#rows+1]={id=id,name=type(part.description)=='table' and part.description.description or part.description or part.name,price=value}
      end
    end
  end
  table.sort(rows,function(a,b) return a.id<b.id end)
  return rows
end
function M.sellPart(id,expectedPrice)
  if not active or saving or serviceBusy or race.busy() or tyres.suspended then return end
  local inGarage=#career_modules_inventory.getInventoryIdsInClosestGarage()>0
  if not inGarage then message('Продажа деталей доступна в гараже.','warning') return end
  id=tonumber(id)
  local part=career_modules_partInventory.getInventory()[id]
  if not part or part.location~=0 then message('Деталь уже продана или установлена.','warning') return end
  local price=tyres.resaleValue(part,career_modules_valueCalculator.getPartValue(part))
  if not rules.finite(price) or price~=expectedPrice then message('Цена изменилась. Повторите продажу.','warning') return end
  -- The stock seller recalculates the native price internally. Temporarily
  -- provide our wear-adjusted quote for this exact part so the actual credit
  -- matches the price displayed in the StreetRacers store.
  local valueCalculator=career_modules_valueCalculator
  local originalValue=valueCalculator.getPartValue
  valueCalculator.getPartValue=function(candidate)
    if candidate==part then return price end
    return originalValue(candidate)
  end
  local sold,err=pcall(career_modules_partInventory.sellParts,{id})
  valueCalculator.getPartValue=originalValue
  if not sold then message('Не удалось продать деталь: '..tostring(err),'warning') return end
  requestSave()
  message('Деталь продана за $'..string.format('%.2f',price),'success')
end

function M.requestRoadside(partId, token, price, model)
  if not active or not player() then return end
  M.replaceTyres(inventoryId(player():getID()), partId, 'roadside', token, price, model)
end

function M.getMechanicalRows()
  local car=player()
  local id=car and inventoryId(car:getID())
  local result,byPart={},{}
  if not id or not owned(id) then return result end
  for _,entry in ipairs(mechanicalViews[car:getID()] or {}) do
    local best,length
    for partId,part in pairs(career_modules_partInventory.getInventory()) do
      if part.location==id and type(entry.path)=='string' and type(part.partPath)=='string' then
        local path=part.partPath
        -- The JBeam path can name the containing slot or the actual part.
        local slot=part.containingSlot
        if entry.path==path or entry.path==slot or entry.path:sub(1,#path+1)==path..'/' then
          if not length or #path>length then best,length=partId,#path end
        end
      end
    end
    local key=best or entry.name
    local row=byPart[key]
    if not row then
      row={id=best,kind=entry.kind,name=entry.name,condition=entry.condition}
      byPart[key]=row result[#result+1]=row
    else row.condition=math.min(row.condition,entry.condition) end
    if best then
      local part=career_modules_partInventory.getInventory()[best]
      local hp=traffic.playerPower and traffic.playerPower() or 150
      local labor=({engine=300,gearbox=200,differential=120,clutch=100})[row.kind] or 150
      row.price=math.ceil(labor+(math.max(100,tonumber(part.value) or 1000)*1.2+hp*2)*(1-row.condition))
    end
  end
  table.sort(result,function(a,b) return a.name<b.name end)
  return result
end

function M.repairComponent(partId,expectedPrice)
  if not active or serviceBusy then return end
  local car=player()
  local id=car and inventoryId(car:getID())
  local allowed,why=canService(id)
  if not allowed then message(why,'warning') return end
  local quote
  for _,row in ipairs(M.getMechanicalRows()) do if row.id==partId then quote=row end end
  if not quote or quote.condition>0.98 or quote.price~=expectedPrice or money()<quote.price then
    message('Узел, его состояние, цена или баланс изменились. Повторите заказ.','warning') return
  end
  serviceBusy,serviceAt=true,clock
  serviceSerial=serviceSerial+1
  local serial,profile=serviceSerial,saveFingerprint()
  local ctx={mode='mechanical',id=id,vehicleId=car:getID(),token='service:'..serviceSerial}
  serviceContext=ctx
  ctx.capture=function()
    career_modules_inventory.updatePartConditions(nil,id,function()
      if not active or serviceContext~=ctx or serial~=serviceSerial or profile~=saveFingerprint() then return end
      local ok,reason=canService(id)
      local part=career_modules_partInventory.getInventory()[partId]
      local currentQuote
      for _,row in ipairs(M.getMechanicalRows()) do if row.id==partId then currentQuote=row end end
      if not currentQuote or currentQuote.price~=quote.price then clearService() message('Состояние узла изменилось. Повторите заказ.','warning') return end
      if not ok or not part or part.location~=id or career_modules_inventory.getVehicleIdFromInventoryId(id)~=ctx.vehicleId or money()<quote.price then
        clearService() message(reason or 'Машина или баланс изменились.','warning') return
      end
      local inventoryCar=career_modules_inventory.getVehicles()[id]
      local oldConditions,oldPart=deepcopy(inventoryCar.partConditions),deepcopy(part.partCondition)
      local fresh=deepcopy(part.partCondition or {})
      fresh.integrityValue,fresh.integrityState,fresh.odometer=1,nil,0
      fresh.visualValue=fresh.visualValue or 1
      part.partCondition,inventoryCar.partConditions[part.partPath]=fresh,fresh
      local conditions=deepcopy(inventoryCar.partConditions)
      changeMoney(-quote.price,'StreetRacers: переборка узла '..quote.name)
      local replacement=career_modules_inventory.spawnVehicle(id,2,function()
        if not active or serviceContext~=ctx or serial~=serviceSerial or profile~=saveFingerprint() then return end
        inventoryCar.partConditions=conditions
        if not ctx.restorationQueued then career_modules_inventory.applyPartConditions(id) end
        clearService()
        tyres.attach(career_modules_inventory.getVehicleIdFromInventoryId(id),true)
        requestSave()
        message('Узел обслужен. Состояние остальных деталей сохранено.','success')
      end)
      if replacement and serviceContext==ctx then
        inventoryCar.partConditions=conditions
        career_modules_inventory.applyPartConditions(id)
        ctx.restorationQueued=true
      elseif not replacement and serviceContext==ctx then
        part.partCondition,inventoryCar.partConditions=oldPart,oldConditions
        changeMoney(quote.price,'StreetRacers: возврат за несостоявшийся ремонт')
        clearService() requestSave() message('Ремонт не выполнен. Деньги возвращены.','warning')
      end
    end)
  end
  command(ctx.vehicleId,'controller.setFreeze(1)')
  ctx.waiting=tyres.snapshot(ctx.token,ctx.vehicleId)[ctx.vehicleId]
  if not ctx.waiting then clearService() message('Дождитесь связи с машиной.','warning') end
end

function M.vehicleReady(data) if active then tyres.ready(data) end end

local function finishSaveIfReady()
  local ctx = saveContext
  if not ctx or not ctx.path or next(ctx.pending) then return end
  ctx.written = true
  local ok = career_saveSystem.jsonWriteFileSafe(ctx.path .. fileName, state, true)
  if not ok then saving = false message('Не удалось сохранить StreetRacers. Продолжение заезда отменено.', 'error') end
  career_saveSystem.asyncSaveExtensionFinished('career_modules_streetRacers')
  if not ok then saveContext = nil end
  if not ok and race.phase == 'saving' then race.finish('void', 'Ставка возвращена: ошибка сохранения.') end
end

function M.receiveTyres(data)
  if not active then return end
  local accepted = tyres.receive(data)
  if accepted and type(data.mechanical)=='table' then
    local rows={}
    local previous={}
    for _,row in ipairs(mechanicalViews[data.vehicleId] or {}) do previous[row.name]=row end
    for _,row in ipairs(data.mechanical) do
      if type(row)=='table' and type(row.name)=='string' and rules.finite(row.condition) then
        rows[#rows+1]={name=row.name,kind=row.kind,path=row.path,condition=rules.clamp(row.condition,0,1),
          oilTemperature=rules.finite(row.oilTemperature) and row.oilTemperature or nil,
          coolantTemperature=rules.finite(row.coolantTemperature) and row.coolantTemperature or nil,
          alert=type(row.alert)=='string' and row.alert or nil,critical=row.critical==true}
        if row.kind=='engine' and row.alert and (not previous[row.name] or previous[row.name].alert~=row.alert) then
          log('W','StreetRacers',string.format('Engine warning vehicle=%d device=%s condition=%.3f oil=%s coolant=%s: %s',
            data.vehicleId,row.name,row.condition,tostring(rows[#rows].oilTemperature),tostring(rows[#rows].coolantTemperature),row.alert))
        end
      end
    end
    mechanicalViews[data.vehicleId]=rows
  end
  local ctx = serviceContext
  if accepted and ctx and ctx.waiting and data.request==ctx.token and data.vehicleId==ctx.vehicleId and data.session==ctx.waiting then
    ctx.waiting = nil
    ctx.capture()
  end
  if accepted and saveContext and not saveContext.written and data.request == saveContext.token and saveContext.pending[data.vehicleId] == data.session then
    saveContext.pending[data.vehicleId] = nil
    finishSaveIfReady()
  end
end

function M.onSaveCurrentProfileAsyncStart()
  if not active then return end
  saving = true
  saveSerial = saveSerial+1
  local token = 'save:' .. saveSerial
  career_saveSystem.registerAsyncSaveExtension('career_modules_streetRacers')
  saveContext = {token = token, elapsed = 0, pending = tyres.snapshot(token)}
  -- If base career tries to save during an asynchronous tyre purchase, it must not
  -- commit a mix of the old balance and the new tyres. A fresh snapshot follows.
  if serviceBusy or resumeAt then career_saveSystem.saveFailed() requestSave() end
end
function M.onSaveCurrentProfile(path)
  if not active then return end
  if saveContext then saveContext.path = path finishSaveIfReady() end
end
function M.onSaveFinished()
  if not active then return end
  saving, saveContext = false, nil
  for _,fine in ipairs(deferredFines) do chargeCollision(fine) end
  deferredFines={}
  race.saved()
end

function M.onTrafficSpecialVehiclesProviders() if active then traffic.register(true, state.settings.police) end end
function M.onTrafficStarted() if active then policeReapply = true end end
function M.onTrafficReservedVehiclesReady(provider)
  if active and provider == 'streetRacersPolice' then policeReapply = true end
end
function M.onVehicleDestroyed(id)
  if not active then return end
  traffic.forget(id)
  mechanicalViews[id]=nil
  tyres.connections[id] = nil
  attachPending[id] = nil
end
function M.onVehicleSpawned(id)
  if active then
    traffic.forget(id)
    if player() and player():getID()==id then traffic.invalidatePlayer() end
    attachPending[id] = clock+0.5
  end
end
function M.onVehicleResetted(id)
  if not active then return end
  race.reset(id)
  -- VLua onReset sends the last sample and requests restoration in queue order.
end
function M.onVehicleSwitched() if active then serviceInventory = nil traffic.invalidatePlayer() end end
function M.onInventoryPreRemoveVehicleObject(id, vehicleId)
  if active and vehicleId then tyres.snapshot() end
end
function M.onPursuitAction(id, action)
  if active and action == 'arrest' and race.playerId == id and race.busy() then
    race.finish(race.phase == 'running' and 'loss' or 'void', 'Полиция остановила заезд.')
  end
end
function M.onAnyMissionChanged(status)
  if not active then return end
  if status == 'started' then race.cancel() end
end
function M.onPartShoppingStarted()
  if active then race.cancel() tyres.suspend() end
end
function M.onPartShoppingCancelled() if active then resumeAt = clock+0.5 end end
function M.onPartShoppingTransactionComplete() if active then resumeAt = clock+0.5 traffic.invalidatePlayer() requestSave() end end
function M.onEnterVehicleFinished() if active then tyres.poll() end end
function M.onAddedVehiclePartsToInventory() if active then tyres.poll() pricing.refreshInventory() end end
function M.onVehicleAddedToInventory() if active then pricing.refreshInventory() end end
function M.onVehicleShoppingMenuOpened() if active then pricing.setShopping(true) pricing.refreshOffers() end end
function M.onVehicleShoppingMenuClosed() if active then pricing.setShopping(false) end end
function M.onModActivated() if active then catalogChanged=true end end
function M.onModDeactivated() if active then catalogChanged=true end end
function M.onModManagerModsMounted() if active then catalogChanged=true end end
function M.onUiChangedState(name)
  if type(name)=='string' then
    uiState=name
    if active and pricing then pricing.onUiChangedState(name) end
  end
end

function M.getTyreHudView()
  if not active or not state.settings.tyreHud then return nil end
  local vehicle = player()
  local id = vehicle and inventoryId(vehicle:getID())
  if not id or not owned(id) then return nil end
  -- HUD needs live state only; quoting repairs walks the part inventory and
  -- belongs to the service menu, not the per-frame driving overlay.
  return {wheels=tyres.hud(vehicle:getID()),mechanical=mechanicalViews[vehicle:getID()] or {},suspended=tyres.suspended}
end

function M.onComputerAddFunctions(menuData, functions)
  if not active then return end
  functions.general.streetRacers = {id = 'streetRacers', label = 'StreetRacers', order = 25,
    callback = function() career_career.closeAllMenus() M.openMenu() end}
  for _, vehicle in ipairs(menuData.vehiclesInGarage or {}) do
    local id = vehicle.inventoryId
    functions.vehicleSpecific[id].streetRacersTyres = {id = 'streetRacersTyres', label = 'Запчасти StreetRacers: новые шины', order = 2,
      callback = function() career_career.closeAllMenus() M.openMenu(id) ui.selectTab('tyres') end}
  end
end

function M.getView()
  if not active then return {active = false} end
  local id = serviceInventory or (player() and inventoryId(player():getID()))
  local car = id and career_modules_inventory.getVehicles()[id]
  local roadsideId = player() and inventoryId(player():getID())
  -- Parts scans walk the full inventory. Share one short-lived snapshot between
  -- menu, invitation and race HUD, instead of scanning twice on every draw.
  if not viewCache or clock-viewAt>=0.25 or viewCache.id~=id or viewCache.roadsideId~=roadsideId then
    local rows=id and tyres.parts(id) or {}
    for _,row in ipairs(rows) do row.choices=tyres.choices(id,row.part) end
    viewCache={id=id,roadsideId=roadsideId,rows=rows,mechanical=M.getMechanicalRows(),roadsideRows=roadsideId==id and tyres.roadsideParts(id) or
      (roadsideId and owned(roadsideId) and tyres.roadsideParts(roadsideId) or {})}
    for _,row in ipairs(viewCache.roadsideRows) do row.choices=tyres.choices(roadsideId,row.part) end
    viewAt=clock
  end
  local roadsideAllowed, roadsideReason = canService(roadsideId, 'roadside')
  local tyreMode=tyreServiceMode(id)
  local tyreAllowed,tyreReason=canService(id,tyreMode)
  local tow,towReason=towQuote()
  local carName='Сначала купите автомобиль'
  if car then
    local translator=career_modules_inventory.getVehicleNiceNameTranslated
    local ok,value=pcall(function() return translator and translator(id) end)
    if ok and type(value)=='string' and value~='' then carName=value
    elseif type(car.niceName)=='string' then carName=car.niceName
    elseif type(car.niceName)=='table' and type(car.niceName.txt)=='string' then carName=car.niceName.txt
    else carName=tostring(car.model or 'Автомобиль') end
  end
  local startZone=startPreview.getView()
  return {active = true, state = state, race = race, money = money(), inventoryId = id,
    carName = carName, tyres = viewCache.rows,
    roadsideInventoryId=roadsideId,
    tyreMode=tyreMode,tyreAllowed=tyreAllowed,tyreReason=tyreReason,roadsideMode=tyreServiceMode(roadsideId),
    roadsideTyres = viewCache.roadsideRows, tow=tow,towReason=towReason,garagePending=pendingGarage~=nil,
    roadsideAllowed = roadsideAllowed and not serviceBusy, roadsideReason = roadsideReason,
    excludedTraffic=traffic.exclusions(),mechanical=viewCache.mechanical,startZone=startZone,
    championshipPhase=championship and championship.phase or 'idle',
    saving = saving or serviceBusy, message = clock-lastMessageAt < 20 and lastMessage or '',
    countdown = countdownAt and clock-countdownAt < 1.2 and lastCountdown or nil}
end

function M.onDrawOnMinimap(td)
  if not active or not race then return end
  if not race.busy() and state.settings.racerMarkers~=false then racerMarkers.minimap(td,traffic.ready(player())) end
  if not race.committed() or race.phase=='settling' then return end
  local opponent=getObjectByID(race.opponentId)
  local utils=ui_apps_minimap_utils
  if not opponent or not opponent:getActive() or not utils then return end
  local pos=opponent:getPosition()
  local fill,border=color(255,65,160,255),color(255,255,255,255)
  if utils.drawEdgePointer(pos,fill,border,8) then return end
  local xx,xy,yx,yy,ox,oy=utils.getWorldToMapTransform()
  -- Above ordinary vehicle icons, below the player and the native map mask.
  td:circleMarker(pos.x,pos.y,8,2,utils.dpi or 1,fill,border,xx,xy,yx,yy,ox,oy,95)
end

function M.onUpdate(dtReal, dtSim)
  if not active then return end
  clock, pollTimer = clock+dtReal, pollTimer+dtReal
  -- Do not open ImGui, scan vehicles or alter UI layouts while the native world
  -- is loading. A spawned player alone does not mean the UI is ready to play.
  if waitForLoading() then return end
  if not state.homeGarage and not pendingGarage and not autoGarageAttempted then
    M.chooseGarage(starterGarage)
    if pendingGarage then autoGarageAttempted=true end
  end
  chooseGarageNow()
  finishTow(dtReal)
  if serviceAt and clock-serviceAt > 15 then
    clearService()
    serviceSerial = serviceSerial+1
    message('Обслуживание не получило ответ от машины. Проверьте её состояние в гараже.', 'error')
  end
  if resumeAt and clock >= resumeAt then resumeAt = nil tyres.resume() end
  for id, at in pairs(attachPending) do
    if clock >= at then tyres.attach(id, true) attachPending[id] = nil end
  end
  if saveContext then
    saveContext.elapsed = saveContext.elapsed+dtReal
    if saveContext.elapsed > (saveContext.written and 20 or 5) then
      career_saveSystem.saveFailed()
      saveContext, saving = nil, false
      career_saveSystem.asyncSaveExtensionFinished('career_modules_streetRacers')
      message('Нет ответа от машины при сохранении. Старое сохранение сохранено.', 'error')
      if race.phase == 'saving' then race.finish('void', 'Сохранение не удалось: ставка возвращена.') end
    end
  end
  if not saving and #deferredFines>0 then
    for _,fine in ipairs(deferredFines) do chargeCollision(fine) end
    deferredFines={}
  end
  race.update(dtReal, dtSim)
  local entrantAllowed=player() and state.championship and owned(inventoryId(player():getID())) and
    inventoryId(player():getID())==state.championship.inventoryId and M.dragStripAvailable() and
    not gameplay_missions_missionManager.getForegroundMissionId() and not serviceBusy
  championship.update(dtReal,dtSim,entrantAllowed)
  championshipMarker.update(routes.dragStripInfo(),player(),state.homeGarage~=nil and not race.busy(),freeroam_bigMapMode.bigMapActive())
  startTraffic.update(race)
  startPreview.update(dtReal,race.phase=='offer',player(),race.opponentId and getObjectByID(race.opponentId),race.mode)
  if catalogChanged and not race.busy() and race.phase~='offer' and not saving and not serviceBusy then
    catalogChanged=false
    traffic.invalidateCatalog()
    pricing.invalidate()
  end
  pricing.update(dtReal,state.homeGarage~=nil and not race.busy() and not championship.busy() and not saving and not serviceBusy)
  if state.homeGarage and not pendingGarage then
    traffic.update(dtReal,player(),state.settings.racerMarkers~=false and not race.busy() and not freeroam_bigMapMode.bigMapActive())
  end
  markerTimer=markerTimer+dtReal
  if markerTimer>=0.25 then
    markerTimer=0
    readyRacers=traffic.ready(player())
    racerMarkers.update(readyRacers,state.homeGarage~=nil and state.settings.racerMarkers~=false and not race.busy() and freeroam_bigMapMode.bigMapActive())
  end
  if pollTimer > 1 then
    pollTimer = 0
    if not saving then tyres.poll() end
    if policeReapply then traffic.applyPolice(state.settings.police) policeReapply = false end
    if not gameplay_missions_missionManager.getForegroundMissionId() and not race.busy() and not serviceBusy then
      traffic.maintainPolice(state.settings.police)
    end
    if state.homeGarage and not garagePositions[state.homeGarage] and player() and not race.busy() and not serviceBusy and not saving then
      garagePose(state.homeGarage,player())
    end
    routePreview.update(race.phase=='offer' and race.mode~='drag' and freeroam_bigMapMode.bigMapActive(),player())
    torqueApp.update(state.settings.torqueCurve and player()~=nil and owned(inventoryId(player():getID())))
  end
  if saveRequested and not saving and not serviceBusy and not resumeAt then
    saveRequested = false
    career_saveSystem.saveCurrent()
  end
  if ui.clearBounds then ui.clearBounds() end
  if menuOpen and not freeroam_bigMapMode.bigMapActive() then ui.draw(M) end
  if not menuOpen and not freeroam_bigMapMode.bigMapActive() and (race.phase=='offer' or race.phase=='preparing' or race.phase=='saving') then ui.drawOffer(M) end
  if not freeroam_bigMapMode.bigMapActive() and not gameplay_missions_missionManager.getForegroundMissionId() then
  if race.phase == 'running' or race.phase == 'countdown' or race.phase=='staging' or (countdownAt and clock-countdownAt < 1.2) then ui.hud(M) end
    tyreHud.draw(M.getTyreHudView(),ui.tyrePosition and ui.tyrePosition())
  end
  if freeroam_bigMapMode.bigMapActive() then routePreview.draw() end
  if not freeroam_bigMapMode.bigMapActive() then startPreview.draw() end

end

local function shutdown()
  if not active then return end
  if menuKeys then menuKeys.stop() menuKeys=nil end
  clearService()
  release(race and race.playerId, heldOpponent)
  tyres.stop()
  if garageAccess then garageAccess.stop() garageAccess=nil end
  pricing.stop()
  championship.release()
  championshipMarker.clear()
  championshipProfile=nil
  traffic.stop()
  nativeDrag.stop()
  racerMarkers.clear()
  torqueApp.stop()
  routePreview.clear()
  startPreview.clear()
  active, saving, saveRequested, menuOpen = false, false, false, false
  saveContext = nil
  deferredFines={}
  attachPending, resumeAt = {}, nil
  serviceBusy, serviceAt = false, nil
  serviceSerial = serviceSerial+1
  garageCache,garagePositions,pendingGarage=nil,{},nil
  readyRacers,viewCache={},nil
  mechanicalViews={}
  trafficLoadingAt, trafficLoadingReleased = nil, false
end

function M.onExtensionLoaded() initialize() end
function M.onCareerActive(enabled) if enabled then initialize() else shutdown() end end
M.onExtensionUnloaded = shutdown
M.onClientEndMission = shutdown
return M
