-- StreetRacers, 2026. MIT. Independent starting mode; no overhaul required.
return {
  id = 'streetRacers', order = 90, tier = 'major', title = 'StreetRacers',
  description = 'Уличные гонки и дрэг на деньги. Выбирай водителя и трассу, береги шины. West Coast USA.',
  image = 'images/career/start_fresh.jpg', tag = 'StreetRacers • 0.4.21 alpha',
  initPlayerAttributes = function(attributes)
    attributes.setAttributes({money = 15000}, {label = 'StreetRacers: стартовый капитал'})
  end,
  setupInventory = function()
    spawn.safeTeleport(getPlayerVehicle(0), vec3(905.54, -542.39, 164.31))
    gameplay_walk.setRot(vec3(-1, 1.5, 0.75), vec3(0, 0, 1))
  end
}
