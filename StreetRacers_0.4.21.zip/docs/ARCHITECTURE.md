# StreetRacers architecture

Target: BeamNG.drive 0.40, West Coast USA; tested on 0.40.1 and 0.40.4. No game source file overrides, bundled vehicle assets, modscript bootstrap, RLS dependency or copied reference-mod implementation. Pricing uses reversible in-memory API wrappers only while this career is active.

## Entry points

- `career/startingModes/streetRacers.lua`: native starting-mode discovery, initial money and walking position.
- `career/modules/streetRacers.lua`: auto-discovered career extension. Only activates for `startingOptions.startMode == 'streetRacers'`. Owns money, native inventory, profile saves, service transactions and lifecycle hooks.
- `streetRacers/race.lua`: engine-independent race state machine, escrow lifecycle, finish detection and interruption handling.
- `streetRacers/routes.lua`: GPS projection, connected navgraph path, road width and same-direction starting grid using damage-preserving `spawn.safeTeleport`.
- `streetRacers/traffic.lua`: native special-vehicle providers, full configuration catalogue, paint selection, cached opponent acceptance and police switch.
- `streetRacers/tyres.lua`: inventory identities, wheel-to-part binding, vehicle sessions, snapshots and paid replacement.
- `vehicle/extensions/streetRacersVehicle.lua`: VLua horn events, wheel telemetry, friction multiplier, tyre deflation and reset handshake.
- `common/streetRacers/domain.lua`: pure classification, economy, swept finish intersection and original wear/temperature model.
- `streetRacers/ui.lua`: native ImGui career menu, contextual horn-triggered offer window and race HUD. No permanent race tab or manual challenge button.
- `streetRacers/tyreHud.lua`: compact wheel rows, wear bars, temperatures and conditional alerts, automatically drawn during driving. Geometry is shared with the developer preview renderer; native drawing scales to the ImGui font.
- `streetRacers/pricing.lua`: power-only valuation for every non-official motor-vehicle configuration, immediate market scan scheduling and verified-list filtering. It never edits game catalogue data or vehicle ZIPs.

The helper modules use `require('ge/extensions/streetRacers/...')` because GE's package path includes `lua/?.lua`, not `lua/ge/extensions/?.lua`.

## 0.4.5 loading guard

The active StreetRacers update returns while core_gamestate.loading() is true. Menu drawing, scanning, layout changes and queued services wait for native loading completion. A 90-second grace period runs only when careerVehicles remains requested while the known world-loading requests are clear and the player object is active. Recovery releases careerVehicles only; it does not force UI acknowledgements, change navigation, delete vehicles or restart the native spawn queue. A diagnostic is written to settings/streetRacersStartup.json. Other career modes are inactive and unaffected. A blocked main thread or world-loading failure cannot be recovered by this guard.

## 0.4.4 additions

`racerMarkers.lua` owns only its native map icons, removes stale icons individually and draws ready traffic on the minimap. Active traffic inspections are spread across updates, model metadata and ready lists are cached. Garage metadata is cached per career session; a queued selection resolves a parking pose once and teleports without a second facilities lookup. Main-menu part scans share a 250 ms snapshot.

Towing captures tyres and native part conditions before teleporting the existing car with resetVehicle=false. It verifies the resulting position before charging. The standard roadside service and component rebuilds use the same profile/session guards, freeze and snapshot handshake. Component rebuilds retain all conditions except the selected part's integrity and odometer, restore them after the native respawn convenience logic, and refund a failed spawn.

`common/streetRacers/mechanics.lua` defines deterministic load-based fatigue. `vehicle/extensions/streetRacersMechanics.lua` applies incremental wear through supported native device condition coefficients, preserving existing damage. Native part-condition serialization carries the state with the actual engine/gearbox/clutch/differential part across saves and swaps. Ordinary reset reapplies the observed coefficient floors; a paid rebuild creates a fresh physics instance with the selected part's renewed conditions. Custom devices without the native condition API are left alone. Native snapshots report diagnostics alongside the existing authenticated tyre snapshots.

`torqueApp.lua` clones the active career UI layout in memory, adds the StreetRacers torque app once and restores its own temporary layout on disable/unload. It republishes the career list when the layout API is replaced. The manifest's `street-racers-torque-curve` element resolves to the registered `streetRacersTorqueCurve` Angular directive. The component requests fresh native torque data after its listeners are mounted and on vehicle changes, independently of the Lua vehicle-ID cache or resize events. It does not save a new global layout or replace the user's existing torque graph. `tests/torque_app_spec.cjs` exercises the manifest, component mount, curve rendering and stream cleanup together.

The police provider keeps one extra reserved vehicle. After two periodic observations of an active reserve, it explicitly calls native `setAiMode('traffic')`: commands queued before dormant physics wakes can be lost in 0.40.5. A once-per-second check outside foreground missions, races and services claims/restores only StreetRacers reserves; missing reserves are requested at most once per ten seconds, only while native traffic is running. Tracking each traffic-entry instance prevents resetting an active patrol or pursuit on every poll. Settings display actual visible, active police counts, independently of the saved on/off preference.

## Economy and saves

Race states: idle → offer → saving → staging → countdown → running → idle. Settlement can be deferred while a career snapshot is being saved. Stake reservation records a pending race and debits once before requesting a native save. `onSaveFinished` permits staging. Each damage-preserving teleport gets a separate physics update (0.5 simulation seconds). Place the player, then use its actual body centre to position the opponent; compare body centres instead of model-specific reference nodes. Validate direction, lateral clearance and longitudinal alignment before countdown and GO. Retry the opposite side once on obstruction, otherwise refund. The opponent stays detached from traffic for the invitation/race and returns on settlement. Win pays 2× stake, loss 0, draw/technical void 1×. A pending race loaded from disk is forfeited without another debit. Statistics and the last 50 completed results, including human-readable reasons, persist with the profile. Messages and grid measurements are logged under StreetRacers.

Uses 0.39 profile hooks: `onSaveCurrentProfileAsyncStart`, `onSaveCurrentProfile`, `onSaveFinished`. Registers as an asynchronous save participant, requests tagged snapshots from connected owned vehicles, then calls `jsonWriteFileSafe`. Missing samples/timeouts invalidate the new autosave. The confirmation context remains live until all save participants finish. Economic actions and tyre replacement are blocked during a pending save.

## Tyre ownership

Native parts carry `tags.streetRacersTyreId`. Full native part tags survive reconciliation and save/load. The accompanying profile state maps each unique token to named wheel conditions. Session, binding generation and monotonically increasing packet sequence reject stale VLua messages. Incoming wear cannot increase condition. Paid replacement rotates the token, so old queued samples cannot wear the new set. Different wheel names on a reused set inherit its worst previously observed condition.

Wheel bindings prefer exact JBeam part origin, then shared part paths and axle naming. This supports standard axle-based parts; unusual vehicle mods need acceptance tests. Preview shopping suspends wear and reconnects after the transaction/cancellation. Replacement captures native part conditions before respawn and reapplies other damage after native spawn convenience repairs.

Wear is sampled from `lastSlip`, `downForceRaw`, speed and elapsed simulation time. Nine compound profiles provide durability, heating and overheat thresholds; profile selection comes from each installed tyre part and travels in the GE-to-VLua binding. Unknown parts default to road tyres. The model multiplies existing wheel friction coefficients using `setFrictionThermalSensitivity`; it restores defaults when disabled. It is intentionally a gameplay approximation. Shared pure functions allow LuaJIT tests without emulating the physics engine.

Version 0.3.2 calibrates ordinary road wear to 0.5 percentage points per 10 km (2,000 km rolling-only gameplay lifetime). Native slip velocities up to 1.5 m/s add no tread loss; beyond that band, squared excess slip and wheel load determine abrasion. Heat generation is reduced, thermal wear acceleration is capped at 1.5, and wheel/body speed suppress stationary solver jitter without suppressing a spinning, loaded tyre. Invalid telemetry cannot produce NaN wear or increase condition; negative contact load is treated as no contact. Compound multipliers and existing saved conditions remain applicable. `tools/audit_wear.py` compares the rules with the 0.3.1 archive and can replay the isolated native telemetry probe.

Save schema remains version 1. Missing `settings.tyreHud` defaults to true; an explicit false survives reload. The HUD reads only the current owned car's valid bindings and hides on the map or during foreground missions. Existing wear identities are unchanged.

Version 0.3.0 adds a sticky per-wheel `deflated` flag; missing flags in older saves default to false. Native wheel damage is sampled on connection, each snapshot, and `onTireDeflated`. Resetting a car does not clear the persisted flag. `broken` is live telemetry, not a replacement for native damage persistence.

Roadside service requires the current owned, stationary car and a punctured installed tyre set. Price is `ceil(garagePrice * 1.5) + 150`; both paths use the same existing part and keep its model. A tagged fresh VLua snapshot precedes native damage capture and payment. The service locks the car, validates session, inventory identity, quoted price and service transaction serial, then replaces the native part-sized set. The old connection is invalidated before respawn to prevent old puncture packets contaminating the new purchase. Damage restoration is queued after native initialization even if the later bridge acknowledgement is delayed. A failed spawn restores the original token/conditions and refunds the debit; prepayment timeouts release the lock without charging. Model changes remain in the native garage part shop.

Pricing markers travel with generated offers. Persisted older offers rescale once using the corrected/original base ratio, preserving seller markup. Owned inventory `configBaseValue` migrates to the same base, leaving native mileage, damage and part-difference calculations in place. Wrappers restore on career shutdown, with identity checks to avoid overwriting another extension's later wrapper.

Version 0.4.0 introduced actual engine maxPower (native PS) instead of config metadata for live pricing. `enginePrices.lua` loads one complete config at a time in an invisible temporary vehicle above the map, freezes it, requests the engine data through VLua, and deletes only its own objects. A token/vehicle check rejects stale replies; failure after 12 seconds yields no guessed price. Scanning starts only while shopping and when no race/save/service is active. Offer and owned-stock-config results share a session cache; restarting invalidates it after any mod updates. Reversible shopping hooks filter unverified/broken listings and guard purchase/inspection entry points, including the native local-function UI event path. Already verified listings remain available while others load. Negotiated prices survive refreshes. Since 0.4.20 all non-official motor vehicles use the universal measured-power policy described below. No mod files or personal save files are edited by the scanner.

## Source references

Car catalogs come from the installed vehicle APIs, with per-record validation and a stock fallback if unavailable. Collectible price families are identified from model metadata, with legacy aliases for incomplete mods. Native mod activation/deactivation/mount notifications invalidate model/power/traffic caches between races. Traffic exclusions use a versioned envelope tied to the sorted active mod names and archive size/mtime, so a changed pack or archive does not inherit an obsolete rejection. Optional APIs are guarded; the target remains the native 0.40 career, not arbitrary replacements of that career API by other mods.

Version 0.3.3 converts the GPS graph path to forward AI waypoints at GO. If the opponent lies between the first two graph nodes, omit the node behind it. Pass the remaining nodes as `wpTargetList`, allowing native AI to build its initial road segment from its actual pose. Preserve subsequent nodes and the edge through the finish. Sending the untrimmed graph as `path` made the first, already passed endpoint a driving target. A launch is confirmed by movement of at least 3 m at over 1 m/s; failure after 12 simulation seconds or a finish before launch refunds escrow. Once confirmed, subsequent stops do not cause a technical refund. Log AI route endpoints at GO and vehicle telemetry on launch timeout.

Public API background: [extensions](https://www.documentation.beamng.com/modding/programming/extensions/), [VM separation](https://docs.beamng.com/modding/programming/virtualmachines/), [input actions](https://documentation.beamng.com/modding/input/actions/), [mod packaging](https://documentation.beamng.com/modding/mod-support/mod_packing/).

Exact 0.39.4 signatures were checked against the user's locally installed game Lua: career saveSystem/inventory/partInventory, traffic provider allocator, facilities, groundMarkers, AI, vehicle wheels and JBeam stage2. These game files and the supplied reference archives are not redistributed.

## 0.4.6 selected purchase inspection

`pricing.needsEngine` includes every non-official car/truck configuration, including Custom/Career records and incomplete mod metadata; the offer's model/config keys fill omitted catalogue keys. Official BeamNG configurations and explicit trailers/props remain native. One selected pending action resumes after the engine reply; its original arguments, route and offer identity are retained. Route changes, seller changes and teardown cancel navigation. Selected inspections move ahead of queued inventory work. Scans do not start on the purchase screen. Failed inspections remain blocked. Session-only engine results cannot survive a restart with updated vehicle mods.

## 0.4.7 condition panel

`uiTheme.lua` scopes grey/orange ImGui styling to our panels. `uiLayout.lua` places the condition HUD below or beside the current window using display and font size; it suppresses the passive overlay if there is no free area. Race bet and Start controls are outside the scrolling instructions. The condition scene groups live VLua mechanical state by kind using the minimum condition; unavailable devices remain unknown. HUD telemetry reads never quote repairs or scan part inventory. Service actions remain in the parts menu. Inventory vehicle names use native localization before crossing the UI boundary.

## 0.4.8 grids, race AI and persistent banks

`routes.lua` shares width geometry between staging and the 2 Hz world preview, solves tapered widths directly, and finds nearby connected route edges without scanning the world graph. Route orientation and AI waypoint trimming use the nearest segment of the initial 200 m of the route, retaining the destination edge. Native AI uses `setRacing(true)`, no rubberband, aggression 0.96–1, normal grip/braking/avoidance and no arbitrary route speed cap. Racing mode is cleared when returning the car to traffic.

`state.racerWallets[model:configuration]` owns a lazily initialized bank. Engine inspection can set initial funding once; reinspection never replaces a spent balance. Every live instance reads the same bank. Settlement refreshes matching profiles; its key is retained in pendingRace so disappearance and interrupted losses cannot create a new account. Catalog invalidation, traffic replacement and mod changes clear transient profiles but preserve career banks. Other career profiles receive their own table.

Fatigue has a per-simulated-second upper bound and cannot reduce severe native damage coefficients. VLua reports native engine thermal flags and temperatures to the HUD without mutating thermal behavior. A percentage drop caused by native bearings/thermal integrity remains visible as such rather than being described as extra fatigue.

## 0.4.9 Alder Drag Strip

`dragStrip.lua` reads `/levels/west_coast_usa/dragstrips/alderStrip_main.strip.json` directly and caches its two lane stage/endLine positions and boundary half-widths. No native drag scenario, bridge setter or prefab is started. Missing/invalid geometry blocks the event before escrow. Both lanes share start/finish planes. The event follows the installed map's measured ~400 m endLine, rather than substituting an arbitrary GPS road or an assumed quarter-mile distance.

A career-menu GPS button navigates to staging. Within 110 m, `challengeDrag()` invites the closest-power accepted driver from active traffic, retaining the existing power/reputation and persistent model/config bank rules. Horn offers can also select drag mode near the strip. Invitations may hold a distant driver until staging; the usual 180-second invitation timeout applies. No independent spawn pool or wallet exists. Native foreground missions and an active native drag event block challenges.

The ordinary escrow/save/placement/countdown/settlement state machine is reused. Drag placement uses absolute native lane centres, validates the actual body centre within 1 m laterally / 1.5 m longitudinally, and tracks lane assignments when retrying the other side. The throttled start preview draws the two slots. Directional finish-plane crossing uses interpolation within each simulation frame and rejects reverse, out-of-lane and overhead crossings. Sustained progress is not required to lose by leaving the lane; a non-launched opponent remains a technical void. Timing uses body centres for both vehicles. History records the event kind.

`vehicle/extensions/streetRacersDragAI.lua` gives the native manual driving AI a private graph confined to one straight lane, extending 320 m past the finish to avoid early braking. It uses `ai.driveUsingPath({path=...})` with full aggression and no traffic detours. During that synchronous call only, its automatic `mapmgr.requestMap` is suppressed and always restored (including exceptions), then `mapmgr.setCustomMap` installs the graph. It never uses the teleporting `script` branch. Release, reset and extension teardown disable this controller, clear only its own custom map, and request the normal world map before traffic resumes.

## 0.4.10 strip ownership and visible bot

`nativeDrag.lua` installs reversible wrappers only for an active StreetRacers career. On West Coast outside a foreground mission it suppresses native freeroam `isDragEnabled`, `setDragRaceData` and `startDragRaceActivity`. This blocks both newly generated POIs and old invisible-trigger callbacks. A pre-existing freeroam native activity is cleared once via the native public cleanup API, and the raw-POI generation is invalidated. Foreground missions, non-freeroam drag contexts and other maps delegate to the original functions. Shutdown restores functions only if they still belong to this module, then invalidates POIs again.

Inviting a drag rival detaches a full traffic car, activates it, restores opaque mesh visibility and places it on the opposite native lane before the wager UI. Both the menu and horn-to-drag path use this placement. Missing traffic and placement errors cannot create an empty wager. The initial player lane follows the closest lane to avoid staging over the invited car; the retry swaps tracked lane assignments. The straight AI graph begins 8 m ahead of staging (a manual path's first node is a driving target), eliminating reverse/turn attempts toward an already passed point. Traffic release restores normal AI and pooling.


## 0.4.14 championship and fatigue

Street racing retains traffic selection, reputation, wagering, GPS routes and horn entry. The legacy drag/road menu selector and history list are removed. `common/streetRacers/championshipRules.lua` owns the persistent five-round ladder, targets and idempotent prizes. `ge/extensions/streetRacers/championship.lua` owns one private entrant, attached objects, generation token, physics wake delay and authenticated power response. Entrants never come from the road-traffic acceptance pool; they are deleted on release, cancellation, timeout and shutdown. The world registration marker is 25 m behind the line and 18 m beside it, with proximity horn opening and a menu fallback.

The native spawn API creates entrants without entering them or replacing traffic. `vehicle/extensions/streetRacersChampionship.lua` scales real combustion-engine torque curves, verifies the non-nitrous peak, and scales the engine torque rating for the purpose-built tune. Unsupported devices or calibration errors fail before race reservation. The existing race state machine runs a zero-stake drag; pending records carry championship/round IDs. Settlement advances the ladder and pays once. Interrupted saved rounds remain retryable without another debit or prize. The same owned car and power within 5% are required for an unfinished roster.

Fatigue calibrates a 1000 PS engine at full load / 90% RPM to roughly 30 points in 100 loaded seconds. Road load remains inexpensive. Active native nitrous torque, induction ratio, cold oil, high oil temperature and sustained load increase loss. A supported combustion engine reaches native `lockUp()` at zero gameplay condition. Existing native damage is never reduced; coefficient floors survive reset and native serialization. Gearbox/differential/clutch fatigue uses transmitted torque. No tyre coefficients changed.

Mechanism references, not numerical lifespan: [Haltech nitrous control](https://support.haltech.com/portal/en/kb/articles/nitrous-control) documents damage from incorrect fuel/ignition corrections; [Garrett turbo systems](https://www.garrettmotion.com/wp-content/uploads/2019/10/GAM_Turbo-Systems-102_Advanced.pdf) discusses detonation and damaging pressure spikes. Neither specifies a universal ten-race life; the 70% target is an explicit gameplay calibration.


## 0.4.15 championship bank

The ladder uses economyVersion=2. Each win advances once and accumulates an unpaid bank; only the fifth win returns a $29,000 payout to the career adapter. A loss atomically marks the ladder failed and zeroes its bank, retaining the result table for display. Failed ladders cannot settle again; starting another event creates a new championship identity and begins at round one. Void/draw keep the bank. Reset discards unpaid bank, while normal save/reload between stages preserves it. A pending saved stage is recovered as loss, burning all bank without another career debit. No entry fee exists. The existing zero-stake race/save pipeline and street wagering branch are unchanged.

Legacy ladders paid rewards immediately, so migration clears their table without crediting or reclaiming money. The migration requests a save after initialization. Completed/failed states have a zero bank; valid unfinished states have bank equal to the sum of won rewards. Tests cover duplicate/outdated results, all loss rounds, resumed final settlement and UI forfeiture messaging.


## 0.4.16 drag map ownership

Suppressing the synchronous requestMap call inside driveUsingPath is insufficient: spawn/tracking can have a world-map reply already in flight. Native mapmgr.setMap then replaces mapmgr.mapData. Native AI detects the changed graph, clears currentRoute, and has no pending manualPath left to rebuild it. The vehicle continues with its last pedal and steering commands. This explains a gradual departure from the strip without an AI exception.

streetRacersDragAI guards the vehicle-local setMap callback while it owns the custom lane graph. Stop/reset/unload restore the original callback only if still owned, then clear the private map and request the world map. A retired guard delegates normally, including when a later mod has wrapped it. Circuit racing is disabled before path setup so native AI uses the original straight path without alternate overtaking plans. All steering, pedals, traction management, physics and engine output remain native. Street racing never loads this controller and keeps its existing AI settings.

The API regression injects a late world-map reply after path setup and verifies that the private graph/aliases survive, then verifies normal world replies after release. Existing tests cover error restoration, idempotent stop and inherited circuit mode. The development-only freeroam lane probe measures body-centre lateral error and finish progress on both lanes at 900–1500 PS in an isolated userpath; it never enters a personal career. Optional telemetry records map ownership and rejected map replies.


## 0.4.17 menu navigation

During an active StreetRacers career, menuNavigation installs a reversible guihooks.trigger adapter for native UINavigation/menu events (toggleMenues emits both onDown=1 and onUp=0). Only a full StreetRacers menu in play, outside loading, foreground missions and big map, consumes a press. It closes the full menu without changing tyre HUD settings. The matching release and repeats are consumed so a release-driven native handler cannot open the game menu on the same press; the next full pair delegates unchanged. Other events retain exact varargs, including nils and argument count.

Career shutdown restores the prior trigger only if still owned; a retired adapter delegates through a later wrapper. Main-window bounds clear on close. No global input rebinding or native UI bundle changes are made. Tests cover event pairs, repeated down, reopen, HUD availability, native UI/map/loading, vanilla career and teardown.


## 0.4.18 tyre catalogue and immediate championship payouts

`tyreCatalog` reads each installed tyre slot's `suitablePartNames` from the resolved native `config.partsTree` and retrieves leaf-part metadata with `jbeam/io`. No synthetic tyre models or guessed size compatibility. The catalogue is cached per vehicle-data object and slot. Every inventory slot remains an independent target. Both service tabs use the same model selector and confirmation with part token, model and price.

The coordinator chooses the garage tariff in the garage and roadside tariff elsewhere. Roadside service accepts intact worn tyres, requires the occupied stopped owned car, and retains mission/pursuit/race/save restrictions. A fresh snapshot precedes payment outside the garage. On model changes, the native parts tree, inventory part name/path/value, fresh tyre identity and native part conditions change together. Other parts retain their captured damage. Failed respawn restores the entire part, config, changedSlots and conditions and refunds the payment. Native spawn/reconciliation rebuilds inventory path maps.

Championship economyVersion=3 pays each won stage immediately. Rewards use max(1000, min(playerPower,10000)*5), stage multipliers 1/1.2/1.4/1.7/2, rounded to $50. Paid stages advance once; loss/draw/void keep the current stage and prior earnings. The bank remains zero. Saved interrupted rounds are retryable losses. Old valid economyVersion=2 unpaid banks are credited once and removed with their obsolete table in the next career save; failed/completed banks pay nothing. Old immediate-payment tables are reset without any additional credit. Career money and mod state use the same existing coordinated save lifecycle.


## 0.4.19 garage ownership and default Belasco start

`ownedGarages` persists booleans in the existing coordinated career snapshot. Belasco (`servicestationGarage`) is free; new careers queue it automatically after native loading, then resolve/teleport once and save. Other IDs cannot enter the starter path. A failed pose lookup requires an explicit Belasco retry instead of searching every frame. Legacy unpurchased home selections fall back to Belasco without moving cars or charging money.

Career → Garages offers each other catalogue garage for $100,000. The server-side purchase validates catalogue ID, exact price, balance, existing ownership and the idle/save state before debiting once and requesting a save. Purchased bases can be made home without teleportation; the existing GPS/tow code follows homeGarage.

`garageAccess` scopes two native wrappers to StreetRacers. Unowned garage zone queries return an empty list, so the native closest-garage and service/retrieval paths select owned garages and the tyre coordinator charges roadside prices on unowned premises. Opening an unowned garage computer leads to the mod purchase menu. Native facilities metadata and physical buildings remain intact. Ownership checks during loading do not enumerate/cache facilities. Shutdown restores only wrappers it still owns; retained predecessors delegate to native APIs after shutdown. Vanilla careers install no wrapper.


## 0.4.20 universal measured market pricing

Opening the vehicle list queues every non-official motor-vehicle offer immediately. Pending and failed offers are removed from outbound native shopping data, so the UI never exposes an unverified metadata quote. Each successful physical reply refreshes the list (throttled to 0.5 seconds), and the verified offer appears without a purchase click. The scanner still loads exactly one invisible frozen configuration at a time and caches model+configuration results for the session.

`powerPrice` is the only mod base-price policy. It linearly interpolates 10k/25k/45k/70k/200k at 40/150/600/1000/2500 PS, rounds to $500 and clamps outliers to the endpoint range. Original model names, classes, years, `Power` and `Value` do not enter the result. The listing writes this base as marketValue and applies only the native seller personality clamped to 0.95–1.05. Owned vehicles receive the same configBaseValue; native parts, mileage and damage continue to affect their resale. Pricing marker version 4 migrates old family-specific and conservative corrections once.


## 0.4.21 championship stage wagers

Championship economyVersion=4 uses each round reward as its fixed stake. The normal race escrow now debits that amount before the coordinated pre-race save instead of running a zero-stake drag. A win pays `2 * stake` (net `+stake`), a loss pays zero, and draw/void returns the reserved stake. Ladder settlement remains idempotent and advances only on a win. Losses retain the round but a retry creates a new escrow. Insufficient balance is rejected before lineup persistence or opponent spawn.

Pending championship races use the same saved-debit recovery as street races: loading a committed unfinished race records one loss and never debits again. Pre-GO cancellation, staging failure, silent AI and technical disappearance refund once; player forfeiture after GO loses the stake. Every outcome enters common stats/history with its net value. Version 3 lineups are reset without altering money so free and paid attempts cannot mix; already paid prizes remain in the career balance. Valid legacy version 2 unpaid banks retain their one-time migration credit.

The native StreetRacers starting mode sets $15,000 through initPlayerAttributes only when a new career is created. Loading or migrating an existing profile never grants or replaces this capital.
